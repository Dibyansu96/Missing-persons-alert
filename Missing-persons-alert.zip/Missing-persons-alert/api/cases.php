<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

try {
    // Handle GET request for fetching cases
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $response = getCases();
        echo json_encode($response);
    }
    // Handle POST request for creating new cases (if needed)
    elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $response = createCase();
        echo json_encode($response);
    } else {
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Internal server error', 'message' => $e->getMessage()]);
}

function getCases() {
    // Get query parameters
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 6;
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';
    $locationFilter = isset($_GET['location']) ? trim($_GET['location']) : '';
    $statusFilter = isset($_GET['status']) ? trim($_GET['status']) : '';
    $ageFilter = isset($_GET['age']) ? trim($_GET['age']) : '';
    $genderFilter = isset($_GET['gender']) ? trim($_GET['gender']) : '';
    $timeFilter = isset($_GET['time']) ? trim($_GET['time']) : '';
    $sortFilter = isset($_GET['sort']) ? trim($_GET['sort']) : 'recent';

    // Build NamUs API parameters
    $apiParams = [
        'page' => $page,
        'size' => $limit
    ];

    // Add search parameter
    if ($search) {
        $apiParams['namus2Number'] = $search; // NamUs case number search
    }

    // Add location filter (simplified - NamUs uses state/city)
    if ($locationFilter) {
        // Map our location filters to NamUs states
        $locationMap = [
            'north-america' => ['CA', 'TX', 'FL', 'NY', 'IL', 'PA', 'OH', 'GA', 'NC', 'MI'],
            'europe' => [], // NamUs is primarily US-based
            'asia' => [],
            'africa' => [],
            'south-america' => [],
            'australia' => []
        ];

        if (isset($locationMap[$locationFilter])) {
            $apiParams['state'] = implode(',', $locationMap[$locationFilter]);
        }
    }

    // Add age filter
    if ($ageFilter) {
        switch ($ageFilter) {
            case 'child':
                $apiParams['minAge'] = 0;
                $apiParams['maxAge'] = 12;
                break;
            case 'teen':
                $apiParams['minAge'] = 13;
                $apiParams['maxAge'] = 17;
                break;
            case 'adult':
                $apiParams['minAge'] = 18;
                $apiParams['maxAge'] = 59;
                break;
            case 'senior':
                $apiParams['minAge'] = 60;
                $apiParams['maxAge'] = 100;
                break;
        }
    }

    // Add gender filter
    if ($genderFilter) {
        $apiParams['sex'] = ucfirst($genderFilter);
    }

    // Add time filter (simplified - NamUs doesn't have exact date ranges)
    if ($timeFilter) {
        switch ($timeFilter) {
            case 'today':
            case 'week':
                $apiParams['circumstances'] = 'Missing'; // Focus on active missing cases
                break;
            case 'month':
            case 'year':
                // No specific time filter in NamUs API
                break;
        }
    }

    // Try to fetch from NamUs API
    $namusData = fetchFromNamUsAPI($apiParams);

    if ($namusData !== false) {
        // Format NamUs data for frontend
        $formattedCases = [];
        foreach ($namusData['results'] as $case) {
            $formattedCase = formatNamUsCase($case);
            if ($formattedCase) {
                $formattedCases[] = $formattedCase;
            }
        }

        // Apply additional client-side filtering if needed
        $filteredCases = applyClientSideFilters($formattedCases, $statusFilter, $timeFilter, $sortFilter);

        // Calculate pagination info
        $total = $namusData['total'] ?? count($filteredCases);
        $totalPages = ceil($total / $limit);

        return [
            'success' => true,
            'cases' => array_slice($filteredCases, 0, $limit),
            'pagination' => [
                'page' => $page,
                'limit' => $limit,
                'total' => $total,
                'totalPages' => $totalPages
            ]
        ];
    }

    // Fallback to realistic mock data that simulates NamUs
    return getMockNamUsCases($page, $limit, $search, $locationFilter, $statusFilter, $ageFilter, $genderFilter, $timeFilter, $sortFilter);
}

function createCase() {
    // Implementation for creating new cases if needed
    return ['success' => false, 'message' => 'Not implemented'];
}

function getTimeAgo($datetime) {
    $now = new DateTime();
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    if ($diff->y > 0) return $diff->y . ' year' . ($diff->y > 1 ? 's' : '') . ' ago';
    if ($diff->m > 0) return $diff->m . ' month' . ($diff->m > 1 ? 's' : '') . ' ago';
    if ($diff->d > 0) return $diff->d . ' day' . ($diff->d > 1 ? 's' : '') . ' ago';
    if ($diff->h > 0) return $diff->h . ' hour' . ($diff->h > 1 ? 's' : '') . ' ago';
    if ($diff->i > 0) return $diff->i . ' minute' . ($diff->i > 1 ? 's' : '') . ' ago';
    return 'Just now';
}

function getAgeCategory($age) {
    if ($age < 13) return 'child';
    if ($age < 18) return 'teen';
    if ($age < 60) return 'adult';
    return 'senior';
}

function getRandomColor() {
    $colors = ['#e0f2fe', '#dcfce7', '#fef3c7', '#e0e7ff', '#fce7f3'];
    return $colors[array_rand($colors)];
}

// Format NamUs case data to match frontend structure
function formatNamUsCase($case) {
    // Extract basic information
    $firstName = $case['firstName'] ?? 'Unknown';
    $lastName = $case['lastName'] ?? '';
    $fullName = trim($firstName . ' ' . $lastName);

    // Calculate age from date of birth
    $age = null;
    if (isset($case['dateOfBirth'])) {
        $birthDate = new DateTime($case['dateOfBirth']);
        $now = new DateTime();
        $age = $now->diff($birthDate)->y;
    }

    // Determine gender
    $gender = 'unknown';
    if (isset($case['sex'])) {
        $sex = strtolower($case['sex']);
        if ($sex === 'male') $gender = 'male';
        elseif ($sex === 'female') $gender = 'female';
    }

    // Build location string
    $location = '';
    if (isset($case['city']) && isset($case['state'])) {
        $location = $case['city'] . ', ' . $case['state'];
    } elseif (isset($case['state'])) {
        $location = $case['state'];
    }

    // Build description from circumstances
    $description = 'Missing person case';
    if (isset($case['circumstances'])) {
        $description = substr($case['circumstances'], 0, 100) . (strlen($case['circumstances']) > 100 ? '...' : '');
    }

    // Calculate time ago from date of last contact
    $timeAgo = 'Unknown';
    if (isset($case['dateOfLastContact'])) {
        $timeAgo = getTimeAgo($case['dateOfLastContact']);
    }

    // Build tags
    $tags = [];
    if ($age !== null && $age < 18) {
        $tags[] = 'child';
    }
    if (isset($case['isUrgent']) && $case['isUrgent']) {
        $tags[] = 'urgent';
    }

    // Extract coordinates if available
    $latitude = null;
    $longitude = null;
    if (isset($case['location'])) {
        // Try to extract coordinates from location data
        if (isset($case['location']['latitude']) && isset($case['location']['longitude'])) {
            $latitude = $case['location']['latitude'];
            $longitude = $case['location']['longitude'];
        }
    }

    // If no coordinates, try geocoding the location
    if ($latitude === null && $longitude === null && !empty($location)) {
        $coords = geocodeLocation($location);
        if ($coords) {
            $latitude = $coords['lat'];
            $longitude = $coords['lng'];
        }
    }

    return [
        'id' => $case['namus2Number'] ?? uniqid(),
        'name' => $fullName ?: 'Unknown Person',
        'age' => $age ?? 0,
        'location' => $location ?: 'Location unknown',
        'timeAgo' => $timeAgo,
        'description' => $description,
        'status' => 'active',
        'gender' => $gender,
        'category' => getAgeCategory($age ?? 0),
        'tags' => $tags,
        'imageColor' => getRandomColor(),
        'latitude' => $latitude,
        'longitude' => $longitude,
        'namusId' => $case['namus2Number'] ?? null
    ];
}

// Apply additional client-side filtering
function applyClientSideFilters($cases, $statusFilter, $timeFilter, $sortFilter) {
    $filteredCases = $cases;

    // Apply status filter
    if ($statusFilter) {
        switch ($statusFilter) {
            case 'active':
                $filteredCases = array_filter($filteredCases, fn($case) => $case['status'] === 'active');
                break;
            case 'recent':
                $filteredCases = array_filter($filteredCases, fn($case) => strpos($case['timeAgo'], 'day') !== false || strpos($case['timeAgo'], 'hour') !== false);
                break;
            case 'critical':
                $filteredCases = array_filter($filteredCases, fn($case) => in_array('urgent', $case['tags']) && $case['age'] < 18);
                break;
        }
    }

    // Apply time filter
    if ($timeFilter) {
        switch ($timeFilter) {
            case 'today':
                $filteredCases = array_filter($filteredCases, fn($case) => strpos($case['timeAgo'], 'hour') !== false);
                break;
            case 'week':
                $filteredCases = array_filter($filteredCases, fn($case) => strpos($case['timeAgo'], 'day') !== false || strpos($case['timeAgo'], 'week') !== false);
                break;
        }
    }

    // Apply sorting
    switch ($sortFilter) {
        case 'recent':
            // Already somewhat sorted by API
            break;
        case 'urgent':
            usort($filteredCases, fn($a, $b) => count(array_intersect($b['tags'], ['urgent'])) <=> count(array_intersect($a['tags'], ['urgent'])));
            break;
        case 'name':
            usort($filteredCases, fn($a, $b) => strcmp($a['name'], $b['name']));
            break;
    }

    return array_values($filteredCases);
}

// Fallback function to get cases from local DB
function getCasesFromLocalDB($page, $limit, $search, $locationFilter, $statusFilter, $ageFilter, $genderFilter, $timeFilter, $sortFilter) {
    global $pdo;

    $offset = ($page - 1) * $limit;

    // Build WHERE clause
    $whereConditions = [];
    $params = [];

    if ($search) {
        $whereConditions[] = "(CONCAT(first_name, ' ', last_name) LIKE ? OR last_seen_location LIKE ? OR circumstances LIKE ? OR distinctive_features LIKE ?)";
        $searchParam = "%$search%";
        $params = array_merge($params, [$searchParam, $searchParam, $searchParam, $searchParam]);
    }

    if ($locationFilter) {
        $whereConditions[] = "last_seen_location LIKE ?";
        $params[] = "%$locationFilter%";
    }

    if ($statusFilter) {
        if ($statusFilter === 'active') {
            $whereConditions[] = "status = 'active'";
        } elseif ($statusFilter === 'recent') {
            $whereConditions[] = "last_seen_date >= DATE_SUB(NOW(), INTERVAL 2 DAY)";
        } elseif ($statusFilter === 'critical') {
            $whereConditions[] = "last_seen_date >= DATE_SUB(NOW(), INTERVAL 1 DAY) AND age < 18";
        }
    }

    if ($ageFilter) {
        switch ($ageFilter) {
            case 'child':
                $whereConditions[] = "age BETWEEN 0 AND 12";
                break;
            case 'teen':
                $whereConditions[] = "age BETWEEN 13 AND 17";
                break;
            case 'adult':
                $whereConditions[] = "age BETWEEN 18 AND 59";
                break;
            case 'senior':
                $whereConditions[] = "age >= 60";
                break;
        }
    }

    if ($genderFilter) {
        $whereConditions[] = "gender = ?";
        $params[] = $genderFilter;
    }

    if ($timeFilter) {
        switch ($timeFilter) {
            case 'today':
                $whereConditions[] = "last_seen_date >= CURDATE()";
                break;
            case 'week':
                $whereConditions[] = "last_seen_date >= DATE_SUB(NOW(), INTERVAL 1 WEEK)";
                break;
            case 'month':
                $whereConditions[] = "last_seen_date >= DATE_SUB(NOW(), INTERVAL 1 MONTH)";
                break;
            case 'year':
                $whereConditions[] = "last_seen_date >= DATE_SUB(NOW(), INTERVAL 1 YEAR)";
                break;
        }
    }

    $whereClause = $whereConditions ? 'WHERE ' . implode(' AND ', $whereConditions) : '';

    // Build ORDER BY clause
    $orderBy = 'ORDER BY ';
    switch ($sortFilter) {
        case 'recent':
            $orderBy .= 'created_at DESC';
            break;
        case 'urgent':
            $orderBy .= 'CASE WHEN last_seen_date >= DATE_SUB(NOW(), INTERVAL 1 DAY) THEN 1 ELSE 2 END, created_at DESC';
            break;
        case 'name':
            $orderBy .= 'first_name ASC, last_name ASC';
            break;
        default:
            $orderBy .= 'created_at DESC';
    }

    // Get total count
    $countQuery = "SELECT COUNT(*) as total FROM missing_persons $whereClause";
    $countStmt = $pdo->prepare($countQuery);
    $countStmt->execute($params);
    $total = $countStmt->fetch()['total'];

    // Get cases
    $query = "SELECT id, case_id, first_name, last_name, age, gender, last_seen_date, last_seen_location, circumstances, distinctive_features, status, created_at FROM missing_persons $whereClause $orderBy LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $cases = $stmt->fetchAll();

    // Format cases for frontend
    $formattedCases = [];
    foreach ($cases as $case) {
        $timeAgo = getTimeAgo($case['created_at']);
        $tags = [];

        if ($case['age'] < 18) {
            $tags[] = 'child';
        }
        if (strtotime($case['last_seen_date']) >= strtotime('-1 day')) {
            $tags[] = 'urgent';
        }
        if (strpos($case['circumstances'], 'medical') !== false) {
            $tags[] = 'medical';
        }

        $formattedCases[] = [
            'id' => $case['id'],
            'name' => $case['first_name'] . ' ' . $case['last_name'],
            'age' => $case['age'],
            'location' => $case['last_seen_location'],
            'timeAgo' => $timeAgo,
            'description' => substr($case['circumstances'], 0, 100) . '...',
            'status' => $case['status'] === 'active' ? 'active' : 'resolved',
            'gender' => $case['gender'],
            'category' => getAgeCategory($case['age']),
            'tags' => $tags,
            'imageColor' => getRandomColor(),
            'latitude' => rand(25000000, 50000000) / 1000000, // Random coords for demo
            'longitude' => rand(-125000000, -70000000) / 1000000
        ];
    }

    return [
        'success' => true,
        'cases' => $formattedCases,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'totalPages' => ceil($total / $limit)
        ]
    ];
}

// Function to fetch data from NamUs API
function fetchFromNamUsAPI($params) {
    $apiUrl = 'https://www.namus.gov/api/MissingPersons/search?' . http_build_query($params);

    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => [
                'Accept: application/json',
                'User-Agent: FindThem/1.0'
            ],
            'timeout' => 30
        ]
    ]);

    $response = @file_get_contents($apiUrl, false, $context);

    if ($response === false) {
        return false;
    }

    $data = json_decode($response, true);

    if ($data === null) {
        // Try to extract JSON from HTML response
        $jsonStart = strpos($response, '{');
        $jsonEnd = strrpos($response, '}');

        if ($jsonStart !== false && $jsonEnd !== false) {
            $jsonString = substr($response, $jsonStart, $jsonEnd - $jsonStart + 1);
            $data = json_decode($jsonString, true);
        }

        if ($data === null) {
            return false;
        }
    }

    return $data;
}

// Fallback function that generates realistic mock data simulating NamUs
function getMockNamUsCases($page, $limit, $search, $locationFilter, $statusFilter, $ageFilter, $genderFilter, $timeFilter, $sortFilter) {
    $totalCases = 1247; // Simulate NamUs total
    $offset = ($page - 1) * $limit;

    // Generate mock cases
    $mockCases = [];
    $firstNames = ['John', 'Jane', 'Michael', 'Sarah', 'David', 'Lisa', 'Robert', 'Emily', 'James', 'Maria'];
    $lastNames = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez'];
    $cities = ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix', 'Philadelphia', 'San Antonio', 'San Diego', 'Dallas', 'San Jose'];
    $states = ['NY', 'CA', 'IL', 'TX', 'AZ', 'PA'];

    for ($i = 0; $i < $limit; $i++) {
        $id = $offset + $i + 1;
        $firstName = $firstNames[array_rand($firstNames)];
        $lastName = $lastNames[array_rand($lastNames)];
        $age = rand(5, 80);
        $city = $cities[array_rand($cities)];
        $state = $states[array_rand($states)];
        $location = $city . ', ' . $state;

        // Generate coordinates based on location
        $coords = geocodeLocation(strtolower($location));
        $latitude = $coords ? $coords['lat'] : (rand(25000000, 50000000) / 1000000);
        $longitude = $coords ? $coords['lng'] : (rand(-125000000, -70000000) / 1000000);

        $gender = ['male', 'female'][rand(0, 1)];
        $daysAgo = rand(1, 365);
        $dateReported = date('Y-m-d', strtotime("-{$daysAgo} days"));
        $timeAgo = getTimeAgo($dateReported);

        $circumstances = [
            'Last seen walking home from work',
            'Disappeared after school',
            'Left home for grocery shopping',
            'Hiking trip in desert area',
            'After school activity',
            'Medical emergency reported',
            'Run away from home',
            'Missing from residence'
        ][rand(0, 7)];

        $tags = [];
        if ($age < 18) $tags[] = 'child';
        if ($daysAgo <= 7) $tags[] = 'urgent';
        if (strpos($circumstances, 'medical') !== false) $tags[] = 'medical';

        $mockCases[] = [
            'namus2Number' => 'MP' . str_pad($id, 6, '0', STR_PAD_LEFT),
            'firstName' => $firstName,
            'lastName' => $lastName,
            'dateOfBirth' => date('Y-m-d', strtotime("-{$age} years")),
            'sex' => ucfirst($gender),
            'city' => $city,
            'state' => $state,
            'circumstances' => $circumstances,
            'dateOfLastContact' => $dateReported,
            'isUrgent' => in_array('urgent', $tags)
        ];
    }

    // Apply filters to mock data
    $filteredCases = array_filter($mockCases, function($case) use ($search, $locationFilter, $ageFilter, $genderFilter) {
        if ($search && stripos($case['firstName'] . ' ' . $case['lastName'], $search) === false && stripos($case['namus2Number'], $search) === false) {
            return false;
        }

        if ($locationFilter && stripos($case['state'], $locationFilter) === false) {
            return false;
        }

        if ($ageFilter) {
            $birthDate = new DateTime($case['dateOfBirth']);
            $now = new DateTime();
            $caseAge = $now->diff($birthDate)->y;

            switch ($ageFilter) {
                case 'child': if ($caseAge > 12) return false; break;
                case 'teen': if ($caseAge < 13 || $caseAge > 17) return false; break;
                case 'adult': if ($caseAge < 18 || $caseAge > 59) return false; break;
                case 'senior': if ($caseAge < 60) return false; break;
            }
        }

        if ($genderFilter && strtolower($case['sex']) !== $genderFilter) {
            return false;
        }

        return true;
    });

    // Apply sorting
    switch ($sortFilter) {
        case 'name':
            usort($filteredCases, fn($a, $b) => strcmp($a['firstName'] . ' ' . $a['lastName'], $b['firstName'] . ' ' . $b['lastName']));
            break;
        case 'urgent':
            usort($filteredCases, fn($a, $b) => $b['isUrgent'] <=> $a['isUrgent']);
            break;
        case 'recent':
        default:
            usort($filteredCases, fn($a, $b) => strtotime($b['dateOfLastContact']) <=> strtotime($a['dateOfLastContact']));
            break;
    }

    $filteredCases = array_values($filteredCases);
    $paginatedCases = array_slice($filteredCases, 0, $limit);

    return [
        'results' => $paginatedCases,
        'total' => count($filteredCases)
    ];
}

// Simple geocoding function (fallback for coordinates)
function geocodeLocation($location) {
    // This is a simplified geocoding function
    // In production, you might want to use a proper geocoding service
    $location = strtolower(trim($location));

    // Basic coordinate mapping for common locations
    $coordinates = [
        'new york, ny' => ['lat' => 40.7128, 'lng' => -74.0060],
        'los angeles, ca' => ['lat' => 34.0522, 'lng' => -118.2437],
        'chicago, il' => ['lat' => 41.8781, 'lng' => -87.6298],
        'houston, tx' => ['lat' => 29.7604, 'lng' => -95.3698],
        'phoenix, az' => ['lat' => 33.4484, 'lng' => -112.0740],
        'philadelphia, pa' => ['lat' => 39.9526, 'lng' => -75.1652],
        'san antonio, tx' => ['lat' => 29.4241, 'lng' => -98.4936],
        'san diego, ca' => ['lat' => 32.7157, 'lng' => -117.1611],
        'dallas, tx' => ['lat' => 32.7767, 'lng' => -96.7970],
        'san jose, ca' => ['lat' => 37.3382, 'lng' => -121.8863],
    ];

    return $coordinates[$location] ?? null;
}
?>
