<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Include database configuration (you'll need to create this)
require_once 'config.php';

// Get the request method
$method = $_SERVER['REQUEST_METHOD'];

try {
    switch ($method) {
        case 'POST':
            handlePostRequest();
            break;
        case 'GET':
            handleGetRequest();
            break;
        default:
            throw new Exception('Method not allowed', 405);
    }
} catch (Exception $e) {
    http_response_code($e->getCode() ?: 500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}

function handlePostRequest() {
    global $pdo;

    // Check if this is a photo upload request
    if (isset($_GET['caseId']) && !empty($_FILES)) {
        handlePhotoUpload($_GET['caseId']);
        return;
    }

    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);

    if (!$input) {
        throw new Exception('Invalid JSON data', 400);
    }

    // Validate required fields
    $requiredFields = [
        'firstName', 'lastName', 'age', 'gender',
        'lastSeenDate', 'lastSeenLocation', 'circumstances',
        'reporterName', 'reporterRelationship', 'reporterPhone', 'reporterEmail'
    ];

    foreach ($requiredFields as $field) {
        if (empty($input[$field])) {
            throw new Exception("Missing required field: $field", 400);
        }
    }

    // Generate case ID
    $caseId = generateCaseId();

    // Prepare data for insertion
    $data = [
        'case_id' => $caseId,
        'first_name' => sanitizeInput($input['firstName']),
        'last_name' => sanitizeInput($input['lastName']),
        'age' => (int)$input['age'],
        'gender' => sanitizeInput($input['gender']),
        'date_of_birth' => !empty($input['dateOfBirth']) ? $input['dateOfBirth'] : null,
        'nationality' => !empty($input['nationality']) ? sanitizeInput($input['nationality']) : null,
        'height' => !empty($input['height']) ? (int)$input['height'] : null,
        'weight' => !empty($input['weight']) ? (int)$input['weight'] : null,
        'hair_color' => !empty($input['hairColor']) ? sanitizeInput($input['hairColor']) : null,
        'eye_color' => !empty($input['eyeColor']) ? sanitizeInput($input['eyeColor']) : null,
        'distinctive_features' => !empty($input['distinctiveFeatures']) ? sanitizeInput($input['distinctiveFeatures']) : null,
        'clothing_last_seen' => !empty($input['clothingLastSeen']) ? sanitizeInput($input['clothingLastSeen']) : null,
        'last_seen_date' => $input['lastSeenDate'],
        'last_seen_time' => !empty($input['lastSeenTime']) ? $input['lastSeenTime'] : null,
        'last_seen_location' => sanitizeInput($input['lastSeenLocation']),
        'last_seen_details' => !empty($input['lastSeenDetails']) ? sanitizeInput($input['lastSeenDetails']) : null,
        'circumstances' => sanitizeInput($input['circumstances']),
        'medical_conditions' => !empty($input['medicalConditions']) ? sanitizeInput($input['medicalConditions']) : null,
        'behavioral_issues' => !empty($input['behavioralIssues']) ? sanitizeInput($input['behavioralIssues']) : null,
        'reporter_name' => sanitizeInput($input['reporterName']),
        'reporter_relationship' => sanitizeInput($input['reporterRelationship']),
        'reporter_phone' => sanitizeInput($input['reporterPhone']),
        'reporter_email' => sanitizeInput($input['reporterEmail']),
        'additional_contact' => !empty($input['additionalContact']) ? sanitizeInput($input['additionalContact']) : null,
        'status' => 'active',
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s')
    ];

    // Insert into database
    $columns = implode(', ', array_keys($data));
    $placeholders = ':' . implode(', :', array_keys($data));

    $stmt = $pdo->prepare("INSERT INTO missing_persons ($columns) VALUES ($placeholders)");

    foreach ($data as $key => $value) {
        $stmt->bindValue(":$key", $value);
    }

    if ($stmt->execute()) {
        echo json_encode([
            'success' => true,
            'data' => [
                'caseId' => $caseId,
                'message' => 'Report submitted successfully'
            ]
        ]);
    } else {
        throw new Exception('Failed to save report', 500);
    }
}

function handlePhotoUpload($caseId) {
    global $pdo;

    // Create uploads directory if it doesn't exist
    $uploadDir = '../assets/uploads/cases/' . $caseId . '/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    $uploadedFiles = [];

    if (isset($_FILES['photos'])) {
        $files = $_FILES['photos'];

        for ($i = 0; $i < count($files['name']); $i++) {
            if ($files['error'][$i] === UPLOAD_ERR_OK) {
                $fileName = basename($files['name'][$i]);
                $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

                // Validate file type
                $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
                if (!in_array($fileExt, $allowedTypes)) {
                    continue; // Skip invalid files
                }

                // Generate unique filename
                $newFileName = uniqid() . '.' . $fileExt;
                $filePath = $uploadDir . $newFileName;

                if (move_uploaded_file($files['tmp_name'][$i], $filePath)) {
                    $uploadedFiles[] = $newFileName;

                    // Save photo reference to database
                    $stmt = $pdo->prepare("INSERT INTO case_photos (case_id, filename, uploaded_at) VALUES (?, ?, ?)");
                    $stmt->execute([$caseId, $newFileName, date('Y-m-d H:i:s')]);
                }
            }
        }
    }

    echo json_encode([
        'success' => true,
        'data' => [
            'uploaded' => count($uploadedFiles),
            'files' => $uploadedFiles
        ]
    ]);
}

function handleGetRequest() {
    global $pdo;

    // Get all reports or specific report
    if (isset($_GET['caseId'])) {
        $stmt = $pdo->prepare("SELECT * FROM missing_persons WHERE case_id = ?");
        $stmt->execute([$_GET['caseId']]);
        $report = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($report) {
            echo json_encode([
                'success' => true,
                'data' => $report
            ]);
        } else {
            throw new Exception('Report not found', 404);
        }
    } else {
        // Get all active reports
        $stmt = $pdo->query("SELECT * FROM missing_persons WHERE status = 'active' ORDER BY created_at DESC");
        $reports = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true,
            'data' => $reports
        ]);
    }
}

function generateCaseId() {
    return 'MP' . date('Y') . strtoupper(substr(md5(uniqid()), 0, 6));
}

function sanitizeInput($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}
?>
