<?php
// Database configuration
$host = 'localhost';
$dbname = 'findthem_db';
$username = 'root';
$password = '';

try {
    // Connect without specifying database to create it if needed
    $pdo = new PDO("mysql:host=$host;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

    // Create database if it doesn't exist
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbname`");
    $pdo->exec("USE `$dbname`");
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Create tables if they don't exist
try {
    // Missing persons table
    $pdo->exec("CREATE TABLE IF NOT EXISTS missing_persons (
        id INT AUTO_INCREMENT PRIMARY KEY,
        case_id VARCHAR(20) UNIQUE NOT NULL,
        first_name VARCHAR(100) NOT NULL,
        last_name VARCHAR(100) NOT NULL,
        age INT,
        gender ENUM('male', 'female', 'other', 'unknown'),
        date_of_birth DATE,
        nationality VARCHAR(100),
        height INT,
        weight INT,
        hair_color VARCHAR(50),
        eye_color VARCHAR(50),
        distinctive_features TEXT,
        clothing_last_seen TEXT,
        last_seen_date DATE NOT NULL,
        last_seen_time TIME,
        last_seen_location TEXT NOT NULL,
        last_seen_details TEXT,
        circumstances TEXT NOT NULL,
        medical_conditions TEXT,
        behavioral_issues TEXT,
        reporter_name VARCHAR(200) NOT NULL,
        reporter_relationship VARCHAR(100) NOT NULL,
        reporter_phone VARCHAR(20) NOT NULL,
        reporter_email VARCHAR(200) NOT NULL,
        additional_contact TEXT,
        status ENUM('active', 'resolved', 'closed') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )");

    // Case photos table
    $pdo->exec("CREATE TABLE IF NOT EXISTS case_photos (
        id INT AUTO_INCREMENT PRIMARY KEY,
        case_id VARCHAR(20) NOT NULL,
        filename VARCHAR(255) NOT NULL,
        uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (case_id) REFERENCES missing_persons(case_id) ON DELETE CASCADE
    )");

    // Insert sample data if table is empty
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM missing_persons");
    $result = $stmt->fetch();
    if ($result['count'] == 0) {
        // Sample missing persons data - base cases
        $baseCases = [
            ['first_name' => 'John', 'last_name' => 'Doe', 'age' => 25, 'gender' => 'male', 'last_seen_date' => '2024-01-15', 'last_seen_location' => 'New York, NY', 'circumstances' => 'Last seen walking home from work', 'distinctive_features' => 'Tattoo on left arm', 'reporter_name' => 'Jane Doe', 'reporter_relationship' => 'Wife', 'reporter_phone' => '555-1234', 'reporter_email' => 'jane@example.com'],
            ['first_name' => 'Emily', 'last_name' => 'Smith', 'age' => 12, 'gender' => 'female', 'last_seen_date' => '2024-01-20', 'last_seen_location' => 'Los Angeles, CA', 'circumstances' => 'Disappeared after school', 'distinctive_features' => 'Red hair, freckles', 'reporter_name' => 'Michael Smith', 'reporter_relationship' => 'Father', 'reporter_phone' => '555-5678', 'reporter_email' => 'michael@example.com'],
            ['first_name' => 'Robert', 'last_name' => 'Johnson', 'age' => 45, 'gender' => 'male', 'last_seen_date' => '2024-01-10', 'last_seen_location' => 'Chicago, IL', 'circumstances' => 'Left home for grocery shopping', 'distinctive_features' => 'Glasses, beard', 'reporter_name' => 'Sarah Johnson', 'reporter_relationship' => 'Wife', 'reporter_phone' => '555-9012', 'reporter_email' => 'sarah@example.com'],
            ['first_name' => 'Anna', 'last_name' => 'Williams', 'age' => 8, 'gender' => 'female', 'last_seen_date' => '2024-01-18', 'last_seen_location' => 'Houston, TX', 'circumstances' => 'Playing in park, not returned', 'distinctive_features' => 'Pink backpack', 'reporter_name' => 'David Williams', 'reporter_relationship' => 'Father', 'reporter_phone' => '555-3456', 'reporter_email' => 'david@example.com'],
            ['first_name' => 'Michael', 'last_name' => 'Brown', 'age' => 30, 'gender' => 'male', 'last_seen_date' => '2024-01-12', 'last_seen_location' => 'Phoenix, AZ', 'circumstances' => 'Hiking trip', 'distinctive_features' => 'Blue jacket', 'reporter_name' => 'Lisa Brown', 'reporter_relationship' => 'Sister', 'reporter_phone' => '555-7890', 'reporter_email' => 'lisa@example.com'],
            ['first_name' => 'Sophia', 'last_name' => 'Davis', 'age' => 16, 'gender' => 'female', 'last_seen_date' => '2024-01-22', 'last_seen_location' => 'Philadelphia, PA', 'circumstances' => 'After school activity', 'distinctive_features' => 'Braces', 'reporter_name' => 'James Davis', 'reporter_relationship' => 'Father', 'reporter_phone' => '555-1111', 'reporter_email' => 'james@example.com'],
            ['first_name' => 'Daniel', 'last_name' => 'Garcia', 'age' => 50, 'gender' => 'male', 'last_seen_date' => '2024-01-08', 'last_seen_location' => 'San Antonio, TX', 'circumstances' => 'Business trip', 'distinctive_features' => 'Suitcase', 'reporter_name' => 'Maria Garcia', 'reporter_relationship' => 'Wife', 'reporter_phone' => '555-2222', 'reporter_email' => 'maria@example.com'],
            ['first_name' => 'Olivia', 'last_name' => 'Martinez', 'age' => 22, 'gender' => 'female', 'last_seen_date' => '2024-01-25', 'last_seen_location' => 'San Diego, CA', 'circumstances' => 'Night out with friends', 'distinctive_features' => 'Black dress', 'reporter_name' => 'Carlos Martinez', 'reporter_relationship' => 'Brother', 'reporter_phone' => '555-3333', 'reporter_email' => 'carlos@example.com'],
            ['first_name' => 'William', 'last_name' => 'Lopez', 'age' => 35, 'gender' => 'male', 'last_seen_date' => '2024-01-14', 'last_seen_location' => 'Dallas, TX', 'circumstances' => 'Construction site', 'distinctive_features' => 'Hard hat', 'reporter_name' => 'Elena Lopez', 'reporter_relationship' => 'Wife', 'reporter_phone' => '555-4444', 'reporter_email' => 'elena@example.com'],
            ['first_name' => 'Isabella', 'last_name' => 'Gonzalez', 'age' => 10, 'gender' => 'female', 'last_seen_date' => '2024-01-19', 'last_seen_location' => 'San Jose, CA', 'circumstances' => 'School bus stop', 'distinctive_features' => 'Pigtails', 'reporter_name' => 'Jose Gonzalez', 'reporter_relationship' => 'Father', 'reporter_phone' => '555-5555', 'reporter_email' => 'jose@example.com'],
        ];

        // Generate more cases to reach over 1247
        $firstNames = ['James', 'Mary', 'Patricia', 'Jennifer', 'Linda', 'Elizabeth', 'Barbara', 'Susan', 'Margaret', 'Dorothy', 'Lisa', 'Nancy', 'Karen', 'Betty', 'Helen', 'Sandra', 'Donna', 'Carol', 'Ruth', 'Sharon'];
        $lastNames = ['Anderson', 'Thompson', 'Martinez', 'Rodriguez', 'Lewis', 'Lee', 'Walker', 'Hall', 'Allen', 'Young', 'Hernandez', 'King', 'Wright', 'Lopez', 'Hill', 'Scott', 'Green', 'Adams', 'Baker', 'Nelson'];
        $cities = ['Seattle, WA', 'Denver, CO', 'Boston, MA', 'Nashville, TN', 'Atlanta, GA', 'Miami, FL', 'Portland, OR', 'Austin, TX', 'Las Vegas, NV', 'Charlotte, NC', 'Detroit, MI', 'Salt Lake City, UT', 'Raleigh, NC', 'Columbus, OH', 'Milwaukee, WI', 'Oklahoma City, OK', 'Albuquerque, NM', 'Colorado Springs, CO', 'Wichita, KS', 'Arlington, TX'];
        $genders = ['male', 'female'];
        $relationships = ['Parent', 'Spouse', 'Sibling', 'Friend', 'Relative'];

        $sampleCases = $baseCases;

        // Add generated cases to reach 1250+
        for ($i = 11; $i <= 1250; $i++) {
            $firstName = $firstNames[array_rand($firstNames)];
            $lastName = $lastNames[array_rand($lastNames)];
            $age = rand(5, 80);
            $gender = $genders[array_rand($genders)];
            $lastSeenDate = date('Y-m-d', strtotime('-' . rand(1, 365) . ' days'));
            $location = $cities[array_rand($cities)];
            $circumstances = 'Last seen in ' . $location;
            $features = ['None', 'Glasses', 'Tattoo', 'Scar', 'Birthmark'][array_rand(['None', 'Glasses', 'Tattoo', 'Scar', 'Birthmark'])];
            $reporterName = $firstNames[array_rand($firstNames)] . ' ' . $lastNames[array_rand($lastNames)];
            $relationship = $relationships[array_rand($relationships)];
            $phone = '555-' . str_pad(rand(0, 9999), 4, '0', STR_PAD_LEFT);
            $email = strtolower($firstName . '.' . $lastName . '@example.com');

            $sampleCases[] = [
                'first_name' => $firstName,
                'last_name' => $lastName,
                'age' => $age,
                'gender' => $gender,
                'last_seen_date' => $lastSeenDate,
                'last_seen_location' => $location,
                'circumstances' => $circumstances,
                'distinctive_features' => $features,
                'reporter_name' => $reporterName,
                'reporter_relationship' => $relationship,
                'reporter_phone' => $phone,
                'reporter_email' => $email
            ];
        }

        // Insert sample cases
        $insertStmt = $pdo->prepare("INSERT INTO missing_persons (case_id, first_name, last_name, age, gender, last_seen_date, last_seen_location, circumstances, distinctive_features, reporter_name, reporter_relationship, reporter_phone, reporter_email) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        foreach ($sampleCases as $index => $case) {
            $caseId = 'FT' . str_pad($index + 1, 4, '0', STR_PAD_LEFT);
            $insertStmt->execute([$caseId, $case['first_name'], $case['last_name'], $case['age'], $case['gender'], $case['last_seen_date'], $case['last_seen_location'], $case['circumstances'], $case['distinctive_features'], $case['reporter_name'], $case['reporter_relationship'], $case['reporter_phone'], $case['reporter_email']]);
        }
    }

} catch (PDOException $e) {
    die("Table creation or data insertion failed: " . $e->getMessage());
}
?>
