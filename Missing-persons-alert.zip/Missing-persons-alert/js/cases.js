// Cases JavaScript for Missing Persons Alert Website

document.addEventListener('DOMContentLoaded', function() {
    initCasesPage();
    initFilters();
    loadCases();
    initSearch();
    initStatsCounter();
});

// Global variables
let currentPage = 1;
let isLoadingMore = false;
let hasMoreCases = true;
let map = null;
let markers = [];
let caseCardsObserver = null;

// Initialize Load More
function initLoadMore() {
    currentPage = 1;
    isLoadingMore = false;
    hasMoreCases = true;
}

// Initialize Cases Page
function initCasesPage() {
    checkAuthStatus();
    initViewToggle();
    initLoadMore();
    observeCaseCards();
}

// Initialize Filters
function initFilters() {
    const filterSelects = document.querySelectorAll('.filter-select');
    filterSelects.forEach(function(select) {
        select.addEventListener('change', applyFilters);
    });

    const savedFilters = localStorage.getItem('findthem_filters');
    if (savedFilters) {
        try {
            const filters = JSON.parse(savedFilters);
            Object.keys(filters).forEach(function(key) {
                const element = document.getElementById(key);
                if (element) element.value = filters[key];
            });
        } catch (e) {
            console.error('Error loading saved filters:', e);
        }
    }
}

// Toggle Filters Panel
function toggleFilters() {
    const filtersPanel = document.getElementById('filtersPanel');
    if (!filtersPanel) return;

    const isVisible = filtersPanel.classList.contains('show');
    if (isVisible) {
        filtersPanel.classList.remove('show');
        filtersPanel.style.display = 'none';
    } else {
        filtersPanel.classList.add('show');
        filtersPanel.style.display = 'block';
    }
}

// Apply Filters
function applyFilters() {
    const filters = {
        locationFilter: (document.getElementById('locationFilter') && document.getElementById('locationFilter').value) || '',
        statusFilter: (document.getElementById('statusFilter') && document.getElementById('statusFilter').value) || '',
        ageFilter: (document.getElementById('ageFilter') && document.getElementById('ageFilter').value) || '',
        genderFilter: (document.getElementById('genderFilter') && document.getElementById('genderFilter').value) || '',
        timeFilter: (document.getElementById('timeFilter') && document.getElementById('timeFilter').value) || '',
        sortFilter: (document.getElementById('sortFilter') && document.getElementById('sortFilter').value) || 'recent'
    };

    localStorage.setItem('findthem_filters', JSON.stringify(filters));
    initLoadMore();
    loadCases(filters);
}

// Apply Quick Filter
function applyQuickFilter(filterType, event) {
    document.querySelectorAll('.filter-tag').forEach(function(tag) {
        tag.classList.remove('active');
    });

    if (event && event.target) {
        event.target.classList.add('active');
    }

    let filters = {};
    switch (filterType) {
        case 'critical':
            filters.statusFilter = 'critical';
            break;
        case 'children':
            filters.ageFilter = 'child';
            break;
        case '24h':
            filters.timeFilter = 'today';
            break;
    }

    Object.keys(filters).forEach(function(key) {
        const element = document.getElementById(key);
        if (element) element.value = filters[key];
    });

    initLoadMore();
    loadCases(filters);
}

// Reset All Filters
function resetFilters() {
    document.querySelectorAll('.filter-select').forEach(function(select) {
        select.value = '';
    });

    document.querySelectorAll('.filter-tag').forEach(function(tag) {
        tag.classList.remove('active');
    });

    const sortFilter = document.getElementById('sortFilter');
    if (sortFilter) sortFilter.value = 'recent';

    localStorage.removeItem('findthem_filters');
    initLoadMore();
    loadCases();
}

// Load Cases
async function loadCases(filters) {
    filters = filters || {};

    const casesContainer = document.getElementById('casesContainer');
    const loadingIndicator = document.getElementById('casesLoading');
    const noResults = document.getElementById('noResults');
    const loadMoreSection = document.getElementById('loadMoreSection');

    if (!casesContainer) return;

    if (currentPage === 1) {
        casesContainer.innerHTML = '';
        if (loadingIndicator) loadingIndicator.classList.add('show');
        if (noResults) noResults.classList.remove('show');
    }

    try {
        const viewMode = localStorage.getItem('findthem_view_mode') || 'grid';
        const cases = await fetchCases(Object.assign({}, filters, { page: currentPage, limit: 6 }));

        if (loadingIndicator) loadingIndicator.classList.remove('show');

        if (!cases || cases.length === 0) {
            if (currentPage === 1) {
                if (noResults) noResults.classList.add('show');
                if (loadMoreSection) loadMoreSection.style.display = 'none';
            }
            return;
        }

        if (cases.length < 6) {
            hasMoreCases = false;
            if (loadMoreSection) loadMoreSection.style.display = 'none';
        } else {
            if (loadMoreSection) loadMoreSection.style.display = 'block';
        }

        cases.forEach(function(caseData, index) {
            const caseCard = createCaseCard(caseData, viewMode, (currentPage - 1) * 6 + index);
            if (caseCard) casesContainer.appendChild(caseCard);
        });

        // Observe newly added case cards
        if (caseCardsObserver) {
            const newCards = casesContainer.querySelectorAll('.case-card:not(.observed)');
            newCards.forEach(function(card) {
                card.classList.add('observed');
                caseCardsObserver.observe(card);
            });
        }

    } catch (error) {
        console.error('Error loading cases:', error);
        if (loadingIndicator) loadingIndicator.classList.remove('show');
        showAlert('Failed to load cases. Please try again.', 'error');
    }
}

// Load More Cases
async function loadMoreCases() {
    if (isLoadingMore || !hasMoreCases) return;

    isLoadingMore = true;
    const loadMoreBtn = document.getElementById('loadMoreBtn');
    const loadMoreLoading = document.getElementById('loadMoreLoading');

    if (loadMoreBtn) loadMoreBtn.style.display = 'none';
    if (loadMoreLoading) loadMoreLoading.style.display = 'block';

    currentPage++;

    try {
        const filters = getCurrentFilters();
        await loadCases(Object.assign({}, filters, { page: currentPage }));
    } catch (error) {
        console.error('Error loading more cases:', error);
        showAlert('Failed to load more cases. Please try again.', 'error');
    } finally {
        if (loadMoreBtn) loadMoreBtn.style.display = 'block';
        if (loadMoreLoading) loadMoreLoading.style.display = 'none';
        isLoadingMore = false;
    }
}

// Fetch Cases from API
async function fetchCases(filters) {
    filters = filters || {};

    try {
        var queryParams = new URLSearchParams();

        var paramMapping = {
            locationFilter: 'location',
            statusFilter: 'status',
            ageFilter: 'age',
            genderFilter: 'gender',
            timeFilter: 'time',
            sortFilter: 'sort'
        };

        Object.keys(filters).forEach(function(key) {
            if (filters[key] !== '' && filters[key] !== null && filters[key] !== undefined) {
                var phpParamName = paramMapping[key] || key;
                queryParams.append(phpParamName, filters[key]);
            }
        });

        var response = await fetch('../api/cases.php?' + queryParams.toString());
        var data = await response.json();

        if (data.success && data.cases) {
            return data.cases;
        } else {
            console.error('API Error:', data.error || 'Unknown error');
            return [];
        }
    } catch (error) {
        console.error('Fetch error:', error);
        return getMockCases(filters);
    }
}

// Get Mock Cases
function getMockCases(filters) {
    filters = filters || {};

    var mockCases = [
        { id: 1, name: 'John Doe', age: 25, location: 'New York, NY', timeAgo: '2 days ago', description: 'Last seen walking home from work.', status: 'active', gender: 'male', category: 'adult', tags: ['urgent'], imageColor: '#e0f2fe', latitude: 40.7128, longitude: -74.0060 },
        { id: 2, name: 'Emily Smith', age: 12, location: 'Los Angeles, CA', timeAgo: '1 day ago', description: 'Disappeared after school.', status: 'active', gender: 'female', category: 'child', tags: ['child', 'urgent'], imageColor: '#dcfce7', latitude: 34.0522, longitude: -118.2437 },
        { id: 3, name: 'Robert Johnson', age: 45, location: 'Chicago, IL', timeAgo: '3 days ago', description: 'Left home for grocery shopping.', status: 'active', gender: 'male', category: 'adult', tags: ['urgent'], imageColor: '#fef3c7', latitude: 41.8781, longitude: -87.6298 },
        { id: 4, name: 'Anna Williams', age: 8, location: 'Houston, TX', timeAgo: '5 hours ago', description: 'Playing in park, not returned.', status: 'active', gender: 'female', category: 'child', tags: ['child', 'urgent'], imageColor: '#e0e7ff', latitude: 29.7604, longitude: -95.3698 },
        { id: 5, name: 'Michael Brown', age: 30, location: 'Phoenix, AZ', timeAgo: '1 week ago', description: 'Hiking trip in desert area.', status: 'active', gender: 'male', category: 'adult', tags: ['medical'], imageColor: '#fce7f3', latitude: 33.4484, longitude: -112.0740 },
        { id: 6, name: 'Sophia Davis', age: 16, location: 'Philadelphia, PA', timeAgo: '2 days ago', description: 'After school activity.', status: 'active', gender: 'female', category: 'teen', tags: ['urgent'], imageColor: '#e0f2fe', latitude: 39.9526, longitude: -75.1652 }
    ];

    var filteredCases = mockCases;

    if (filters.search) {
        var searchTerm = filters.search.toLowerCase();
        filteredCases = filteredCases.filter(function(caseData) {
            return caseData.name.toLowerCase().indexOf(searchTerm) !== -1 ||
                caseData.location.toLowerCase().indexOf(searchTerm) !== -1 ||
                caseData.description.toLowerCase().indexOf(searchTerm) !== -1;
        });
    }

    if (filters.locationFilter) {
        filteredCases = filteredCases.filter(function(caseData) {
            return caseData.location.toLowerCase().indexOf(filters.locationFilter.toLowerCase()) !== -1;
        });
    }

    if (filters.statusFilter) {
        if (filters.statusFilter === 'active') {
            filteredCases = filteredCases.filter(function(caseData) { return caseData.status === 'active'; });
        } else if (filters.statusFilter === 'critical') {
            filteredCases = filteredCases.filter(function(caseData) {
                return caseData.tags.indexOf('urgent') !== -1 && caseData.age < 18;
            });
        }
    }

    if (filters.ageFilter) {
        switch (filters.ageFilter) {
            case 'child':
                filteredCases = filteredCases.filter(function(caseData) { return caseData.age >= 0 && caseData.age <= 12; });
                break;
            case 'teen':
                filteredCases = filteredCases.filter(function(caseData) { return caseData.age >= 13 && caseData.age <= 17; });
                break;
            case 'adult':
                filteredCases = filteredCases.filter(function(caseData) { return caseData.age >= 18 && caseData.age <= 59; });
                break;
            case 'senior':
                filteredCases = filteredCases.filter(function(caseData) { return caseData.age >= 60; });
                break;
        }
    }

    if (filters.genderFilter) {
        filteredCases = filteredCases.filter(function(caseData) { return caseData.gender === filters.genderFilter; });
    }

    var page = filters.page || 1;
    var limit = filters.limit || 6;
    var offset = (page - 1) * limit;

    return filteredCases.slice(offset, offset + limit);
}

// Create Case Card
function createCaseCard(caseData, viewMode, index) {
    if (!caseData) return null;

    viewMode = viewMode || 'grid';
    index = index || 0;

    var card = document.createElement('div');
    card.className = 'case-card ' + viewMode + '-view fade-in';
    card.style.animationDelay = (index * 0.1) + 's';

    var tagsHtml = '';
    if (caseData.tags && caseData.tags.length) {
        tagsHtml = caseData.tags.map(function(tag) {
            var className = 'tag';
            if (tag === 'amber' || tag === 'child') className += ' ' + tag;
            return '<span class="' + className + '">' + tag + '</span>';
        }).join('');
    }

    var caseId = caseData.id || '';
    var caseName = encodeURIComponent(caseData.name || '');
    var caseAge = caseData.age || '';
    var caseLocation = encodeURIComponent(caseData.location || '');

    if (viewMode === 'grid') {
        card.innerHTML =
            '<div class="case-image" style="background:' + (caseData.imageColor || '#e0f2fe') + '">' +
            '<i class="fas fa-user-circle"></i>' +
            '<span class="case-status ' + (caseData.status || 'active') + '">' + (caseData.status || 'active') + '</span>' +
            '</div>' +
            '<div class="case-content">' +
            '<div class="case-meta">' +
            '<span class="case-location"><i class="fas fa-map-marker-alt"></i> ' + (caseData.location || '') + '</span>' +
            '<span class="case-time"><i class="far fa-clock"></i> ' + (caseData.timeAgo || '') + '</span>' +
            '</div>' +
            '<h3 class="case-name">' + (caseData.name || 'Unknown') + '</h3>' +
            '<div class="case-age">' + (caseData.age || '') + ' years old</div>' +
            '<p class="case-details">' + (caseData.description || '') + '</p>' +
            '<div class="case-tags">' + tagsHtml + '</div>' +
            '<div class="case-actions">' +
            '<a href="case-details.html?id=' + caseId + '&name=' + caseName + '&age=' + caseAge + '&location=' + caseLocation + '" class="btn btn-primary btn-view">' +
            '<i class="fas fa-info-circle"></i> View Details' +
            '</a>' +
            '<button class="btn-share" onclick="shareCase(' + caseId + ')">' +
            '<i class="fas fa-share-alt"></i>' +
            '</button>' +
            '</div>' +
            '</div>';
    } else {
        card.innerHTML =
            '<div class="case-image" style="background:' + (caseData.imageColor || '#e0f2fe') + '">' +
            '<i class="fas fa-user-circle"></i>' +
            '</div>' +
            '<div class="case-content">' +
            '<div class="case-meta">' +
            '<span class="case-location"><i class="fas fa-map-marker-alt"></i> ' + (caseData.location || '') + '</span>' +
            '<span class="case-time"><i class="far fa-clock"></i> ' + (caseData.timeAgo || '') + '</span>' +
            '</div>' +
            '<h3 class="case-name">' + (caseData.name || 'Unknown') + ', ' + (caseData.age || '') + '</h3>' +
            '<span class="case-status ' + (caseData.status || 'active') + '">' + (caseData.status || 'active') + '</span>' +
            '<p class="case-details">' + (caseData.description || '') + '</p>' +
            '<div class="case-tags">' + tagsHtml + '</div>' +
            '</div>' +
            '<div class="case-actions">' +
            '<a href="case-details.html?id=' + caseId + '&name=' + caseName + '&age=' + caseAge + '&location=' + caseLocation + '" class="btn btn-primary">' +
            '<i class="fas fa-info-circle"></i> Details' +
            '</a>' +
            '<button class="btn btn-outline" onclick="shareCase(' + caseId + ')">' +
            '<i class="fas fa-share-alt"></i> Share' +
            '</button>' +
            '</div>';
    }

    return card;
}

// Initialize View Toggle
function initViewToggle() {
    var viewMode = localStorage.getItem('findthem_view_mode') || 'grid';
    changeView(viewMode);
}

// Change View Mode
function changeView(mode) {
    var viewOptions = document.querySelectorAll('.view-option');
    viewOptions.forEach(function(btn) {
        btn.classList.remove('active');
        if (btn.textContent.toLowerCase().indexOf(mode) !== -1) {
            btn.classList.add('active');
        }
    });

    localStorage.setItem('findthem_view_mode', mode);

    var casesContainer = document.getElementById('casesContainer');
    var mapView = document.getElementById('mapView');

    if (!casesContainer || !mapView) return;

    if (mode === 'map') {
        casesContainer.style.display = 'none';
        mapView.style.display = 'block';

        setTimeout(function() {
            if (!map) {
                initMap();
            } else {
                map.invalidateSize();
                updateMap();
            }
        }, 100);
    } else {
        casesContainer.style.display = 'block';
        mapView.style.display = 'none';
        casesContainer.className = 'cases-container ' + mode + '-view';
        loadCases();
    }
}

// Initialize Map
function initMap() {
    var mapElement = document.getElementById('casesMap');
    if (!mapElement) return;
    if (typeof L === 'undefined') return;

    map = L.map('casesMap').setView([39.8283, -98.5795], 4);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 18
    }).addTo(map);

    loadCasesForMap();
}

// Update Map
function updateMap() {
    if (!map) return;
    markers.forEach(function(marker) { map.removeLayer(marker); });
    markers = [];
    loadCasesForMap();
}

// Load Cases for Map
async function loadCasesForMap() {
    if (!map) return;
    try {
        var filters = getCurrentFilters();
        var cases = await fetchCases(Object.assign({}, filters, { page: 1, limit: 100 }));

        cases.forEach(function(caseData) {
            if (caseData.latitude && caseData.longitude) {
                addCaseMarker(caseData);
            }
        });

        if (markers.length > 0) {
            var group = new L.featureGroup(markers);
            map.fitBounds(group.getBounds().pad(0.1));
        }
    } catch (error) {
        console.error('Error loading cases for map:', error);
    }
}

// Add Case Marker
function addCaseMarker(caseData) {
    if (!map) return;

    var markerColor = '#3b82f6';
    if (caseData.tags && caseData.tags.indexOf('urgent') !== -1) {
        markerColor = '#ef4444';
    } else if (caseData.age < 18) {
        markerColor = '#f97316';
    }

    var icon = L.divIcon({
        className: 'custom-marker',
        html: '<div style="background-color:' + markerColor + ';width:20px;height:20px;border-radius:50%;border:2px solid white;box-shadow:0 2px 4px rgba(0,0,0,0.2);"></div>',
        iconSize: [20, 20],
        iconAnchor: [10, 10]
    });

    var marker = L.marker([caseData.latitude, caseData.longitude], { icon: icon });

    var popupContent =
        '<div class="map-popup">' +
        '<h4>' + caseData.name + '</h4>' +
        '<p><strong>Age:</strong> ' + caseData.age + '</p>' +
        '<p><strong>Location:</strong> ' + caseData.location + '</p>' +
        '<p><strong>Missing:</strong> ' + caseData.timeAgo + '</p>' +
        '<p>' + caseData.description + '</p>' +
        '<a href="case-details.html?id=' + caseData.id + '&name=' + encodeURIComponent(caseData.name) + '&age=' + caseData.age + '&location=' + encodeURIComponent(caseData.location) + '" class="btn btn-primary btn-sm">View Details</a>' +
        '</div>';

    marker.bindPopup(popupContent);
    marker.addTo(map);
    markers.push(marker);
}

// Load Real Map
function loadRealMap() {
    if (!map) {
        initMap();
    } else {
        updateMap();
    }
}

// Initialize Search
function initSearch() {
    var searchInput = document.getElementById('globalSearch');
    if (!searchInput) return;

    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            performSearch();
        }
    });
}

// Perform Search
function performSearch() {
    var searchInput = document.getElementById('globalSearch');
    if (!searchInput) return;

    var searchTerm = searchInput.value.trim();
    if (searchTerm) {
        var filters = { search: searchTerm };
        Object.assign(filters, getCurrentFilters());
        loadCases(filters);
    }
}

// Clear Search
function clearSearch() {
    var searchInput = document.getElementById('globalSearch');
    if (searchInput) searchInput.value = '';
    loadCases();
}

// Get Current Filters
function getCurrentFilters() {
    return {
        locationFilter: document.getElementById('locationFilter') ? document.getElementById('locationFilter').value : '',
        statusFilter: document.getElementById('statusFilter') ? document.getElementById('statusFilter').value : '',
        ageFilter: document.getElementById('ageFilter') ? document.getElementById('ageFilter').value : '',
        genderFilter: document.getElementById('genderFilter') ? document.getElementById('genderFilter').value : '',
        timeFilter: document.getElementById('timeFilter') ? document.getElementById('timeFilter').value : '',
        sortFilter: document.getElementById('sortFilter') ? document.getElementById('sortFilter').value : 'recent'
    };
}

// Initialize Stats Counter
function initStatsCounter() {
    var stats = {
        totalCases: document.getElementById('totalCases'),
        casesThisMonth: document.getElementById('casesThisMonth'),
        casesThisWeek: document.getElementById('casesThisWeek')
    };

    var targetValues = {
        totalCases: 1247,
        casesThisMonth: 89,
        casesThisWeek: 23
    };

    Object.keys(stats).forEach(function(key) {
        if (stats[key]) {
            animateCounter(stats[key], targetValues[key]);
        }
    });
}

// Animate Counter
function animateCounter(element, target) {
    var duration = 1500;
    var step = target / (duration / 16);
    var current = 0;

    var timer = setInterval(function() {
        current += step;
        if (current >= target) {
            element.textContent = formatNumber(target);
            clearInterval(timer);
        } else {
            element.textContent = formatNumber(Math.floor(current));
        }
    }, 16);
}

// Format Number
function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// Observe Case Cards
function observeCaseCards() {
    caseCardsObserver = new IntersectionObserver(function(entries) {
        entries.forEach(function(entry) {
            if (entry.isIntersecting) {
                entry.target.classList.add('animated');
            }
        });
    }, { threshold: 0.1 });

    // Observe existing case cards
    var existingCards = document.querySelectorAll('.case-card');
    existingCards.forEach(function(card) {
        card.classList.add('observed');
        caseCardsObserver.observe(card);
    });
}

// Open Advanced Search
function openAdvancedSearch() {
    var modal = document.getElementById('advancedSearchModal');
    if (modal) {
        modal.classList.add('show');
        modal.style.display = 'flex';
    }
}

// Close Advanced Search
function closeAdvancedSearch() {
    var modal = document.getElementById('advancedSearchModal');
    if (modal) {
        modal.classList.remove('show');
        setTimeout(function() {
            modal.style.display = 'none';
        }, 300);
    }
}

// Share Case
function shareCase(caseId) {
    if (navigator.share) {
        navigator.share({
                title: 'Missing Person Alert',
                text: 'Help find this missing person',
                url: window.location.origin + '/cases/case-details.html?id=' + caseId
            }).then(function() { console.log('Successfully shared'); })
            .catch(function(error) { console.log('Error sharing:', error); });
    } else {
        var url = window.location.origin + '/cases/case-details.html?id=' + caseId;
        navigator.clipboard.writeText(url).then(function() {
            showAlert('Case link copied to clipboard!', 'success');
        }).catch(function(err) {
            console.error('Failed to copy:', err);
            showAlert('Failed to share. Please copy the URL manually.', 'error');
        });
    }
}

// Show Alert
function showAlert(message, type) {
    type = type || 'info';

    var existingAlert = document.querySelector('.alert-message');
    if (existingAlert) existingAlert.remove();

    var alert = document.createElement('div');
    alert.className = 'alert-message alert-' + type;

    var icon = 'info-circle';
    if (type === 'success') icon = 'check-circle';
    if (type === 'error') icon = 'exclamation-circle';
    if (type === 'warning') icon = 'exclamation-triangle';

    alert.innerHTML = '<i class="fas fa-' + icon + '"></i><span>' + message + '</span><button class="alert-close" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>';

    alert.style.cssText = 'position:fixed;top:20px;right:20px;padding:1rem 1.5rem;border-radius:var(--border-radius);display:flex;align-items:center;gap:10px;box-shadow:var(--box-shadow);z-index:10000;max-width:400px;animation:slideInRight 0.3s ease-out;';

    var colors = {
        success: { bg: '#d1fae5', text: '#065f46', border: '#a7f3d0' },
        error: { bg: '#fee2e2', text: '#991b1b', border: '#fecaca' },
        warning: { bg: '#fef3c7', text: '#92400e', border: '#fde68a' },
        info: { bg: '#dbeafe', text: '#1e40af', border: '#bfdbfe' }
    };

    alert.style.background = colors[type].bg;
    alert.style.color = colors[type].text;
    alert.style.border = '1px solid ' + colors[type].border;

    document.body.appendChild(alert);

    setTimeout(function() {
        if (alert.parentElement) {
            alert.style.animation = 'fadeOut 0.3s ease-out';
            setTimeout(function() { alert.remove(); }, 300);
        }
    }, 5000);
}

// Check Auth Status
function checkAuthStatus() {
    var user = localStorage.getItem('findthem_user');
    var loginBtn = document.querySelector('.btn-login');
    var registerBtn = document.querySelector('.btn-register');

    if (user && loginBtn && registerBtn) {
        var userData = JSON.parse(user);
        loginBtn.innerHTML = '<i class="fas fa-user-circle"></i> ' + userData.name.split(' ')[0];
        loginBtn.href = '../dashboard/index.html';
        registerBtn.innerHTML = '<i class="fas fa-sign-out-alt"></i> Logout';
        registerBtn.onclick = function(e) {
            e.preventDefault();
            logout();
        };
    }
}

// Logout
function logout() {
    localStorage.removeItem('findthem_user');
    localStorage.removeItem('findthem_token');
    window.location.reload();
}

// Export functions
window.toggleFilters = toggleFilters;
window.applyFilters = applyFilters;
window.applyQuickFilter = applyQuickFilter;
window.resetFilters = resetFilters;
window.performSearch = performSearch;
window.clearSearch = clearSearch;
window.changeView = changeView;
window.shareCase = shareCase;
window.openAdvancedSearch = openAdvancedSearch;
window.closeAdvancedSearch = closeAdvancedSearch;
window.loadRealMap = loadRealMap;
window.loadMoreCases = loadMoreCases;