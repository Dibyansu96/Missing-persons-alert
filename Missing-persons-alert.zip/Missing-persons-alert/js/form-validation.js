// Form validation utilities for FindThem

// Validate report form
function validateReportForm() {
    const form = document.getElementById('reportForm');
    let isValid = true;
    let errors = [];

    // Clear previous errors
    clearFormErrors();

    // Required fields validation
    const requiredFields = [
        { id: 'firstName', name: 'First Name' },
        { id: 'lastName', name: 'Last Name' },
        { id: 'age', name: 'Age' },
        { id: 'gender', name: 'Gender' },
        { id: 'lastSeenDate', name: 'Date Last Seen' },
        { id: 'lastSeenLocation', name: 'Location Last Seen' },
        { id: 'circumstances', name: 'Circumstances' },
        { id: 'reporterName', name: 'Reporter Name' },
        { id: 'reporterRelationship', name: 'Relationship to Missing Person' },
        { id: 'reporterPhone', name: 'Reporter Phone' },
        { id: 'reporterEmail', name: 'Reporter Email' }
    ];

    requiredFields.forEach(field => {
        const element = document.getElementById(field.id);
        if (!element.value.trim()) {
            showFieldError(element, `${field.name} is required`);
            isValid = false;
            errors.push(`${field.name} is required`);
        }
    });

    // Age validation
    const age = document.getElementById('age').value;
    if (age && (age < 1 || age > 120)) {
        showFieldError(document.getElementById('age'), 'Age must be between 1 and 120');
        isValid = false;
        errors.push('Invalid age');
    }

    // Email validation
    const email = document.getElementById('reporterEmail').value;
    if (email && !isValidEmail(email)) {
        showFieldError(document.getElementById('reporterEmail'), 'Please enter a valid email address');
        isValid = false;
        errors.push('Invalid email');
    }

    // Phone validation
    const phone = document.getElementById('reporterPhone').value;
    if (phone && !isValidPhone(phone)) {
        showFieldError(document.getElementById('reporterPhone'), 'Please enter a valid phone number');
        isValid = false;
        errors.push('Invalid phone number');
    }

    // Date validation
    const lastSeenDate = document.getElementById('lastSeenDate').value;
    if (lastSeenDate) {
        const today = new Date();
        const selectedDate = new Date(lastSeenDate);
        if (selectedDate > today) {
            showFieldError(document.getElementById('lastSeenDate'), 'Date cannot be in the future');
            isValid = false;
            errors.push('Invalid date');
        }
    }

    // File validation
    const photos = document.getElementById('photos').files;
    if (photos.length > 5) {
        showFieldError(document.getElementById('photos'), 'Maximum 5 photos allowed');
        isValid = false;
        errors.push('Too many photos');
    }

    for (let i = 0; i < photos.length; i++) {
        if (photos[i].size > 5 * 1024 * 1024) { // 5MB
            showFieldError(document.getElementById('photos'), 'Each photo must be less than 5MB');
            isValid = false;
            errors.push('Photo too large');
            break;
        }
    }

    if (!isValid) {
        showFormMessage('Please correct the following errors:\n' + errors.join('\n'), 'error');
    }

    return isValid;
}

// Utility functions
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function isValidPhone(phone) {
    const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
    return phoneRegex.test(phone.replace(/[\s\-\(\)]/g, ''));
}

function showFieldError(element, message) {
    element.classList.add('error');
    const errorElement = document.createElement('div');
    errorElement.className = 'field-error';
    errorElement.textContent = message;
    element.parentNode.appendChild(errorElement);
}

function clearFormErrors() {
    // Remove error classes
    document.querySelectorAll('.error').forEach(el => el.classList.remove('error'));

    // Remove error messages
    document.querySelectorAll('.field-error').forEach(el => el.remove());
}

function showFormMessage(message, type) {
    const messageEl = document.getElementById('formMessage');
    messageEl.textContent = message;
    messageEl.className = `form-message ${type}`;
    messageEl.style.display = 'block';
    messageEl.scrollIntoView({ behavior: 'smooth' });
}

function hideFormMessage() {
    const messageEl = document.getElementById('formMessage');
    if (messageEl) {
        messageEl.style.display = 'none';
    }
}

// General form validation for other forms
function validateForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return false;

    let isValid = true;
    const requiredFields = form.querySelectorAll('[required]');

    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            showFieldError(field, 'This field is required');
            isValid = false;
        }
    });

    return isValid;
}