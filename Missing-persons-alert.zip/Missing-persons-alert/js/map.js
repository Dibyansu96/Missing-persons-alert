// Map JavaScript for Missing Persons Alert Website

document.addEventListener('DOMContentLoaded', function() {
    // Initialize map when DOM is loaded
    initWorldMap();
});

// Global map variable for world map
let worldMap = null;

// Initialize World Map
function initWorldMap() {
    const mapElement = document.getElementById('worldMap');

    if (!mapElement) return;

    // Check if Leaflet is loaded
    if (typeof L !== 'undefined') {
        // Small delay to ensure container has proper dimensions
        setTimeout(function() {
            // Initialize real Leaflet map
            worldMap = L.map('worldMap').setView([20, 0], 2);

            // Add OpenStreetMap tiles
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors',
                maxZoom: 18,
            }).addTo(worldMap);

            // Load cases for map
            loadCasesForWorldMap(worldMap);

            // Add map controls
            addMapControls(worldMap);
        }, 100);

    } else {
        // Fallback: Create placeholder map
        createPlaceholderMap(mapElement);
    }
}

// Add Sample Markers
function addSampleMarkers(map) {
    const sampleCases = [{
            lat: 40.7128,
            lng: -74.0060,
            name: "Emma Johnson",
            location: "New York, USA",
            timeAgo: "2 hours ago",
            color: "#ff6b6b"
        },
        {
            lat: 43.6532,
            lng: -79.3832,
            name: "David Chen",
            location: "Toronto, Canada",
            timeAgo: "5 hours ago",
            color: "#ffa726"
        },
        {
            lat: 40.4168,
            lng: -3.7038,
            name: "Sophia Rodriguez",
            location: "Madrid, Spain",
            timeAgo: "1 day ago",
            color: "#42a5f5"
        },
        {
            lat: 25.2048,
            lng: 55.2708,
            name: "Mohammed Al-Farsi",
            location: "Dubai, UAE",
            timeAgo: "3 days ago",
            color: "#66bb6a"
        }
    ];

    sampleCases.forEach(function(caseData) {
        const marker = L.circleMarker([caseData.lat, caseData.lng], {
            color: caseData.color,
            fillColor: caseData.color,
            fillOpacity: 0.8,
            radius: 8
        }).addTo(map);

        marker.bindPopup(
            '<div class="map-popup">' +
            '<h4>' + caseData.name + '</h4>' +
            '<p><i class="fas fa-map-marker-alt"></i> ' + caseData.location + '</p>' +
            '<p><i class="far fa-clock"></i> ' + caseData.timeAgo + '</p>' +
            '<a href="cases/case-details.html?id=' + caseData.name.toLowerCase().replace(' ', '-') + '" class="btn btn-primary btn-small">View Details</a>' +
            '</div>'
        );
    });
}

// Add Map Controls
function addMapControls(map) {
    // Add layer control for different map views
    const baseLayers = {
        "OpenStreetMap": L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }),
        "Satellite": L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
            attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community'
        })
    };

    L.control.layers(baseLayers).addTo(map);

    // Add search control
    const searchControl = L.control({ position: 'topright' });
    searchControl.onAdd = function(map) {
        const div = L.DomUtil.create('div', 'map-search-control');
        div.innerHTML = '<div class="map-search">' +
            '<input type="text" placeholder="Search location..." id="mapSearchInput">' +
            '<button id="mapSearchBtn"><i class="fas fa-search"></i></button>' +
            '</div>';
        return div;
    };
    searchControl.addTo(map);

    // Add search functionality
    setTimeout(function() {
        const searchInput = document.getElementById('mapSearchInput');
        const searchBtn = document.getElementById('mapSearchBtn');

        if (searchBtn) {
            searchBtn.addEventListener('click', function() {
                const query = searchInput.value;
                if (query) {
                    searchLocation(query, map);
                }
            });
        }

        if (searchInput) {
            searchInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    const query = searchInput.value;
                    if (query) {
                        searchLocation(query, map);
                    }
                }
            });
        }
    }, 100);
}

// Search Location Function
function searchLocation(query, map) {
    // Predefined locations for demo
    const locations = {
        'new york': [40.7128, -74.0060],
        'london': [51.5074, -0.1278],
        'tokyo': [35.6762, 139.6503],
        'paris': [48.8566, 2.3522],
        'sydney': [-33.8688, 151.2093]
    };

    const location = locations[query.toLowerCase()];
    if (location) {
        map.setView(location, 10);
        L.popup()
            .setLatLng(location)
            .setContent('<b>' + query.charAt(0).toUpperCase() + query.slice(1) + '</b><br>Search results for missing persons in this area.')
            .openOn(map);
    } else {
        alert('Location not found. Try searching for major cities.');
    }
}

// Create Placeholder Map
function createPlaceholderMap(container) {
    container.innerHTML = '<div style="width:100%;height:100%;background:linear-gradient(135deg, #e0f2fe 0%, #bae6fd 100%);display:flex;align-items:center;justify-content:center;border-radius:8px;">' +
        '<div style="text-align:center;color:var(--primary-color);">' +
        '<i class="fas fa-globe-americas" style="font-size:4rem;margin-bottom:1rem;"></i>' +
        '<h3 style="color:var(--primary-color);">Interactive World Map</h3>' +
        '<p>Showing real-time missing person reports worldwide</p>' +
        '<div style="margin-top:1rem;">' +
        '<button onclick="refreshMap()" class="btn btn-primary btn-small">' +
        '<i class="fas fa-sync-alt"></i> Refresh Map' +
        '</button>' +
        '</div>' +
        '</div>' +
        '</div>';
}

// Refresh Map Function
function refreshMap() {
    const mapElement = document.getElementById('worldMap');
    if (mapElement) {
        // Add loading animation
        mapElement.innerHTML = '<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;">' +
            '<div class="loading-spinner"></div>' +
            '</div>';

        // Simulate refresh delay
        setTimeout(function() {
            initWorldMap();
        }, 1500);
    }
}

// Load Cases for World Map
async function loadCasesForWorldMap(map) {
    try {
        // Fetch cases from API (limit to reasonable number for map performance)
        const response = await fetch('../api/cases.php?page=1&limit=50');
        const data = await response.json();

        if (data.success && data.cases) {
            // Add markers for cases with coordinates
            data.cases.forEach(function(caseData) {
                if (caseData.latitude && caseData.longitude) {
                    addWorldMapMarker(map, caseData);
                }
            });
        } else {
            console.error('API Error:', data.error || 'Unknown error');
            // Fallback to sample markers
            addSampleMarkers(map);
        }
    } catch (error) {
        console.error('Error loading cases for world map:', error);
        // Fallback to sample markers
        addSampleMarkers(map);
    }
}

// Add World Map Marker
function addWorldMapMarker(map, caseData) {
    // Determine marker color based on case priority
    let markerColor = '#42a5f5'; // blue for normal cases
    if (caseData.tags && caseData.tags.includes('urgent')) {
        markerColor = '#ef4444'; // red for urgent
    } else if (caseData.age < 18) {
        markerColor = '#f97316'; // orange for children
    }

    const marker = L.circleMarker([caseData.latitude, caseData.longitude], {
        color: markerColor,
        fillColor: markerColor,
        fillOpacity: 0.8,
        radius: 8
    }).addTo(map);

    marker.bindPopup(
        '<div class="map-popup">' +
        '<h4>' + caseData.name + '</h4>' +
        '<p><i class="fas fa-map-marker-alt"></i> ' + caseData.location + '</p>' +
        '<p><i class="far fa-clock"></i> ' + caseData.timeAgo + '</p>' +
        '<a href="cases/case-details.html?id=' + caseData.id + '&name=' + encodeURIComponent(caseData.name) + '&age=' + caseData.age + '&location=' + encodeURIComponent(caseData.location) + '" class="btn btn-primary btn-small">View Details</a>' +
        '</div>'
    );
}

// Export functions for global use
window.refreshMap = refreshMap;
window.searchLocation = searchLocation;