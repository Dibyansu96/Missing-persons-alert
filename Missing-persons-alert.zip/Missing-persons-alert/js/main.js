// Main JavaScript for Missing Persons Alert Website

// DOM Ready
document.addEventListener('DOMContentLoaded', function() {
    // Initialize all components
    initMenuToggle();
    initStatsCounter();
    loadRecentCases();
    initMap();
    initEmergencyContacts();
    initAnimations();

    // Check if user is logged in
    checkAuthStatus();

    // Initialize tooltips
    initTooltips();
});

// Mobile Menu Toggle
function initMenuToggle() {
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');

    if (menuToggle && navLinks) {
        menuToggle.addEventListener('click', function() {
            navLinks.classList.toggle('active');
            menuToggle.innerHTML = navLinks.classList.contains('active') ?
                '<i class="fas fa-times"></i>' :
                '<i class="fas fa-bars"></i>';
        });

        // Close menu when clicking outside
        document.addEventListener('click', function(event) {
            if (!event.target.closest('.navbar')) {
                navLinks.classList.remove('active');
                menuToggle.innerHTML = '<i class="fas fa-bars"></i>';
            }
        });
    }
}

// Animated Statistics Counter
function initStatsCounter() {
    const statElements = {
        activeCases: document.getElementById('activeCases'),
        foundCases: document.getElementById('foundCases'),
        countries: document.getElementById('countries'),
        volunteers: document.getElementById('volunteers')
    };

    const targetValues = {
        activeCases: 1247,
        foundCases: 8952,
        countries: 124,
        volunteers: 5321
    };

    // Check if elements exist on current page
    if (statElements.activeCases) {
        Object.keys(statElements).forEach(key => {
            if (statElements[key]) {
                animateCounter(statElements[key], targetValues[key]);
            }
        });
    }
}

function animateCounter(element, target) {
    const duration = 2000; // 2 seconds
    const step = target / (duration / 16); // 60fps
    let current = 0;

    const timer = setInterval(() => {
        current += step;
        if (current >= target) {
            element.textContent = formatNumber(target);
            clearInterval(timer);
        } else {
            element.textContent = formatNumber(Math.floor(current));
        }
    }, 16);
}

function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

// Load Recent Cases
function loadRecentCases() {
    const casesContainer = document.getElementById('recentCases');

    if (!casesContainer) return;

    // Sample case data (in real app, this would come from an API)
    const cases = [{
            id: 1,
            name: "Emma Johnson",
            age: 28,
            location: "New York, USA",
            timeAgo: "2 hours ago",
            description: "Last seen wearing blue jeans and white t-shirt near Central Park.",
            imageColor: "#e0f2fe",
            tags: ["Female", "Adult", "24-48 hours"]
        },
        {
            id: 2,
            name: "David Chen",
            age: 45,
            location: "Toronto, Canada",
            timeAgo: "5 hours ago",
            description: "Missing after not returning from evening walk. Has medical condition.",
            imageColor: "#dcfce7",
            tags: ["Male", "Senior", "Medical Alert"]
        },
        {
            id: 3,
            name: "Sophia Rodriguez",
            age: 16,
            location: "Madrid, Spain",
            timeAgo: "1 day ago",
            description: "Student missing after school. Last seen near city center.",
            imageColor: "#fef3c7",
            tags: ["Teen", "Student", "Amber Alert"]
        },
        {
            id: 4,
            name: "Mohammed Al-Farsi",
            age: 32,
            location: "Dubai, UAE",
            timeAgo: "3 days ago",
            description: "Tourist missing from hotel. Family concerned for his safety.",
            imageColor: "#e0e7ff",
            tags: ["Tourist", "International", "3+ days"]
        }
    ];

    // Clear loading state
    casesContainer.innerHTML = '';

    // Create case cards
    cases.forEach((caseData, index) => {
        const caseCard = createCaseCard(caseData, index);
        casesContainer.appendChild(caseCard);
    });
}

function createCaseCard(caseData, index) {
    const card = document.createElement('div');
    card.className = 'case-card fade-in';
    card.style.animationDelay = `${index * 0.1}s`;

    card.innerHTML = `
        <div class="case-image" style="background: ${caseData.imageColor}">
            <i class="fas fa-user-circle"></i>
        </div>
        <div class="case-content">
            <div class="case-meta">
                <span class="case-location"><i class="fas fa-map-marker-alt"></i> ${caseData.location}</span>
                <span class="case-time"><i class="far fa-clock"></i> ${caseData.timeAgo}</span>
            </div>
            <h3 class="case-name">${caseData.name}, ${caseData.age}</h3>
            <p class="case-details">${caseData.description}</p>
            <div class="case-tags">
                ${caseData.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
            </div>
            <div class="case-actions">
                <a href="cases/case-details.html?id=${caseData.id}" class="btn btn-primary">
                    <i class="fas fa-info-circle"></i> View Details
                </a>
                <button class="btn btn-outline" onclick="shareCase(${caseData.id})">
                    <i class="fas fa-share-alt"></i> Share
                </button>
            </div>
        </div>
    `;
    
    return card;
}

// Initialize Map
function initMap() {
    const mapElement = document.getElementById('worldMap');
    
    if (!mapElement) return;
    
    // Create a simple map visualization (in real app, use Leaflet/Google Maps)
    mapElement.innerHTML = `
        <div style="width:100%;height:100%;background:linear-gradient(135deg, #e0f2fe 0%, #bae6fd 100%);display:flex;align-items:center;justify-content:center;">
            <div style="text-align:center;color:var(--primary-color);">
                <i class="fas fa-globe-americas" style="font-size:4rem;margin-bottom:1rem;"></i>
                <h3 style="color:var(--primary-color);">Interactive Map Loading...</h3>
                <p>In production, this would show missing person locations worldwide</p>
            </div>
        </div>
    `;
    
    // In a real implementation, you would initialize Leaflet/Google Maps here
    // Example: const map = L.map('worldMap').setView([20, 0], 2);
    // Add markers for missing persons from API data
}

// Emergency Contacts
function initEmergencyContacts() {
    // This would load emergency contacts from API
    // For now, we'll just ensure the emergency call buttons work
    const emergencyCallButtons = document.querySelectorAll('.emergency-call');
    
    emergencyCallButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            const number = this.textContent;
            if (confirm(`Call ${number}? This will use your device's phone app.`)) {
                // In a real mobile app, this would trigger the phone dialer
                console.log(`Calling ${number}`);
            } else {
                e.preventDefault();
            }
        });
    });
}

// Share Case Function
function shareCase(caseId) {
    if (navigator.share) {
        navigator.share({
            title: 'Missing Person Alert',
            text: 'Help find this missing person',
            url: `https://findthem.org/cases/case-details.html?id=${caseId}`
        })
        .then(() => console.log('Successfully shared'))
        .catch(error => console.log('Error sharing:', error));
    } else {
        // Fallback: Copy to clipboard
        const url = `${window.location.origin}/cases/case-details.html?id=${caseId}`;
        navigator.clipboard.writeText(url)
            .then(() => {
                alert('Case link copied to clipboard!');
            })
            .catch(err => {
                console.error('Failed to copy: ', err);
            });
    }
}

// Authentication Status
function checkAuthStatus() {
    const user = localStorage.getItem('findthem_user');
    const loginBtn = document.querySelector('.btn-login');
    const registerBtn = document.querySelector('.btn-register');
    
    if (user && loginBtn && registerBtn) {
        const userData = JSON.parse(user);
        loginBtn.innerHTML = `<i class="fas fa-user-circle"></i> ${userData.name.split(' ')[0]}`;
        loginBtn.href = "dashboard/index.html";
        registerBtn.innerHTML = '<i class="fas fa-sign-out-alt"></i> Logout';
        registerBtn.onclick = function(e) {
            e.preventDefault();
            logout();
        };
    }
}

function logout() {
    localStorage.removeItem('findthem_user');
    localStorage.removeItem('findthem_token');
    window.location.href = 'index.html';
}

// Tooltips
function initTooltips() {
    const tooltipElements = document.querySelectorAll('[data-tooltip]');
    
    tooltipElements.forEach(element => {
        element.addEventListener('mouseenter', showTooltip);
        element.addEventListener('mouseleave', hideTooltip);
    });
}

function showTooltip(e) {
    const tooltipText = this.getAttribute('data-tooltip');
    const tooltip = document.createElement('div');
    tooltip.className = 'tooltip';
    tooltip.textContent = tooltipText;
    
    document.body.appendChild(tooltip);
    
    const rect = this.getBoundingClientRect();
    tooltip.style.left = `${rect.left + rect.width / 2 - tooltip.offsetWidth / 2}px`;
    tooltip.style.top = `${rect.top - tooltip.offsetHeight - 10}px`;
    
    this.tooltipElement = tooltip;
}

function hideTooltip() {
    if (this.tooltipElement) {
        this.tooltipElement.remove();
        this.tooltipElement = null;
    }
}

// Initialize Animations on Scroll
function initAnimations() {
    // Add Intersection Observer for scroll animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animated');
            }
        });
    }, observerOptions);
    
    // Observe elements with animation classes
    document.querySelectorAll('.fade-in, .slide-in-left, .slide-in-right').forEach(el => {
        observer.observe(el);
    });
}

// Form Validation
function validateForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return true;
    
    const inputs = form.querySelectorAll('input[required], textarea[required], select[required]');
    let isValid = true;
    
    inputs.forEach(input => {
        if (!input.value.trim()) {
            input.classList.add('error');
            isValid = false;
            
            // Add error message if not exists
            if (!input.nextElementSibling || !input.nextElementSibling.classList.contains('error-message')) {
                const errorMsg = document.createElement('div');
                errorMsg.className = 'error-message';
                errorMsg.textContent = 'This field is required';
                input.parentNode.insertBefore(errorMsg, input.nextSibling);
            }
        } else {
            input.classList.remove('error');
            const errorMsg = input.nextElementSibling;
            if (errorMsg && errorMsg.classList.contains('error-message')) {
                errorMsg.remove();
            }
        }
    });
    
    return isValid;
}

// API Integration Functions
async function fetchCases(filters = {}) {
    try {
        // In production, this would be a real API call
        const response = await fetch('/api/cases', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('findthem_token')}`
            },
            body: JSON.stringify(filters)
        });
        
        return await response.json();
    } catch (error) {
        console.error('Error fetching cases:', error);
        return { error: 'Failed to load cases' };
    }
}

async function reportSighting(caseId, data) {
    try {
        const response = await fetch(`/api/cases/${caseId}/sightings`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        
        return await response.json();
    } catch (error) {
        console.error('Error reporting sighting:', error);
        return { error: 'Failed to report sighting' };
    }
}

// Export functions for use in other modules
window.shareCase = shareCase;
window.validateForm = validateForm;