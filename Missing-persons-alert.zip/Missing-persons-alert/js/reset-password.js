// Reset Password JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize form submission
    const resetPasswordForm = document.getElementById('resetPasswordForm');
    if (resetPasswordForm) {
        resetPasswordForm.addEventListener('submit', handleResetPassword);
    }

    // Start countdown timer
    startCountdownTimer();

    // Initialize password strength checker
    initPasswordStrengthChecker();

    // Initialize password match checker
    initPasswordMatchChecker();

    // Check URL token (simulated)
    checkResetToken();
});

// Check Reset Token
function checkResetToken() {
    // In production, this would validate the token from URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const token = urlParams.get('token');

    if (!token) {
        showAlert('Invalid or expired reset link. Please request a new one.', 'error');
        setTimeout(() => {
            window.location.href = '../auth/forgot-password.html';
        }, 3000);
    }
}

// Handle Reset Password
async function handleResetPassword(e) {
    e.preventDefault();

    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');
    const newPassword = form.newPassword.value;
    const confirmPassword = form.confirmPassword.value;

    // Validate passwords
    if (!validatePasswordStrength(newPassword)) {
        showAlert('Password does not meet security requirements', 'error');
        return;
    }

    if (newPassword !== confirmPassword) {
        showAlert('Passwords do not match', 'error');
        return;
    }

    // Show loading state
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Resetting Password...';
    submitBtn.disabled = true;

    try {
        // Simulate API call
        await simulateAPICall();

        // Show success
        showAlert('Password reset successful! Redirecting to login...', 'success');

        // Clear stored reset data
        localStorage.removeItem('findthem_reset_email');
        localStorage.removeItem('findthem_reset_time');

        // Redirect to login after delay
        setTimeout(() => {
            window.location.href = '../auth/login.html?reset=success';
        }, 2000);

    } catch (error) {
        showAlert('Failed to reset password. Please try again.', 'error');
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }
}

// Validate Password Strength
function validatePasswordStrength(password) {
    const requirements = {
        length: password.length >= 8,
        uppercase: /[A-Z]/.test(password),
        lowercase: /[a-z]/.test(password),
        number: /[0-9]/.test(password),
        special: /[^A-Za-z0-9]/.test(password)
    };

    return Object.values(requirements).every(req => req);
}

// Initialize Password Strength Checker
function initPasswordStrengthChecker() {
    const passwordInput = document.getElementById('newPassword');
    if (passwordInput) {
        passwordInput.addEventListener('input', function() {
            updatePasswordStrength(this.value);
            updatePasswordRequirements(this.value);
        });
    }
}

// Update Password Requirements UI
function updatePasswordRequirements(password) {
    const requirements = {
        length: password.length >= 8,
        uppercase: /[A-Z]/.test(password),
        lowercase: /[a-z]/.test(password),
        number: /[0-9]/.test(password),
        special: /[^A-Za-z0-9]/.test(password)
    };

    Object.keys(requirements).forEach(req => {
        const element = document.getElementById(`req-${req}`);
        if (element) {
            const icon = element.querySelector('i');
            if (requirements[req]) {
                icon.className = 'fas fa-check-circle';
                icon.style.color = '#10b981';
            } else {
                icon.className = 'fas fa-times-circle';
                icon.style.color = '#ef4444';
            }
        }
    });
}

// Initialize Password Match Checker
function initPasswordMatchChecker() {
    const passwordInput = document.getElementById('newPassword');
    const confirmInput = document.getElementById('confirmPassword');

    if (passwordInput && confirmInput) {
        [passwordInput, confirmInput].forEach(input => {
            input.addEventListener('input', checkPasswordMatch);
        });
    }
}

// Check Password Match
function checkPasswordMatch() {
    const password = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const indicator = document.getElementById('passwordMatchIndicator');

    if (!indicator) return;

    if (!confirmPassword) {
        indicator.style.display = 'none';
        return;
    }

    if (password === confirmPassword) {
        indicator.innerHTML = '<i class="fas fa-check-circle"></i> <span>Passwords match</span>';
        indicator.style.color = '#10b981';
        indicator.style.display = 'flex';
    } else {
        indicator.innerHTML = '<i class="fas fa-times-circle"></i> <span>Passwords do not match</span>';
        indicator.style.color = '#ef4444';
        indicator.style.display = 'flex';
    }
}

// Start Countdown Timer
function startCountdownTimer() {
    const timerElement = document.querySelector('.timer-display');

    if (timerElement) {
        let timeLeft = 5 * 60; // 5 minutes

        // Update every second
        const timerInterval = setInterval(() => {
            timeLeft--;

            const minutes = Math.floor(timeLeft / 60);
            const seconds = timeLeft % 60;

            timerElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

            if (timeLeft < 60) {
                timerElement.style.color = '#ef4444';
            }

            if (timeLeft <= 0) {
                clearInterval(timerInterval);
                timerElement.textContent = '00:00';

                // Disable form
                const form = document.getElementById('resetPasswordForm');
                if (form) {
                    form.style.opacity = '0.5';
                    form.style.pointerEvents = 'none';
                }

                showAlert('Reset link has expired. Please request a new one.', 'error');

                setTimeout(() => {
                    window.location.href = '../auth/forgot-password.html';
                }, 3000);
            }
        }, 1000);

        // Store interval for cleanup
        window.timerInterval = timerInterval;
    }
}

// Clean up on page unload
window.addEventListener('beforeunload', function() {
    if (window.timerInterval) {
        clearInterval(window.timerInterval);
    }
});

// Export functions
window.togglePassword = togglePassword;
window.updatePasswordStrength = updatePasswordStrength;
window.checkPasswordMatch = checkPasswordMatch;