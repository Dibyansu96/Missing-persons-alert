// Authentication JavaScript

document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const forgotPasswordForm = document.getElementById('forgotPasswordForm');

    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }

    if (forgotPasswordForm) {
        forgotPasswordForm.addEventListener('submit', handleForgotPassword);
    }

    // Initialize social login buttons
    initSocialLogin();
});

// Toggle password visibility
function togglePassword(inputId) {
    const input = document.getElementById(inputId || 'password');
    const toggleBtn = input.nextElementSibling;

    if (input.type === 'password') {
        input.type = 'text';
        toggleBtn.innerHTML = '<i class="fas fa-eye-slash"></i>';
    } else {
        input.type = 'password';
        toggleBtn.innerHTML = '<i class="fas fa-eye"></i>';
    }
}

// Handle Login
async function handleLogin(e) {
    e.preventDefault();

    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');
    const email = form.email.value;
    const password = form.password.value;

    // Simple validation
    if (!email || !password) {
        showAlert('Please fill in all fields', 'error');
        return;
    }

    // Show loading state
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Signing In...';
    submitBtn.disabled = true;

    try {
        // Simulate API call - In production, this would be a real API call
        await simulateAPICall();

        // For demo purposes, create mock user data
        const userData = {
            id: 1,
            email: email,
            name: 'John Doe',
            role: 'user',
            token: 'demo_token_' + Date.now()
        };

        // Store user data in localStorage (in production, use secure storage)
        localStorage.setItem('findthem_user', JSON.stringify(userData));
        localStorage.setItem('findthem_token', userData.token);

        showAlert('Login successful! Redirecting...', 'success');

        // Redirect to dashboard after 1 second
        setTimeout(() => {
            window.location.href = '../dashboard/index.html';
        }, 1000);

    } catch (error) {
        showAlert('Invalid email or password. Please try again.', 'error');
        submitBtn.innerHTML = '<i class="fas fa-sign-in-alt"></i> Sign In';
        submitBtn.disabled = false;
    }
}

// Handle Registration
async function handleRegister(e) {
    e.preventDefault();

    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');

    // Get form values
    const formData = {
        name: form.name.value,
        email: form.email.value,
        phone: form.phone.value,
        password: form.password.value,
        confirmPassword: form.confirmPassword.value,
        terms: form.terms.checked
    };

    // Validation
    if (!formData.name || !formData.email || !formData.password) {
        showAlert('Please fill in all required fields', 'error');
        return;
    }

    if (formData.password !== formData.confirmPassword) {
        showAlert('Passwords do not match', 'error');
        return;
    }

    if (!formData.terms) {
        showAlert('You must accept the terms and conditions', 'error');
        return;
    }

    // Show loading state
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating Account...';
    submitBtn.disabled = true;

    try {
        // Simulate API call
        await simulateAPICall();

        // Create mock user data
        const userData = {
            id: Math.floor(Math.random() * 1000) + 1,
            email: formData.email,
            name: formData.name,
            phone: formData.phone,
            role: 'user',
            verified: false,
            token: 'demo_token_' + Date.now()
        };

        // Store user data
        localStorage.setItem('findthem_user', JSON.stringify(userData));
        localStorage.setItem('findthem_token', userData.token);

        showAlert('Account created successfully! Please check your email for verification.', 'success');

        // Redirect to verification page
        setTimeout(() => {
            window.location.href = 'verify-email.html';
        }, 2000);

    } catch (error) {
        showAlert('Registration failed. Please try again.', 'error');
        submitBtn.innerHTML = '<i class="fas fa-user-plus"></i> Create Account';
        submitBtn.disabled = false;
    }
}

// Handle Forgot Password
async function handleForgotPassword(e) {
    e.preventDefault();

    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');
    const email = form.email.value;

    if (!email) {
        showAlert('Please enter your email address', 'error');
        return;
    }

    // Show loading state
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
    submitBtn.disabled = true;

    try {
        // Simulate API call
        await simulateAPICall();

        showAlert('Password reset instructions have been sent to your email.', 'success');

        // Reset form
        form.reset();

        // Redirect to login after 3 seconds
        setTimeout(() => {
            window.location.href = 'login.html';
        }, 3000);

    } catch (error) {
        showAlert('Failed to send reset instructions. Please try again.', 'error');
        submitBtn.innerHTML = '<i class="fas fa-paper-plane"></i> Send Reset Instructions';
        submitBtn.disabled = false;
    }
}

// Initialize Social Login
function initSocialLogin() {
    const googleBtn = document.querySelector('.btn-google');
    const facebookBtn = document.querySelector('.btn-facebook');

    if (googleBtn) {
        googleBtn.addEventListener('click', () => handleSocialLogin('google'));
    }

    if (facebookBtn) {
        facebookBtn.addEventListener('click', () => handleSocialLogin('facebook'));
    }
}

// Handle Social Login
function handleSocialLogin(provider) {
    showAlert(`Connecting with ${provider}...`, 'info');

    // In production, this would redirect to OAuth provider
    // For demo, simulate login
    setTimeout(() => {
        const userData = {
            id: Math.floor(Math.random() * 1000) + 1,
            email: `user_${Date.now()}@example.com`,
            name: 'Social User',
            role: 'user',
            provider: provider,
            token: 'social_token_' + Date.now()
        };

        localStorage.setItem('findthem_user', JSON.stringify(userData));
        localStorage.setItem('findthem_token', userData.token);

        showAlert(`Logged in with ${provider}!`, 'success');

        setTimeout(() => {
            window.location.href = '../dashboard/index.html';
        }, 1000);
    }, 1500);
}

// Simulate API call delay
function simulateAPICall() {
    return new Promise(resolve => {
        setTimeout(resolve, 1500);
    });
}

// Show alert message
function showAlert(message, type = 'info') {
    // Remove existing alerts
    const existingAlert = document.querySelector('.alert-message');
    if (existingAlert) {
        existingAlert.remove();
    }

    // Create alert element
    const alert = document.createElement('div');
    alert.className = `alert-message alert-${type}`;

    // Set icon based on type
    let icon = 'info-circle';
    if (type === 'success') icon = 'check-circle';
    if (type === 'error') icon = 'exclamation-circle';
    if (type === 'warning') icon = 'exclamation-triangle';

    alert.innerHTML = `
        <i class="fas fa-${icon}"></i>
        <span>${message}</span>
        <button class="alert-close" onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;

    // Add styles
    alert.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: var(--border-radius);
        display: flex;
        align-items: center;
        gap: 10px;
        box-shadow: var(--box-shadow);
        z-index: 10000;
        max-width: 400px;
        animation: slideInRight 0.3s ease-out;
    `;

    // Set colors based on type
    const colors = {
        success: { bg: '#d1fae5', text: '#065f46', border: '#a7f3d0' },
        error: { bg: '#fee2e2', text: '#991b1b', border: '#fecaca' },
        warning: { bg: '#fef3c7', text: '#92400e', border: '#fde68a' },
        info: { bg: '#dbeafe', text: '#1e40af', border: '#bfdbfe' }
    };

    alert.style.background = colors[type].bg;
    alert.style.color = colors[type].text;
    alert.style.border = `1px solid ${colors[type].border}`;

    document.body.appendChild(alert);

    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (alert.parentElement) {
            alert.style.animation = 'fadeOut 0.3s ease-out';
            setTimeout(() => alert.remove(), 300);
        }
    }, 5000);
}

// Password strength checker
function checkPasswordStrength(password) {
    if (!password) return 0;

    let strength = 0;

    // Length check
    if (password.length >= 8) strength++;
    if (password.length >= 12) strength++;

    // Complexity checks
    if (/[A-Z]/.test(password)) strength++;
    if (/[a-z]/.test(password)) strength++;
    if (/[0-9]/.test(password)) strength++;
    if (/[^A-Za-z0-9]/.test(password)) strength++;

    return Math.min(strength, 5); // Max 5
}

function updatePasswordStrength(password) {
    const strength = checkPasswordStrength(password);
    const meter = document.getElementById('passwordStrength');
    const text = document.getElementById('passwordStrengthText');

    if (!meter || !text) return;

    const levels = [
        { text: 'Very Weak', color: '#ef4444', width: '20%' },
        { text: 'Weak', color: '#f97316', width: '40%' },
        { text: 'Fair', color: '#eab308', width: '60%' },
        { text: 'Good', color: '#84cc16', width: '80%' },
        { text: 'Strong', color: '#10b981', width: '100%' }
    ];

    const level = levels[strength] || levels[0];

    meter.style.width = level.width;
    meter.style.backgroundColor = level.color;
    text.textContent = level.text;
    text.style.color = level.color;
}

// Export functions
window.togglePassword = togglePassword;
window.updatePasswordStrength = updatePasswordStrength;