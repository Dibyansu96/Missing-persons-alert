// API utilities for FindThem

const API_BASE = '../api';

// Generic API request function
async function apiRequest(endpoint, options = {}) {
    const url = `${API_BASE}${endpoint}`;
    const defaultOptions = {
        headers: {
            'Content-Type': 'application/json',
        },
    };

    const config = {...defaultOptions, ...options };

    try {
        const response = await fetch(url, config);
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('API request failed:', error);
        throw error;
    }
}

// Report submission functions
async function submitReport(formData) {
    // Convert FormData to JSON for the main data
    const jsonData = {};
    for (let [key, value] of formData.entries()) {
        if (key !== 'photos[]') {
            jsonData[key] = value;
        }
    }

    return await apiRequest('/reports.php', {
        method: 'POST',
        body: JSON.stringify(jsonData)
    });
}

async function uploadPhotos(caseId, photos) {
    const formData = new FormData();
    for (let i = 0; i < photos.length; i++) {
        formData.append('photos[]', photos[i]);
    }

    // Use fetch directly for file upload (no Content-Type header)
    const response = await fetch(`${API_BASE}/reports.php?caseId=${caseId}`, {
        method: 'POST',
        body: formData
    });

    return await response.json();
}

// Get reports
async function getReports(caseId = null) {
    const endpoint = caseId ? `/reports.php?caseId=${caseId}` : '/reports.php';
    return await apiRequest(endpoint);
}

// Authentication functions (placeholders for future implementation)
async function login(credentials) {
    return await apiRequest('/auth.php', {
        method: 'POST',
        body: JSON.stringify(credentials)
    });
}

async function register(userData) {
    return await apiRequest('/auth.php', {
        method: 'POST',
        body: JSON.stringify({...userData, action: 'register' })
    });
}

// Admin functions
async function getAdminReports() {
    return await apiRequest('/admin.php');
}

async function updateCaseStatus(caseId, status) {
    return await apiRequest('/admin.php', {
        method: 'POST',
        body: JSON.stringify({ caseId, status, action: 'update_status' })
    });
}