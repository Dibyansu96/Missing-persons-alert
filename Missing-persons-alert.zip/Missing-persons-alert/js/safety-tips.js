// Safety Tips JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize safety tips page
    initSafetyTips();
    initAgeGroupTabs();
    initSafetyQuiz();
    initChecklist();
    initQuickLinks();
});

// Initialize Safety Tips
function initSafetyTips() {
    // Initialize scroll animations
    initScrollAnimations();

    // Initialize stats counter
    initStatsCounter();

    // Load user's saved safety preferences
    loadSafetyPreferences();
}

// Initialize Age Group Tabs
function initAgeGroupTabs() {
    // Show first age group by default
    showAgeGroup('toddlers');
}

// Show Age Group
function showAgeGroup(ageGroup) {
    // Hide all age group content
    document.querySelectorAll('.age-group-content').forEach(content => {
        content.style.display = 'none';
    });

    // Remove active class from all tabs
    document.querySelectorAll('.age-tab').forEach(tab => {
        tab.classList.remove('active');
    });

    // Show selected age group content
    const contentId = `${ageGroup}-content`;
    const contentElement = document.getElementById(contentId);
    if (contentElement) {
        contentElement.style.display = 'block';
    }

    // Add active class to selected tab
    const activeTab = Array.from(document.querySelectorAll('.age-tab')).find(tab =>
        tab.textContent.toLowerCase().includes(ageGroup)
    );
    if (activeTab) {
        activeTab.classList.add('active');
    }

    // Load age-specific content if needed
    loadAgeGroupContent(ageGroup);
}

// Load Age Group Content
function loadAgeGroupContent(ageGroup) {
    const contentElement = document.getElementById(`${ageGroup}-content`);

    if (contentElement && !contentElement.hasAttribute('data-loaded')) {
        // Simulate loading content
        setTimeout(() => {
            let content = '';

            switch (ageGroup) {
                case 'children':
                    content = `
                        <div class="safety-tips-grid">
                            <div class="safety-tip-card">
                                <div class="tip-icon">
                                    <i class="fas fa-map-marker-alt"></i>
                                </div>
                                <div class="tip-content">
                                    <h3>Safe Routes</h3>
                                    <p>Teach children safe routes to school and friends' houses.</p>
                                    <ul class="tip-details">
                                        <li>Practice walking routes together</li>
                                        <li>Identify safe houses along the way</li>
                                        <li>Establish check-in times</li>
                                    </ul>
                                </div>
                            </div>
                            
                            <div class="safety-tip-card">
                                <div class="tip-icon">
                                    <i class="fas fa-mobile-alt"></i>
                                </div>
                                <div class="tip-content">
                                    <h3>Communication Rules</h3>
                                    <p>Establish rules for phone and internet use.</p>
                                    <ul class="tip-details">
                                        <li>Set screen time limits</li>
                                        <li>Monitor online activities</li>
                                        <li>Teach about online privacy</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    `;
                    break;

                case 'teens':
                    content = `
                        <div class="safety-tips-grid">
                            <div class="safety-tip-card">
                                <div class="tip-icon">
                                    <i class="fas fa-car"></i>
                                </div>
                                <div class="tip-content">
                                    <h3>Transportation Safety</h3>
                                    <p>Safety guidelines for teens using various transportation methods.</p>
                                    <ul class="tip-details">
                                        <li>Ride-sharing safety rules</li>
                                        <li>Public transportation awareness</li>
                                        <li>Emergency cash for taxis</li>
                                    </ul>
                                </div>
                            </div>
                            
                            <div class="safety-tip-card">
                                <div class="tip-icon">
                                    <i class="fas fa-user-friends"></i>
                                </div>
                                <div class="tip-content">
                                    <h3>Social Safety</h3>
                                    <p>Guidelines for social situations and peer pressure.</p>
                                    <ul class="tip-details">
                                        <li>Party safety guidelines</li>
                                        <li>Alcohol and drug awareness</li>
                                        <li>Peer pressure response strategies</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    `;
                    break;
            }

            if (content) {
                contentElement.innerHTML = content;
                contentElement.setAttribute('data-loaded', 'true');
            }
        }, 500);
    }
}

// Initialize Safety Quiz
function initSafetyQuiz() {
    // Quiz questions and answers
    window.quizData = {
        currentQuestion: 0,
        score: 0,
        userAnswers: [],
        questions: [{
                question: "What is the most important thing to do before going out alone at night?",
                options: [
                    "Tell someone where you're going",
                    "Charge your phone",
                    "Plan your route",
                    "All of the above"
                ],
                correctAnswer: 3,
                explanation: "All of these are important safety measures. Always let someone know your plans, ensure your phone is charged, and plan a safe route."
            },
            {
                question: "What should children be taught about strangers?",
                options: [
                    "Never talk to strangers",
                    "Only talk to strangers in public places",
                    "Recognize safe strangers (police, store employees)",
                    "All strangers are dangerous"
                ],
                correctAnswer: 2,
                explanation: "Children should learn to recognize safe strangers who can help them if they're lost, like police officers or store employees with name tags."
            },
            {
                question: "What information should travelers always carry?",
                options: [
                    "Passport and credit cards",
                    "Emergency contact information",
                    "Hotel address and local emergency numbers",
                    "All of the above"
                ],
                correctAnswer: 3,
                explanation: "Travelers should carry identification, emergency contacts, and local information for maximum safety."
            },
            {
                question: "What's the best way to protect personal information online?",
                options: [
                    "Never share anything personal",
                    "Use strong, unique passwords",
                    "Only use private Wi-Fi networks",
                    "All of the above"
                ],
                correctAnswer: 1,
                explanation: "Using strong, unique passwords is essential. While being cautious online is important, complete avoidance isn't practical."
            },
            {
                question: "What should you do if you feel you're being followed?",
                options: [
                    "Run to the nearest isolated area",
                    "Confront the person following you",
                    "Go to a public place and call for help",
                    "Ignore it and continue walking"
                ],
                correctAnswer: 2,
                explanation: "Go to a well-lit, populated area and call for help. Never confront someone or go to an isolated location."
            }
        ]
    };

    // Load first question
    loadQuizQuestion();
}

// Load Quiz Question
function loadQuizQuestion() {
    const quizData = window.quizData;
    const currentQuestion = quizData.questions[quizData.currentQuestion];

    if (!currentQuestion) return;

    // Update question text
    document.getElementById('questionText').textContent = currentQuestion.question;

    // Update options
    const optionsContainer = document.querySelector('.quiz-options');
    optionsContainer.innerHTML = '';

    currentQuestion.options.forEach((option, index) => {
        const optionElement = document.createElement('div');
        optionElement.className = 'quiz-option';
        optionElement.onclick = () => selectAnswer(index);
        optionElement.innerHTML = `
            <span class="option-letter">${String.fromCharCode(65 + index)}</span>
            <span class="option-text">${option}</span>
        `;

        // Check if this was previously selected
        if (quizData.userAnswers[quizData.currentQuestion] === index) {
            optionElement.classList.add('selected');
        }

        optionsContainer.appendChild(optionElement);
    });

    // Update progress
    updateQuizProgress();

    // Update button states
    updateQuizButtons();
}

// Select Answer
function selectAnswer(answerIndex) {
    const quizData = window.quizData;

    // Remove selected class from all options
    document.querySelectorAll('.quiz-option').forEach(option => {
        option.classList.remove('selected');
    });

    // Add selected class to clicked option
    const selectedOption = document.querySelectorAll('.quiz-option')[answerIndex];
    if (selectedOption) {
        selectedOption.classList.add('selected');
    }

    // Store user's answer
    quizData.userAnswers[quizData.currentQuestion] = answerIndex;

    // Enable submit button if on last question
    if (quizData.currentQuestion === quizData.questions.length - 1) {
        document.getElementById('submitBtn').style.display = 'inline-flex';
        document.getElementById('nextBtn').style.display = 'none';
    }
}

// Update Quiz Progress
function updateQuizProgress() {
    const quizData = window.quizData;
    const progress = ((quizData.currentQuestion + 1) / quizData.questions.length) * 100;

    // Update progress bar
    const progressFill = document.querySelector('.progress-fill');
    if (progressFill) {
        progressFill.style.width = `${progress}%`;
    }

    // Update question counter
    const currentQuestionElement = document.getElementById('currentQuestion');
    if (currentQuestionElement) {
        currentQuestionElement.textContent = quizData.currentQuestion + 1;
    }
}

// Update Quiz Buttons
function updateQuizButtons() {
    const quizData = window.quizData;
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');

    // Previous button
    if (prevBtn) {
        prevBtn.disabled = quizData.currentQuestion === 0;
    }

    // Next button
    if (nextBtn) {
        nextBtn.disabled = quizData.currentQuestion === quizData.questions.length - 1;
    }
}

// Next Question
function nextQuestion() {
    const quizData = window.quizData;

    if (quizData.currentQuestion < quizData.questions.length - 1) {
        quizData.currentQuestion++;
        loadQuizQuestion();
    }
}

// Previous Question
function prevQuestion() {
    const quizData = window.quizData;

    if (quizData.currentQuestion > 0) {
        quizData.currentQuestion--;
        loadQuizQuestion();
    }
}

// Submit Quiz
function submitQuiz() {
    const quizData = window.quizData;

    // Calculate score
    quizData.score = 0;
    quizData.questions.forEach((question, index) => {
        if (quizData.userAnswers[index] === question.correctAnswer) {
            quizData.score++;
        }
    });

    // Show results
    showQuizResults();
}

// Show Quiz Results
function showQuizResults() {
    const quizData = window.quizData;
    const quizQuestion = document.getElementById('quizQuestion');
    const quizResults = document.getElementById('quizResults');
    const quizScore = document.getElementById('quizScore');
    const resultsMessage = document.getElementById('resultsMessage');

    if (!quizQuestion || !quizResults || !quizScore || !resultsMessage) return;

    // Hide question, show results
    quizQuestion.style.display = 'none';
    quizResults.style.display = 'block';

    // Update score
    quizScore.textContent = quizData.score;

    // Set result message based on score
    let message = '';
    if (quizData.score === quizData.questions.length) {
        message = 'Perfect score! You have excellent safety knowledge. Keep up the good work!';
    } else if (quizData.score >= quizData.questions.length * 0.7) {
        message = 'Good job! You have solid safety knowledge. Review the questions you missed to improve.';
    } else if (quizData.score >= quizData.questions.length * 0.5) {
        message = 'You have basic safety knowledge. Consider reviewing the safety tips on this page.';
    } else {
        message = 'Please review the safety tips on this page to improve your safety knowledge.';
    }

    // Add question review
    message += '<div class="quiz-review" style="margin-top: 1.5rem; text-align: left;">';
    quizData.questions.forEach((question, index) => {
        const userAnswer = quizData.userAnswers[index];
        const isCorrect = userAnswer === question.correctAnswer;

        message += `
            <div style="margin-bottom: 1rem; padding: 1rem; background: ${isCorrect ? '#d1fae5' : '#fee2e2'}; border-radius: var(--border-radius);">
                <strong>Question ${index + 1}:</strong> ${question.question}<br>
                <strong>Your answer:</strong> ${userAnswer !== undefined ? question.options[userAnswer] : 'Not answered'}<br>
                <strong>Correct answer:</strong> ${question.options[question.correctAnswer]}<br>
                <em style="font-size: 0.9rem; color: #666;">${question.explanation}</em>
            </div>
        `;
    });
    message += '</div>';

    resultsMessage.innerHTML = message;

    // Hide quiz actions
    document.querySelector('.quiz-actions').style.display = 'none';
}

// Restart Quiz
function restartQuiz() {
    // Reset quiz data
    window.quizData = {
        currentQuestion: 0,
        score: 0,
        userAnswers: [],
        questions: window.quizData.questions // Keep the same questions
    };

    // Show question, hide results
    document.getElementById('quizQuestion').style.display = 'block';
    document.getElementById('quizResults').style.display = 'none';

    // Show quiz actions
    document.querySelector('.quiz-actions').style.display = 'flex';

    // Reset buttons
    document.getElementById('submitBtn').style.display = 'none';
    document.getElementById('nextBtn').style.display = 'inline-flex';

    // Load first question
    loadQuizQuestion();
}

// Initialize Checklist
function initChecklist() {
    // Load saved checklist state
    const savedChecklist = JSON.parse(localStorage.getItem('findthem_safety_checklist') || '{}');

    // Apply saved state
    Object.keys(savedChecklist).forEach(id => {
        const checkbox = document.getElementById(id);
        if (checkbox) {
            checkbox.checked = savedChecklist[id];
        }
    });

    // Add change listeners
    document.querySelectorAll('.checklist-item input[type="checkbox"]').forEach(checkbox => {
        checkbox.addEventListener('change', saveChecklistState);
    });
}

// Save Checklist State
function saveChecklistState() {
    const checklistState = {};

    document.querySelectorAll('.checklist-item input[type="checkbox"]').forEach(checkbox => {
        checklistState[checkbox.id] = checkbox.checked;
    });

    localStorage.setItem('findthem_safety_checklist', JSON.stringify(checklistState));
}

// Initialize Quick Links
function initQuickLinks() {
    // Smooth scroll for quick links
    document.querySelectorAll('.quick-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);

            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
            }
        });
    });
}

// Initialize Stats Counter
function initStatsCounter() {
    const stats = document.querySelectorAll('.safety-stat .stat-number');
    const targetValues = [78, 92, 65];

    stats.forEach((stat, index) => {
        animateStatCounter(stat, targetValues[index]);
    });
}

// Animate Stat Counter
function animateStatCounter(element, target) {
    const duration = 2000;
    const step = target / (duration / 16);
    let current = 0;

    const timer = setInterval(() => {
        current += step;
        if (current >= target) {
            element.textContent = target + '%';
            clearInterval(timer);
        } else {
            element.textContent = Math.floor(current) + '%';
        }
    }, 16);
}

// Initialize Scroll Animations
function initScrollAnimations() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animated');
            }
        });
    }, { threshold: 0.1 });

    // Observe safety tip cards
    document.querySelectorAll('.safety-tip-card, .digital-tip-card').forEach(card => {
        observer.observe(card);
    });
}

// Load Safety Preferences
function loadSafetyPreferences() {
    // Load any saved user preferences
    const preferences = JSON.parse(localStorage.getItem('findthem_safety_preferences') || '{}');

    // Apply preferences if needed
    if (preferences.lastVisitedSection) {
        // Could scroll to last visited section
    }
}

// Show Alert
function showAlert(message, type = 'info') {
    const existingAlert = document.querySelector('.alert-message');
    if (existingAlert) existingAlert.remove();

    const alert = document.createElement('div');
    alert.className = 'alert-message alert-' + type;

    let icon = 'info-circle';
    if (type === 'success') icon = 'check-circle';
    if (type === 'error') icon = 'exclamation-circle';
    if (type === 'warning') icon = 'exclamation-triangle';

    alert.innerHTML = '<i class="fas fa-' + icon + '"></i><span>' + message + '</span><button class="alert-close" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>';

    alert.style.cssText = 'position: fixed; top: 20px; right: 20px; padding: 1rem 1.5rem; border-radius: var(--border-radius); display: flex; align-items: center; gap: 10px; box-shadow: var(--box-shadow); z-index: 10000; max-width: 400px; animation: slideInRight 0.3s ease-out;';

    const colors = {
        success: { bg: '#d1fae5', text: '#065f46', border: '#a7f3d0' },
        error: { bg: '#fee2e2', text: '#991b1b', border: '#fecaca' },
        warning: { bg: '#fef3c7', text: '#92400e', border: '#fde68a' },
        info: { bg: '#dbeafe', text: '#1e40af', border: '#bfdbfe' }
    };

    alert.style.background = colors[type].bg;
    alert.style.color = colors[type].text;
    alert.style.border = '1px solid ' + colors[type].border;

    document.body.appendChild(alert);

    setTimeout(function() {
        if (alert.parentElement) {
            alert.style.animation = 'fadeOut 0.3s ease-out';
            setTimeout(function() { alert.remove(); }, 300);
        }
    }, 5000);
}

// Download Safety Guide - Download existing PDF file
function downloadSafetyGuide() {
    // PDF file path - the PDF is in the root directory
    const pdfFileName = 'Personal_Safety_Guidelines_Handbook_Full_Detailed (1).pdf';
    const pdfPath = '../' + pdfFileName;

    // Show loading message
    showAlert('Preparing your download...', 'info');

    // Use fetch API for more reliable download
    fetch(pdfPath)
        .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                    return response.blob();
                })
            .then(blob => {
                // Create a blob URL for the file
                const blobUrl = window.URL.createObjectURL(blob);

                // Create a temporary anchor element
                const link = document.createElement('a');
                link.href = blobUrl;
                link.download = pdfFileName;
                link.style.display = 'none';

                // Append to body, click, and remove
                document.body.appendChild(link);
                link.click();

                // Clean up
                setTimeout(() => {
                    document.body.removeChild(link);
                    window.URL.revokeObjectURL(blobUrl);
                }, 100);

                showAlert('Download started! Your safety guide PDF will download shortly.', 'success');
            })
            .catch(error => {
                console.error('Download error:', error);
                // Fallback to traditional method if fetch fails
                fallbackDownload(pdfPath, pdfFileName);
            });
        }

    // Fallback download method
    function fallbackDownload(pdfPath, pdfFileName) {
        const link = document.createElement('a');
        link.href = pdfPath;
        link.download = pdfFileName;
        link.target = '_blank';

        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        showAlert('Download started! Your safety guide PDF will download shortly.', 'success');
    }