// Search Results JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize search results page
    initSearchResults();
    initRefineSearch();
    initSearchQuery();
    initSorting();
    initViewToggle();
    loadSearchResults();
    initModals();
    initRelatedSearches();
});

// Initialize Search Results
function initSearchResults() {
    // Parse URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const searchQuery = urlParams.get('q') || '';
    const filters = parseFiltersFromUrl();

    // Update search query display
    updateSearchQueryDisplay(searchQuery, filters);

    // Update page title
    if (searchQuery) {
        document.title = `"${searchQuery}" - Search Results - FindThem`;
    }

    // Check authentication for save search
    checkAuthForSaveSearch();
}

// Parse Filters from URL
function parseFiltersFromUrl() {
    const urlParams = new URLSearchParams(window.location.search);
    const filters = {};

    // Parse filter parameters
    const filterParams = ['location', 'status', 'age', 'gender', 'time', 'type'];

    filterParams.forEach(param => {
        const value = urlParams.get(param);
        if (value) {
            filters[param] = value;
        }
    });

    return filters;
}

// Update Search Query Display
function updateSearchQueryDisplay(searchQuery, filters) {
    const queryDisplay = document.getElementById('searchQueryDisplay');
    const activeFilters = queryDisplay.querySelector('.active-filters');
    const searchSummary = document.querySelector('.search-summary');

    if (!activeFilters) return;

    // Clear existing filters
    activeFilters.innerHTML = '';

    // Add search query if exists
    if (searchQuery) {
        const queryBadge = createFilterBadge('Search', searchQuery, 'search');
        activeFilters.appendChild(queryBadge);

        // Update search summary
        searchSummary.textContent = `Showing results for "${searchQuery}"`;
    }

    // Add filter badges
    Object.keys(filters).forEach(key => {
        const label = getFilterLabel(key);
        const value = filters[key];
        const filterBadge = createFilterBadge(label, value, key);
        activeFilters.appendChild(filterBadge);
    });

    // Update results count
    updateResultsStats();
}

// Create Filter Badge
function createFilterBadge(label, value, key) {
    const badge = document.createElement('div');
    badge.className = 'filter-badge';

    // Format value for display
    let displayValue = value;
    if (key === 'age') {
        displayValue = getAgeGroupLabel(value);
    } else if (key === 'status') {
        displayValue = getStatusLabel(value);
    } else if (key === 'gender') {
        displayValue = getGenderLabel(value);
    }

    badge.innerHTML = `
        <span class="filter-label">${label}:</span>
        <span class="filter-value">${displayValue}</span>
        <button class="remove-filter" onclick="removeFilter('${key}')">
            <i class="fas fa-times"></i>
        </button>
    `;

    return badge;
}

// Get Filter Label
function getFilterLabel(key) {
    const labels = {
        'search': 'Search',
        'location': 'Location',
        'status': 'Status',
        'age': 'Age',
        'gender': 'Gender',
        'time': 'Time',
        'type': 'Type'
    };

    return labels[key] || key;
}

// Get Age Group Label
function getAgeGroupLabel(value) {
    const labels = {
        'child': 'Child (0-12)',
        'teen': 'Teen (13-17)',
        'adult': 'Adult (18-59)',
        'senior': 'Senior (60+)'
    };

    return labels[value] || value;
}

// Get Status Label
function getStatusLabel(value) {
    const labels = {
        'active': 'Active',
        'critical': 'Critical',
        'recent': 'Recent',
        'found': 'Found'
    };

    return labels[value] || value;
}

// Get Gender Label
function getGenderLabel(value) {
    const labels = {
        'male': 'Male',
        'female': 'Female',
        'other': 'Other'
    };

    return labels[value] || value;
}

// Remove Filter
function removeFilter(filterKey) {
    const urlParams = new URLSearchParams(window.location.search);

    if (filterKey === 'search') {
        urlParams.delete('q');
    } else {
        urlParams.delete(filterKey);
    }

    // Update URL without page reload
    const newUrl = `${window.location.pathname}?${urlParams.toString()}`;
    window.history.replaceState({}, '', newUrl);

    // Reload results
    loadSearchResults();
}

// Clear All Filters
function clearAllFilters() {
    // Reset to base search page
    window.location.href = 'index.html';
}

// Initialize Refine Search
function initRefineSearch() {
    // Load saved refinements from localStorage
    const savedRefinements = localStorage.getItem('findthem_refinements');
    if (savedRefinements) {
        try {
            const refinements = JSON.parse(savedRefinements);
            applySavedRefinements(refinements);
        } catch (e) {
            console.error('Error loading refinements:', e);
        }
    }

    // Set up refine toggle
    const refineToggle = document.querySelector('.btn-refine-toggle');
    if (refineToggle) {
        refineToggle.addEventListener('click', toggleRefineSearch);
    }
}

// Toggle Refine Search Panel
function toggleRefineSearch() {
    const panel = document.getElementById('refineSearchPanel');
    const toggleBtn = document.querySelector('.btn-refine-toggle');

    if (panel.classList.contains('show')) {
        panel.classList.remove('show');
        panel.style.display = 'none';
        toggleBtn.innerHTML = '<i class="fas fa-chevron-down"></i> Show Filters';
    } else {
        panel.classList.add('show');
        panel.style.display = 'block';
        toggleBtn.innerHTML = '<i class="fas fa-chevron-up"></i> Hide Filters';
    }
}

// Apply Saved Refinements
function applySavedRefinements(refinements) {
    // Apply color selections
    if (refinements.hairColor) {
        selectColor('hair', refinements.hairColor);
    }

    if (refinements.eyeColor) {
        selectColor('eyes', refinements.eyeColor);
    }

    // Apply feature selections
    if (refinements.features) {
        refinements.features.forEach(feature => {
            toggleFeature(feature, true);
        });
    }

    // Apply other refinements
    const elements = {
        'refineAgeFrom': refinements.ageFrom,
        'refineAgeTo': refinements.ageTo,
        'refineHeight': refinements.height,
        'refineClothing': refinements.clothing
    };

    Object.keys(elements).forEach(id => {
        const element = document.getElementById(id);
        if (element && elements[id]) {
            element.value = elements[id];
        }
    });
}

// Select Color
function selectColor(type, color) {
    // Remove active class from all color options of this type
    document.querySelectorAll(`.color-option[data-color]`).forEach(option => {
        if (option.closest(`#refine${type.charAt(0).toUpperCase() + type.slice(1)}`) ||
            option.closest(`[data-type="${type}"]`)) {
            option.classList.remove('active');
        }
    });

    // Add active class to selected color
    const selectedOption = document.querySelector(`.color-option[data-color="${color}"]`);
    if (selectedOption) {
        selectedOption.classList.add('active');
    }
}

// Toggle Feature
function toggleFeature(feature, forceState = null) {
    const featureTag = document.querySelector(`.feature-tag[onclick*="${feature}"]`);
    if (featureTag) {
        const isActive = forceState !== null ? forceState : featureTag.classList.contains('active');

        if (isActive) {
            featureTag.classList.remove('active');
        } else {
            featureTag.classList.add('active');
        }
    }
}

// Refine by Quick Option
function refineByTime(timeRange) {
    // Update URL with time filter
    const urlParams = new URLSearchParams(window.location.search);
    urlParams.set('time', timeRange);

    // Update URL and reload
    const newUrl = `${window.location.pathname}?${urlParams.toString()}`;
    window.location.href = newUrl;
}

function refineByAge(ageGroup) {
    const urlParams = new URLSearchParams(window.location.search);
    urlParams.set('age', ageGroup);

    const newUrl = `${window.location.pathname}?${urlParams.toString()}`;
    window.location.href = newUrl;
}

function refineByStatus(status) {
    const urlParams = new URLSearchParams(window.location.search);
    urlParams.set('status', status);

    const newUrl = `${window.location.pathname}?${urlParams.toString()}`;
    window.location.href = newUrl;
}

function refineByDistance() {
    // Request location permission
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const { latitude, longitude } = position.coords;
                const urlParams = new URLSearchParams(window.location.search);
                urlParams.set('lat', latitude);
                urlParams.set('lng', longitude);
                urlParams.set('distance', '25'); // 25 miles/kilometers

                const newUrl = `${window.location.pathname}?${urlParams.toString()}`;
                window.location.href = newUrl;
            },
            (error) => {
                showAlert('Unable to get your location. Please enable location services.', 'error');
            }
        );
    } else {
        showAlert('Geolocation is not supported by your browser.', 'error');
    }
}

// Apply Refinements
function applyRefinements() {
    const refinements = {
        ageFrom: (document.getElementById('refineAgeFrom') || {}).value || '',
        ageTo: (document.getElementById('refineAgeTo') || {}).value || '',
        height: (document.getElementById('refineHeight') || {}).value || '',
        clothing: (document.getElementById('refineClothing') || {}).value || '',
        hairColor: getSelectedColor('hair'),
        eyeColor: getSelectedColor('eyes'),
        features: getSelectedFeatures()
    };

    // Save refinements to localStorage
    localStorage.setItem('findthem_refinements', JSON.stringify(refinements));

    // Build URL with refinements
    const urlParams = new URLSearchParams(window.location.search);

    // Add age range
    if (refinements.ageFrom || refinements.ageTo) {
        urlParams.set('ageFrom', refinements.ageFrom);
        urlParams.set('ageTo', refinements.ageTo);
    }

    // Add other refinements
    if (refinements.height) urlParams.set('height', refinements.height);
    if (refinements.clothing) urlParams.set('clothing', refinements.clothing);
    if (refinements.hairColor) urlParams.set('hair', refinements.hairColor);
    if (refinements.eyeColor) urlParams.set('eyes', refinements.eyeColor);
    if (refinements.features.length > 0) {
        urlParams.set('features', refinements.features.join(','));
    }

    // Reload with refinements
    const newUrl = `${window.location.pathname}?${urlParams.toString()}`;
    window.location.href = newUrl;
}

// Get Selected Color
function getSelectedColor(type) {
    const selected = document.querySelector(`.color-option.active[data-color]`);
    return selected ? selected.getAttribute('data-color') : '';
}

// Get Selected Features
function getSelectedFeatures() {
    const features = [];
    document.querySelectorAll('.feature-tag.active').forEach(tag => {
        const onclickAttr = tag.getAttribute('onclick');
        const match = onclickAttr.match(/toggleFeature\('([^']+)'/);
        if (match) {
            features.push(match[1]);
        }
    });
    return features;
}

// Reset Refinements
function resetRefinements() {
    // Clear localStorage
    localStorage.removeItem('findthem_refinements');

    // Reset form elements
    document.getElementById('refineAgeFrom').value = '';
    document.getElementById('refineAgeTo').value = '';
    document.getElementById('refineHeight').value = '';
    document.getElementById('refineClothing').value = '';

    // Reset color selections
    document.querySelectorAll('.color-option.active').forEach(option => {
        option.classList.remove('active');
    });

    // Reset feature selections
    document.querySelectorAll('.feature-tag.active').forEach(tag => {
        tag.classList.remove('active');
    });

    // Reset quick options
    document.querySelectorAll('.refine-option.active').forEach(option => {
        option.classList.remove('active');
    });

    // Reload without refinements
    const urlParams = new URLSearchParams(window.location.search);

    // Remove refinement parameters
    ['ageFrom', 'ageTo', 'height', 'clothing', 'hair', 'eyes', 'features'].forEach(param => {
        urlParams.delete(param);
    });

    const newUrl = `${window.location.pathname}?${urlParams.toString()}`;
    window.location.href = newUrl;
}

// Initialize Search Query
function initSearchQuery() {
    const urlParams = new URLSearchParams(window.location.search);
    const searchQuery = urlParams.get('q') || '';

    if (searchQuery) {
        // Highlight search terms in results (will be done when loading results)
        console.log('Search query:', searchQuery);
    }
}

// Load Search Results
async function loadSearchResults() {
    const resultsContainer = document.getElementById('resultsContainer');
    const loadingIndicator = document.getElementById('resultsLoading');
    const noResults = document.getElementById('noResultsFound');
    const resultsMapContainer = document.getElementById('resultsMapContainer');

    if (!resultsContainer) return;

    // Show loading
    resultsContainer.innerHTML = '';
    loadingIndicator.classList.add('show');
    noResults.style.display = 'none';
    resultsMapContainer.style.display = 'none';

    // Get search parameters
    const urlParams = new URLSearchParams(window.location.search);
    const searchParams = {
        query: urlParams.get('q') || '',
        location: urlParams.get('location') || '',
        status: urlParams.get('status') || '',
        age: urlParams.get('age') || '',
        gender: urlParams.get('gender') || '',
        time: urlParams.get('time') || '',
        ageFrom: urlParams.get('ageFrom') || '',
        ageTo: urlParams.get('ageTo') || '',
        height: urlParams.get('height') || '',
        hair: urlParams.get('hair') || '',
        eyes: urlParams.get('eyes') || '',
        features: urlParams.get('features') || '',
        lat: urlParams.get('lat') || '',
        lng: urlParams.get('lng') || '',
        distance: urlParams.get('distance') || ''
    };

    try {
        // Fetch search results
        const { results, stats } = await fetchSearchResults(searchParams);

        // Hide loading
        loadingIndicator.classList.remove('show');

        // Update stats
        updateResultsStats(stats);

        if (results.length === 0) {
            noResults.style.display = 'block';
            return;
        }

        // Get current view mode
        const viewMode = localStorage.getItem('findthem_results_view') || 'grid';

        if (viewMode === 'map') {
            // Show map view
            resultsMapContainer.style.display = 'grid';
            displayResultsOnMap(results);
        } else {
            // Show list/grid view
            displayResults(results, viewMode);
        }

        // Update pagination
        updatePagination(stats.currentPage, stats.totalPages);

    } catch (error) {
        console.error('Error loading search results:', error);
        loadingIndicator.classList.remove('show');
        showAlert('Failed to load search results. Please try again.', 'error');
    }
}

// Fetch Search Results
async function fetchSearchResults(params) {
    // Simulate API call
    return new Promise((resolve) => {
        setTimeout(() => {
            // Sample results data
            const allResults = [{
                    id: 1,
                    name: "Emma Johnson",
                    age: 28,
                    location: "New York, USA",
                    timeAgo: "2 hours ago",
                    description: "Last seen wearing blue jeans and white t-shirt near Central Park.",
                    status: "critical",
                    gender: "female",
                    category: "adult",
                    tags: ["amber", "medical"],
                    imageColor: "#e0f2fe",
                    latitude: 40.7128,
                    longitude: -74.0060,
                    hair: "blonde",
                    eyes: "blue",
                    height: "average",
                    features: ["tattoo"]
                },
                {
                    id: 2,
                    name: "David Chen",
                    age: 45,
                    location: "Toronto, Canada",
                    timeAgo: "5 hours ago",
                    description: "Missing after not returning from evening walk. Has medical condition.",
                    status: "active",
                    gender: "male",
                    category: "adult",
                    tags: ["medical"],
                    imageColor: "#dcfce7",
                    latitude: 43.651070,
                    longitude: -79.347015,
                    hair: "black",
                    eyes: "brown",
                    height: "average",
                    features: ["glasses"]
                },
                {
                    id: 3,
                    name: "Sophia Rodriguez",
                    age: 16,
                    location: "Madrid, Spain",
                    timeAgo: "1 day ago",
                    description: "Student missing after school. Last seen near city center.",
                    status: "recent",
                    gender: "female",
                    category: "teen",
                    tags: ["amber", "child"],
                    imageColor: "#fef3c7",
                    latitude: 40.4168,
                    longitude: -3.7038,
                    hair: "brown",
                    eyes: "brown",
                    height: "short",
                    features: ["piercing"]
                },
                {
                    id: 4,
                    name: "Mohammed Al-Farsi",
                    age: 32,
                    location: "Dubai, UAE",
                    timeAgo: "3 days ago",
                    description: "Tourist missing from hotel. Family concerned for his safety.",
                    status: "active",
                    gender: "male",
                    category: "adult",
                    tags: ["tourist"],
                    imageColor: "#e0e7ff",
                    latitude: 25.2048,
                    longitude: 55.2708,
                    hair: "black",
                    eyes: "brown",
                    height: "tall",
                    features: ["beard"]
                },
                {
                    id: 5,
                    name: "Liam Wilson",
                    age: 8,
                    location: "London, UK",
                    timeAgo: "12 hours ago",
                    description: "Child missing from playground. Last seen with blue backpack.",
                    status: "critical",
                    gender: "male",
                    category: "child",
                    tags: ["amber", "child", "urgent"],
                    imageColor: "#fce7f3",
                    latitude: 51.5074,
                    longitude: -0.1278,
                    hair: "blonde",
                    eyes: "blue",
                    height: "short",
                    features: []
                }
            ];

            // Filter results based on search parameters
            let filteredResults = allResults;

            // Filter by search query
            if (params.query) {
                const query = params.query.toLowerCase();
                filteredResults = filteredResults.filter(result =>
                    result.name.toLowerCase().includes(query) ||
                    result.location.toLowerCase().includes(query) ||
                    result.description.toLowerCase().includes(query) ||
                    result.tags.some(tag => tag.toLowerCase().includes(query))
                );
            }

            // Filter by age
            if (params.age) {
                filteredResults = filteredResults.filter(result => result.category === params.age);
            }

            // Filter by age range
            if (params.ageFrom || params.ageTo) {
                const from = parseInt(params.ageFrom) || 0;
                const to = parseInt(params.ageTo) || 120;
                filteredResults = filteredResults.filter(result => result.age >= from && result.age <= to);
            }

            // Filter by gender
            if (params.gender) {
                filteredResults = filteredResults.filter(result => result.gender === params.gender);
            }

            // Filter by hair color
            if (params.hair) {
                filteredResults = filteredResults.filter(result => result.hair === params.hair);
            }

            // Filter by eye color
            if (params.eyes) {
                filteredResults = filteredResults.filter(result => result.eyes === params.eyes);
            }

            // Filter by height
            if (params.height) {
                filteredResults = filteredResults.filter(result => result.height === params.height);
            }

            // Filter by features
            if (params.features) {
                const features = params.features.split(',');
                filteredResults = filteredResults.filter(result =>
                    features.every(feature => result.features.includes(feature))
                );
            }

            // Filter by status
            if (params.status) {
                filteredResults = filteredResults.filter(result => result.status === params.status);
            }

            // Simulate pagination
            const pageSize = 10;
            const currentPage = 1;
            const startIndex = (currentPage - 1) * pageSize;
            const endIndex = startIndex + pageSize;
            const paginatedResults = filteredResults.slice(startIndex, endIndex);
            const totalPages = Math.ceil(filteredResults.length / pageSize);

            resolve({
                results: paginatedResults,
                stats: {
                    totalResults: filteredResults.length,
                    currentPage: currentPage,
                    totalPages: totalPages,
                    searchTime: 0.42,
                    countries: new Set(filteredResults.map(r => r.location.split(',')[1].trim())).size
                }
            });
        }, 1000);
    });
}

// Display Results
function displayResults(results, viewMode = 'grid') {
    const resultsContainer = document.getElementById('resultsContainer');

    // Clear container
    resultsContainer.innerHTML = '';
    resultsContainer.className = `results-container ${viewMode}-view`;

    // Get search query for highlighting
    const urlParams = new URLSearchParams(window.location.search);
    const searchQuery = urlParams.get('q') || '';

    // Add results
    results.forEach((result, index) => {
        const resultElement = createResultElement(result, viewMode, index, searchQuery);
        resultsContainer.appendChild(resultElement);
    });
}

// Create Result Element
function createResultElement(result, viewMode, index, searchQuery = '') {
    const element = document.createElement('div');
    element.className = `case-card ${viewMode}-view fade-in`;
    element.style.animationDelay = `${index * 0.1}s`;

    // Highlight search terms in description
    let highlightedDescription = result.description;
    if (searchQuery) {
        const regex = new RegExp(`(${searchQuery})`, 'gi');
        highlightedDescription = result.description.replace(regex, '<mark>$1</mark>');
    }

    // Format tags
    const tagsHtml = result.tags.map(tag => {
        let className = 'tag';
        if (tag === 'amber' || tag === 'child') className += ` ${tag}`;
        return `<span class="${className}">${tag}</span>`;
    }).join('');

    if (viewMode === 'grid') {
        element.innerHTML = `
            <div class="case-image" style="background: ${result.imageColor}">
                <i class="fas fa-user-circle"></i>
                <span class="case-status ${result.status}">${result.status}</span>
            </div>
            <div class="case-content">
                <div class="case-meta">
                    <span class="case-location"><i class="fas fa-map-marker-alt"></i> ${result.location}</span>
                    <span class="case-time"><i class="far fa-clock"></i> ${result.timeAgo}</span>
                </div>
                <h3 class="case-name">${highlightName(result.name, searchQuery)}</h3>
                <div class="case-age">${result.age} years old</div>
                <p class="case-details">${highlightedDescription}</p>
                <div class="case-tags">
                    ${tagsHtml}
                </div>
                <div class="case-actions">
                    <a href="case-details.html?id=${result.id}" class="btn btn-primary btn-view">
                        <i class="fas fa-info-circle"></i> View Details
                    </a>
                    <button class="btn-share" onclick="shareCase(${result.id})">
                        <i class="fas fa-share-alt"></i>
                    </button>
                </div>
            </div>
        `;
    } else {
        // List view
        element.innerHTML = `
            <div class="case-image" style="background: ${result.imageColor}">
                <i class="fas fa-user-circle"></i>
            </div>
            <div class="case-content">
                <div class="case-meta">
                    <span class="case-location"><i class="fas fa-map-marker-alt"></i> ${result.location}</span>
                    <span class="case-time"><i class="far fa-clock"></i> ${result.timeAgo}</span>
                </div>
                <h3 class="case-name">${highlightName(result.name, searchQuery)}</h3>
                <span class="case-status ${result.status}">${result.status}</span>
                <p class="case-details">${highlightedDescription}</p>
                <div class="case-tags">
                    ${tagsHtml}
                </div>
            </div>
            <div class="case-actions">
                <a href="case-details.html?id=${result.id}" class="btn btn-primary">
                    <i class="fas fa-info-circle"></i> Details
                </a>
                <button class="btn btn-outline" onclick="shareCase(${result.id})">
                    <i class="fas fa-share-alt"></i> Share
                </button>
            </div>
        `;
    }

    return element;
}

// Highlight Name
function highlightName(name, searchQuery) {
    if (!searchQuery) return name;

    const regex = new RegExp(`(${searchQuery})`, 'gi');
    return name.replace(regex, '<mark>$1</mark>');
}

// Display Results on Map
function displayResultsOnMap(results) {
    const mapElement = document.getElementById('resultsMap');
    const resultsList = document.getElementById('mapResultsList');

    if (!mapElement || !resultsList) return;

    // Clear existing content
    mapElement.innerHTML = '';
    resultsList.innerHTML = '';

    // Create map placeholder (in production, use Leaflet/Google Maps)
    mapElement.innerHTML = `
        <div style="width:100%;height:100%;background:linear-gradient(135deg, #e0f2fe 0%, #bae6fd 100%);display:flex;align-items:center;justify-content:center;">
            <div style="text-align:center;color:var(--primary-color);padding:2rem;">
                <i class="fas fa-map-marked-alt" style="font-size:4rem;margin-bottom:1rem;"></i>
                <h3 style="color:var(--primary-color);">Search Results Map</h3>
                <p>Showing ${results.length} results on map</p>
                <div class="map-legend" style="margin-top:2rem;text-align:left;">
                    <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;">
                        <span style="width:12px;height:12px;background:#ef4444;border-radius:50%;"></span>
                        <span>Critical Cases</span>
                    </div>
                    <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;">
                        <span style="width:12px;height:12px;background:#f97316;border-radius:50%;"></span>
                        <span>Active Cases</span>
                    </div>
                    <div style="display:flex;align-items:center;gap:10px;">
                        <span style="width:12px;height:12px;background:#10b981;border-radius:50%;"></span>
                        <span>Recent Cases</span>
                    </div>
                </div>
            </div>
        </div>
    `;

    // Add results to sidebar list
    results.forEach((result, index) => {
        const listItem = document.createElement('div');
        listItem.className = 'map-result-item';
        listItem.innerHTML = `
            <h5>${result.name}, ${result.age}</h5>
            <p><i class="fas fa-map-marker-alt"></i> ${result.location}</p>
            <p><i class="far fa-clock"></i> ${result.timeAgo}</p>
        `;
        listItem.onclick = () => {
            window.location.href = `case-details.html?id=${result.id}`;
        };
        resultsList.appendChild(listItem);
    });
}

// Update Results Stats
function updateResultsStats(stats = {}) {
    // Default stats
    const defaultStats = {
        totalResults: 0,
        searchTime: 0.5,
        countries: 0
    };

    const finalStats = {...defaultStats, ...stats };

    // Update display
    document.getElementById('resultsCount').textContent = finalStats.totalResults.toLocaleString();
    document.getElementById('searchTime').textContent = finalStats.searchTime.toFixed(2);
    document.getElementById('countriesCount').textContent = finalStats.countries;
}

// Initialize Sorting
function initSorting() {
    const sortSelect = document.getElementById('sortResults');
    if (sortSelect) {
        // Load saved sort preference
        const savedSort = localStorage.getItem('findthem_sort_preference') || 'relevance';
        sortSelect.value = savedSort;

        sortSelect.addEventListener('change', sortResults);
    }
}

// Sort Results
function sortResults() {
    const sortSelect = document.getElementById('sortResults');
    const sortBy = sortSelect.value;

    // Save preference
    localStorage.setItem('findthem_sort_preference', sortBy);

    // Update URL with sort parameter
    const urlParams = new URLSearchParams(window.location.search);
    urlParams.set('sort', sortBy);

    // Reload results
    loadSearchResults();
}

// Initialize View Toggle
function initViewToggle() {
    const viewMode = localStorage.getItem('findthem_results_view') || 'grid';
    changeResultsView(viewMode);
}

// Change Results View
function changeResultsView(mode) {
    // Update active button
    document.querySelectorAll('.view-option').forEach(btn => {
        btn.classList.remove('active');
        if (btn.innerHTML.includes(mode)) {
            btn.classList.add('active');
        }
    });

    // Save preference
    localStorage.setItem('findthem_results_view', mode);

    // Update view
    if (mode === 'map') {
        document.getElementById('resultsContainer').style.display = 'none';
        document.getElementById('resultsMapContainer').style.display = 'grid';
        loadSearchResults(); // Reload to show map
    } else {
        document.getElementById('resultsContainer').style.display = 'block';
        document.getElementById('resultsMapContainer').style.display = 'none';
        const results = document.querySelectorAll('.case-card');
        if (results.length > 0) {
            const resultsContainer = document.getElementById('resultsContainer');
            resultsContainer.className = `results-container ${mode}-view`;

            // Reorganize results for new view mode
            results.forEach(result => {
                result.className = `case-card ${mode}-view`;
            });
        }
    }
}

// Update Pagination
function updatePagination(currentPage, totalPages) {
    const pageNumbers = document.getElementById('resultsPageNumbers');
    const prevBtn = document.querySelector('.results-pagination .prev');
    const nextBtn = document.querySelector('.results-pagination .next');

    if (!pageNumbers) return;

    // Clear existing numbers
    pageNumbers.innerHTML = '';

    // Create page numbers
    const maxVisible = 5;
    let startPage = Math.max(1, currentPage - Math.floor(maxVisible / 2));
    let endPage = Math.min(totalPages, startPage + maxVisible - 1);

    // Adjust start page if we're near the end
    if (endPage - startPage + 1 < maxVisible) {
        startPage = Math.max(1, endPage - maxVisible + 1);
    }

    for (let i = startPage; i <= endPage; i++) {
        const pageBtn = document.createElement('button');
        pageBtn.className = `page-number ${i === currentPage ? 'active' : ''}`;
        pageBtn.textContent = i;
        pageBtn.onclick = () => goToPage(i);
        pageNumbers.appendChild(pageBtn);
    }

    // Update button states
    prevBtn.disabled = currentPage === 1;
    nextBtn.disabled = currentPage === totalPages;
}

// Go to Page
function goToPage(page) {
    const urlParams = new URLSearchParams(window.location.search);
    urlParams.set('page', page);

    // Update URL and reload
    const newUrl = `${window.location.pathname}?${urlParams.toString()}`;
    window.location.href = newUrl;
}

// Previous Page
function prevPage() {
    const activePageElement = document.querySelector('.page-number.active');
    const currentPage = parseInt(activePageElement ? activePageElement.textContent : 1);
    if (currentPage > 1) goToPage(currentPage - 1);
}

// Next Page
function nextPage() {
    const activePageElement = document.querySelector('.page-number.active');
    const currentPage = parseInt(activePageElement ? activePageElement.textContent : 1);
    const totalPages = document.querySelectorAll('.page-number').length;
    if (currentPage < totalPages) goToPage(currentPage + 1);
}

// Initialize Modals
function initModals() {
    // Save Search Modal
    const saveForm = document.getElementById('saveSearchForm');
    if (saveForm) {
        saveForm.addEventListener('submit', handleSaveSearch);
    }
}

// Save Search
function saveSearch() {
    const modal = document.getElementById('saveSearchModal');
    if (modal) {
        modal.classList.add('show');
        modal.style.display = 'flex';
    }
}

// Close Save Search Modal
function closeSaveSearchModal() {
    const modal = document.getElementById('saveSearchModal');
    if (modal) {
        modal.classList.remove('show');
        setTimeout(() => {
            modal.style.display = 'none';
        }, 300);
    }
}

// Handle Save Search
function handleSaveSearch(e) {
    e.preventDefault();

    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');

    const alertData = {
        name: form.alertName.value,
        frequency: form.alertFrequency.value,
        email: form.alertEmail.value,
        searchParams: window.location.search
    };

    // Show loading
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
    submitBtn.disabled = true;

    setTimeout(() => {
        // Save to localStorage (in production, send to API)
        const savedSearches = JSON.parse(localStorage.getItem('findthem_saved_searches') || '[]');
        savedSearches.push({
            ...alertData,
            id: Date.now(),
            createdAt: new Date().toISOString()
        });
        localStorage.setItem('findthem_saved_searches', JSON.stringify(savedSearches));

        // Show success
        showAlert('Search alert saved successfully! You will receive notifications for new matching cases.', 'success');

        // Close modal
        closeSaveSearchModal();

        // Reset form
        form.reset();
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }, 1000);
}

// Export Results
function exportResults() {
    const modal = document.getElementById('exportModal');
    if (modal) {
        modal.classList.add('show');
        modal.style.display = 'flex';
    }
}

// Close Export Modal
function closeExportModal() {
    const modal = document.getElementById('exportModal');
    if (modal) {
        modal.classList.remove('show');
        setTimeout(() => {
            modal.style.display = 'none';
        }, 300);
    }
}

// Export Format
function exportFormat(format) {
    showAlert(`Preparing ${format.toUpperCase()} export...`, 'info');

    // Simulate export process
    setTimeout(() => {
        showAlert(`Export completed! Your ${format.toUpperCase()} file is ready.`, 'success');
        closeExportModal();

        // In production, this would trigger file download
        if (format === 'print') {
            window.print();
        }
    }, 1500);
}

// Initialize Related Searches
function initRelatedSearches() {
    // Set up related search click handlers
    document.querySelectorAll('.related-tag').forEach(tag => {
        tag.addEventListener('click', function(e) {
            e.preventDefault();
            const searchText = this.textContent.replace(/^[^ ]+ /, '').trim();
            performRelatedSearch(searchText);
        });
    });
}

// Perform Related Search
function performRelatedSearch(searchText) {
    const urlParams = new URLSearchParams();
    urlParams.set('q', searchText);

    // Navigate to search results with new query
    window.location.href = `search-results.html?${urlParams.toString()}`;
}

// Check Authentication for Save Search
function checkAuthForSaveSearch() {
    const user = localStorage.getItem('findthem_user');
    const saveSearchBtn = document.querySelector('button[onclick="saveSearch()"]');

    if (!user && saveSearchBtn) {
        saveSearchBtn.onclick = function() {
            showAlert('Please login to save search alerts.', 'info');
            setTimeout(() => {
                window.location.href = '../auth/login.html?redirect=' + encodeURIComponent(window.location.href);
            }, 1500);
        };
    }
}

// Show Alert
function showAlert(message, type = 'info') {
    const existingAlert = document.querySelector('.alert-message');
    if (existingAlert) existingAlert.remove();

    const alert = document.createElement('div');
    alert.className = `alert-message alert-${type}`;

    let icon = 'info-circle';
    if (type === 'success') icon = 'check-circle';
    if (type === 'error') icon = 'exclamation-circle';
    if (type === 'warning') icon = 'exclamation-triangle';

    alert.innerHTML = `
        <i class="fas fa-${icon}"></i>
        <span>${message}</span>
        <button class="alert-close" onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;

    alert.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: var(--border-radius);
        display: flex;
        align-items: center;
        gap: 10px;
        box-shadow: var(--box-shadow);
        z-index: 10000;
        max-width: 400px;
        animation: slideInRight 0.3s ease-out;
    `;

    const colors = {
        success: { bg: '#d1fae5', text: '#065f46', border: '#a7f3d0' },
        error: { bg: '#fee2e2', text: '#991b1b', border: '#fecaca' },
        warning: { bg: '#fef3c7', text: '#92400e', border: '#fde68a' },
        info: { bg: '#dbeafe', text: '#1e40af', border: '#bfdbfe' }
    };

    alert.style.background = colors[type].bg;
    alert.style.color = colors[type].text;
    alert.style.border = `1px solid ${colors[type].border}`;

    document.body.appendChild(alert);

    setTimeout(() => {
        if (alert.parentElement) {
            alert.style.animation = 'fadeOut 0.3s ease-out';
            setTimeout(() => alert.remove(), 300);
        }
    }, 5000);
}

// Show Search Help
function showSearchHelp() {
    alert('Search Tips:\n\n1. Use specific keywords like "blue jacket" or "tattoo on arm"\n2. Include location names for better results\n3. Use the advanced filters to narrow results\n4. Save searches to get alerts for new cases');
}

// Show Advanced Search
function showAdvancedSearch() {
    alert('Advanced Search Guide:\n\n1. Use age range filters for specific age groups\n2. Filter by physical features like hair/eye color\n3. Use distinguishing features like tattoos or scars\n4. Combine multiple filters for precise results');
}

// Share Case (from cases.js)
function shareCase(caseId) {
    if (navigator.share) {
        navigator.share({
            title: 'Missing Person Alert',
            text: 'Help find this missing person',
            url: `${window.location.origin}/cases/case-details.html?id=${caseId}`
        });
    } else {
        const url = `${window.location.origin}/cases/case-details.html?id=${caseId}`;
        navigator.clipboard.writeText(url)
            .then(() => {
                showAlert('Case link copied to clipboard!', 'success');
            })
            .catch(err => {
                showAlert('Failed to share. Please copy the URL manually.', 'error');
            });
    }
}

// Export functions for global use
window.toggleRefineSearch = toggleRefineSearch;
window.selectColor = selectColor;
window.toggleFeature = toggleFeature;
window.refineByTime = refineByTime;
window.refineByAge = refineByAge;
window.refineByStatus = refineByStatus;
window.refineByDistance = refineByDistance;
window.applyRefinements = applyRefinements;
window.resetRefinements = resetRefinements;
window.removeFilter = removeFilter;
window.clearAllFilters = clearAllFilters;
window.sortResults = sortResults;
window.changeResultsView = changeResultsView;
window.prevPage = prevPage;
window.nextPage = nextPage;
window.saveSearch = saveSearch;
window.closeSaveSearchModal = closeSaveSearchModal;
window.exportResults = exportResults;
window.closeExportModal = closeExportModal;
window.exportFormat = exportFormat;
window.performRelatedSearch = performRelatedSearch;
window.showSearchHelp = showSearchHelp;
window.showAdvancedSearch = showAdvancedSearch;
window.shareCase = shareCase;