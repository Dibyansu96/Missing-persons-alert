// Forgot Password JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize form submission
    const forgotPasswordForm = document.getElementById('forgotPasswordForm');
    if (forgotPasswordForm) {
        forgotPasswordForm.addEventListener('submit', handleForgotPassword);
    }

    // Initialize back to top button
    initBackToTop();

    // Initialize step indicator (if exists)
    initResetSteps();

    // Initialize countdown timer (if exists)
    initCountdownTimer();

    // Add animation classes on load
    setTimeout(() => {
        document.querySelector('.auth-card') ? .classList.add('fade-in');
    }, 100);
});

// Handle Forgot Password Form Submission
async function handleForgotPassword(e) {
    e.preventDefault();

    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');
    const email = form.email.value.trim();

    // Validate email
    if (!validateEmail(email)) {
        showAlert('Please enter a valid email address', 'error');
        return;
    }

    // Show loading state
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
    submitBtn.disabled = true;

    try {
        // Simulate API call delay
        await simulateAPICall();

        // Show success message
        showSuccessMessage(email);

        // Hide form
        form.style.display = 'none';

        // Update step indicator if exists
        updateResetStep(2);

        // Start countdown timer
        startCountdownTimer();

        // Store email in localStorage for potential resend
        localStorage.setItem('findthem_reset_email', email);
        localStorage.setItem('findthem_reset_time', Date.now());

    } catch (error) {
        showAlert('Failed to send reset instructions. Please try again.', 'error');

        // Reset button
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }
}

// Validate Email Format
function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Show Success Message
function showSuccessMessage(email) {
    const successMessage = document.getElementById('successMessage');
    if (successMessage) {
        successMessage.classList.add('show');

        // Add animation
        successMessage.style.animation = 'fadeIn 0.5s ease-out';

        // Update email in message if needed
        const emailElement = successMessage.querySelector('.email-address');
        if (emailElement) {
            emailElement.textContent = email;
        }
    }

    // Show notification
    showAlert('Password reset instructions sent to your email', 'success');
}

// Resend Reset Email
async function resendResetEmail() {
    const email = localStorage.getItem('findthem_reset_email');

    if (!email) {
        showAlert('No email found. Please submit the form again.', 'error');
        return;
    }

    // Check if we can resend (prevent spam)
    const lastSent = localStorage.getItem('findthem_reset_time');
    const now = Date.now();

    if (lastSent && (now - lastSent) < 30000) { // 30 seconds cooldown
        showAlert('Please wait 30 seconds before requesting another reset email.', 'warning');
        return;
    }

    const resendBtn = document.querySelector('button[onclick="resendResetEmail()"]');
    if (resendBtn) {
        const originalText = resendBtn.innerHTML;
        resendBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Resending...';
        resendBtn.disabled = true;

        try {
            await simulateAPICall();

            // Update timestamp
            localStorage.setItem('findthem_reset_time', now);

            showAlert('Reset email resent successfully!', 'success');

            // Reset button after delay
            setTimeout(() => {
                resendBtn.innerHTML = originalText;
                resendBtn.disabled = false;
            }, 2000);

            // Restart countdown timer
            startCountdownTimer();

        } catch (error) {
            showAlert('Failed to resend email. Please try again.', 'error');
            resendBtn.innerHTML = originalText;
            resendBtn.disabled = false;
        }
    }
}

// Initialize Back to Top Button
function initBackToTop() {
    const backToTopBtn = document.getElementById('backToTop');

    if (backToTopBtn) {
        // Show/hide button based on scroll position
        window.addEventListener('scroll', () => {
            if (window.pageYOffset > 300) {
                backToTopBtn.classList.add('visible');
            } else {
                backToTopBtn.classList.remove('visible');
            }
        });

        // Scroll to top when clicked
        backToTopBtn.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }
}

// Initialize Reset Steps Indicator
function initResetSteps() {
    const resetSteps = document.querySelectorAll('.reset-step');

    if (resetSteps.length > 0) {
        // Set first step as active by default
        resetSteps[0].classList.add('active');
    }
}

// Update Reset Step
function updateResetStep(stepNumber) {
    const resetSteps = document.querySelectorAll('.reset-step');

    resetSteps.forEach((step, index) => {
        step.classList.remove('active', 'completed');

        if (index + 1 < stepNumber) {
            step.classList.add('completed');
        } else if (index + 1 === stepNumber) {
            step.classList.add('active');
        }
    });
}

// Initialize Countdown Timer
function initCountdownTimer() {
    const timerElement = document.querySelector('.timer-display');

    if (timerElement) {
        // Set initial time (5 minutes)
        let timeLeft = 5 * 60; // 5 minutes in seconds

        // Function to update timer display
        function updateTimerDisplay() {
            const minutes = Math.floor(timeLeft / 60);
            const seconds = timeLeft % 60;

            timerElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

            // Color change when less than 1 minute
            if (timeLeft < 60) {
                timerElement.style.color = '#ef4444';
            }

            if (timeLeft <= 0) {
                clearInterval(timerInterval);
                timerElement.textContent = '00:00';

                // Show expired message
                const timerNote = document.querySelector('.timer-note');
                if (timerNote) {
                    timerNote.textContent = 'Reset link has expired. Please request a new one.';
                    timerNote.style.color = '#ef4444';
                }
            }
        }

        // Initial display
        updateTimerDisplay();
    }
}

// Start Countdown Timer
function startCountdownTimer() {
    const timerElement = document.querySelector('.timer-display');

    if (timerElement) {
        let timeLeft = 5 * 60; // Reset to 5 minutes

        // Clear any existing interval
        if (window.countdownInterval) {
            clearInterval(window.countdownInterval);
        }

        // Update timer every second
        window.countdownInterval = setInterval(() => {
            timeLeft--;

            // Update display
            const minutes = Math.floor(timeLeft / 60);
            const seconds = timeLeft % 60;

            timerElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

            // Color change when less than 1 minute
            if (timeLeft < 60) {
                timerElement.style.color = '#ef4444';
            }

            if (timeLeft <= 0) {
                clearInterval(window.countdownInterval);
                timerElement.textContent = '00:00';

                // Show expired message
                const timerNote = document.querySelector('.timer-note');
                if (timerNote) {
                    timerNote.textContent = 'Reset link has expired. Please request a new one.';
                    timerNote.style.color = '#ef4444';
                }
            }
        }, 1000);
    }
}

// Simulate API Call
function simulateAPICall() {
    return new Promise((resolve) => {
        // Simulate network delay
        setTimeout(() => {
            resolve({ success: true });
        }, 1500);
    });
}

// Show Alert Function (from auth.js)
function showAlert(message, type = 'info') {
    // Remove existing alerts
    const existingAlert = document.querySelector('.alert-message');
    if (existingAlert) {
        existingAlert.remove();
    }

    // Create alert element
    const alert = document.createElement('div');
    alert.className = `alert-message alert-${type}`;

    // Set icon based on type
    let icon = 'info-circle';
    if (type === 'success') icon = 'check-circle';
    if (type === 'error') icon = 'exclamation-circle';
    if (type === 'warning') icon = 'exclamation-triangle';

    alert.innerHTML = `
        <i class="fas fa-${icon}"></i>
        <span>${message}</span>
        <button class="alert-close" onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;

    // Add styles
    alert.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: var(--border-radius);
        display: flex;
        align-items: center;
        gap: 10px;
        box-shadow: var(--box-shadow);
        z-index: 10000;
        max-width: 400px;
        animation: slideInRight 0.3s ease-out;
    `;

    // Set colors based on type
    const colors = {
        success: { bg: '#d1fae5', text: '#065f46', border: '#a7f3d0' },
        error: { bg: '#fee2e2', text: '#991b1b', border: '#fecaca' },
        warning: { bg: '#fef3c7', text: '#92400e', border: '#fde68a' },
        info: { bg: '#dbeafe', text: '#1e40af', border: '#bfdbfe' }
    };

    alert.style.background = colors[type].bg;
    alert.style.color = colors[type].text;
    alert.style.border = `1px solid ${colors[type].border}`;

    document.body.appendChild(alert);

    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (alert.parentElement) {
            alert.style.animation = 'fadeOut 0.3s ease-out';
            setTimeout(() => alert.remove(), 300);
        }
    }, 5000);
}

// Email Validation Indicator
function initEmailValidation() {
    const emailInput = document.getElementById('email');
    if (emailInput) {
        emailInput.addEventListener('input', function() {
            const isValid = validateEmail(this.value);
            const inputGroup = this.closest('.input-with-icon');

            if (inputGroup) {
                if (this.value === '') {
                    inputGroup.classList.remove('valid', 'invalid');
                } else if (isValid) {
                    inputGroup.classList.add('valid');
                    inputGroup.classList.remove('invalid');
                } else {
                    inputGroup.classList.add('invalid');
                    inputGroup.classList.remove('valid');
                }
            }
        });
    }
}

// Initialize email validation
initEmailValidation();

// Export functions for global use
window.resendResetEmail = resendResetEmail;
window.showAlert = showAlert;

// Additional CSS for validation states (add to auth.css)
const style = document.createElement('style');
style.textContent = `
    .input-with-icon.valid {
        border-color: #10b981 !important;
    }
    
    .input-with-icon.valid::after {
        content: '✓';
        position: absolute;
        right: 40px;
        color: #10b981;
        font-weight: bold;
    }
    
    .input-with-icon.invalid {
        border-color: #ef4444 !important;
    }
    
    .input-with-icon.invalid::after {
        content: '✗';
        position: absolute;
        right: 40px;
        color: #ef4444;
        font-weight: bold;
    }
    
    @keyframes fadeOut {
        from { opacity: 1; }
        to { opacity: 0; }
    }
`;
document.head.appendChild(style);