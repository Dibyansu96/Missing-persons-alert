// Dashboard JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize dashboard components
    initDashboardCharts();
    initUserMenu();
    initQuickActions();
    loadDashboardData();

    // Check authentication
    checkDashboardAuth();
});

// Initialize Dashboard Charts
function initDashboardCharts() {
    // This would initialize charts using Chart.js or similar library
    // For now, we'll create a simple placeholder

    const chartContainers = document.querySelectorAll('.chart-container');

    chartContainers.forEach(container => {
        if (!container.hasAttribute('data-initialized')) {
            const type = container.getAttribute('data-chart-type') || 'bar';
            const placeholder = document.createElement('div');
            placeholder.className = 'chart-placeholder';
            placeholder.innerHTML = `
                <div style="padding: 2rem; text-align: center; color: var(--gray-color);">
                    <i class="fas fa-chart-${type}" style="font-size: 3rem; margin-bottom: 1rem;"></i>
                    <h4>Chart Visualization</h4>
                    <p>In production, this would show ${type} chart with real data</p>
                </div>
            `;
            container.appendChild(placeholder);
            container.setAttribute('data-initialized', 'true');
        }
    });
}

// Initialize User Menu
function initUserMenu() {
    const userToggle = document.querySelector('.user-toggle');
    const userDropdown = document.querySelector('.user-dropdown');

    if (userToggle && userDropdown) {
        userToggle.addEventListener('click', function(e) {
            e.stopPropagation();
            userDropdown.classList.toggle('active');
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', function() {
            userDropdown.classList.remove('active');
        });

        // Prevent dropdown from closing when clicking inside
        userDropdown.addEventListener('click', function(e) {
            e.stopPropagation();
        });
    }
}

// Initialize Quick Actions
function initQuickActions() {
    const quickActions = document.querySelectorAll('.quick-action');

    quickActions.forEach(action => {
        action.addEventListener('click', function(e) {
            // Add click animation
            this.classList.add('clicked');
            setTimeout(() => {
                this.classList.remove('clicked');
            }, 300);
        });
    });
}

// Load Dashboard Data
async function loadDashboardData() {
    try {
        // Show loading state
        showLoading(true);

        // Simulate API calls for dashboard data
        const [stats, reports, activities] = await Promise.all([
            fetchDashboardStats(),
            fetchUserReports(),
            fetchRecentActivities()
        ]);

        // Update dashboard with data
        updateDashboardStats(stats);
        updateUserReports(reports);
        updateRecentActivities(activities);

        // Hide loading state
        showLoading(false);

    } catch (error) {
        console.error('Error loading dashboard data:', error);
        showLoading(false);
        showAlert('Failed to load dashboard data. Please try again.', 'error');
    }
}

// Fetch Dashboard Statistics
async function fetchDashboardStats() {
    // Simulate API call
    return new Promise(resolve => {
        setTimeout(() => {
            resolve({
                activeReports: 2,
                caseViews: 48,
                activeAlerts: 3,
                sightingsReported: 12,
                volunteerHours: 24,
                successRate: '78%'
            });
        }, 1000);
    });
}

// Fetch User Reports
async function fetchUserReports() {
    // Simulate API call
    return new Promise(resolve => {
        setTimeout(() => {
            resolve([{
                    id: 1,
                    name: 'Emma Johnson',
                    status: 'active',
                    date: '2 days ago',
                    location: 'New York',
                    views: 124,
                    tips: 8,
                    shares: 42
                },
                {
                    id: 2,
                    name: 'Michael Chen',
                    status: 'found',
                    date: '1 month ago',
                    location: 'San Francisco',
                    views: 892,
                    tips: 24,
                    shares: 156
                }
            ]);
        }, 800);
    });
}

// Fetch Recent Activities
async function fetchRecentActivities() {
    // Simulate API call
    return new Promise(resolve => {
        setTimeout(() => {
            resolve([{
                    type: 'alert',
                    title: 'New alert for your area',
                    description: 'Missing person reported within 5 miles of your location',
                    time: '2 hours ago',
                    icon: 'bell'
                },
                {
                    type: 'tip',
                    title: 'New tip received',
                    description: 'Someone reported a possible sighting for case #1234',
                    time: '1 day ago',
                    icon: 'comment'
                },
                {
                    type: 'share',
                    title: 'Case shared 12 times',
                    description: 'Your missing person report has been shared across social media',
                    time: '2 days ago',
                    icon: 'share-alt'
                }
            ]);
        }, 600);
    });
}

// Update Dashboard Statistics
function updateDashboardStats(stats) {
    // Update stat cards if they exist
    const statElements = {
        activeReports: document.querySelector('.stat-card:nth-child(1) h3'),
        caseViews: document.querySelector('.stat-card:nth-child(2) h3'),
        activeAlerts: document.querySelector('.stat-card:nth-child(3) h3'),
        sightingsReported: document.querySelector('.stat-card:nth-child(4) h3')
    };

    if (statElements.activeReports) {
        statElements.activeReports.textContent = stats.activeReports;
    }
    if (statElements.caseViews) {
        statElements.caseViews.textContent = stats.caseViews;
    }
    if (statElements.activeAlerts) {
        statElements.activeAlerts.textContent = stats.activeAlerts;
    }
    if (statElements.sightingsReported) {
        statElements.sightingsReported.textContent = stats.sightingsReported;
    }
}

// Update User Reports
function updateUserReports(reports) {
    // This would update the reports list with real data
    // For now, the template already has sample data
}

// Update Recent Activities
function updateRecentActivities(activities) {
    // This would update the activities timeline with real data
    // For now, the template already has sample data
}

// Show/Hide Loading State
function showLoading(show) {
    const loadingIndicator = document.getElementById('loadingIndicator');

    if (show) {
        if (!loadingIndicator) {
            const loader = document.createElement('div');
            loader.id = 'loadingIndicator';
            loader.className = 'loading-overlay';
            loader.innerHTML = `
                <div class="loading-spinner"></div>
                <p>Loading dashboard data...</p>
            `;
            document.querySelector('.dashboard-content').appendChild(loader);
        }
    } else {
        if (loadingIndicator) {
            loadingIndicator.remove();
        }
    }
}

// Check Dashboard Authentication
function checkDashboardAuth() {
    const user = localStorage.getItem('findthem_user');

    if (!user) {
        // Redirect to login if not authenticated
        window.location.href = '../auth/login.html?redirect=' + encodeURIComponent(window.location.pathname);
        return;
    }

    // Update user info in dashboard
    try {
        const userData = JSON.parse(user);
        updateUserInfo(userData);
    } catch (error) {
        console.error('Error parsing user data:', error);
    }
}

// Update User Information
function updateUserInfo(userData) {
    // Update user name in dashboard
    const userToggle = document.querySelector('.user-toggle span');
    if (userToggle) {
        userToggle.textContent = userData.name.split(' ')[0];
    }

    const dashboardTitle = document.querySelector('.dashboard-title p');
    if (dashboardTitle) {
        dashboardTitle.textContent = `Welcome back, ${userData.name.split(' ')[0]}. Here's an overview of your activity.`;
    }

    // Update user avatar if exists
    const userAvatar = document.querySelector('.user-toggle img');
    if (userAvatar && userData.avatar) {
        userAvatar.src = userData.avatar;
    }
}

// Logout Function
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('findthem_user');
        localStorage.removeItem('findthem_token');
        window.location.href = '../index.html';
    }
}

// Export functions
window.logout = logout;