// Case Details JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize case details page
    initCaseDetails();
    initSightingForm();
    initShareButtons();
    initContactButtons();
    loadCaseData();
});

// Initialize Case Details
function initCaseDetails() {
    // Get case ID from URL
    const urlParams = new URLSearchParams(window.location.search);
    const caseId = urlParams.get('id') || '1';

    // Set case ID in title or other elements if needed
    document.title = `Case #${caseId} - FindThem`;

    // Check authentication for reporting
    checkAuthForReporting();
}

// Load Case Data
async function loadCaseData() {
    const caseId = new URLSearchParams(window.location.search).get('id') || '1';

    try {
        // Show loading state
        showLoading(true);

        // Fetch case details
        const caseData = await fetchCaseDetails(caseId);

        // Update page with case data
        updateCaseDetails(caseData);

        // Hide loading
        showLoading(false);

    } catch (error) {
        console.error('Error loading case details:', error);
        showLoading(false);
        showAlert('Failed to load case details. Please try again.', 'error');
    }
}

// Fetch Case Details
async function fetchCaseDetails(caseId) {
    // Simulate API call
    return new Promise((resolve) => {
        setTimeout(() => {
            // Sample case data - in production, this would come from API
            const cases = {
                '1': {
                    id: 1,
                    name: "Emma Johnson",
                    age: 28,
                    location: "New York, USA",
                    timeAgo: "2 hours ago",
                    description: "Emma Johnson was last seen at approximately 3:45 PM near Central Park West. She was wearing a blue denim jacket, white t-shirt, and black jeans. She has blonde hair and blue eyes, standing at 5'6\" tall.",
                    status: "critical",
                    gender: "female",
                    category: "adult",
                    tags: ["amber", "medical"],
                    caseNumber: "MP-2024-0427",
                    reportedDate: "April 27, 2024 4:15 PM",
                    policeCase: "NYPD-2024-8723",
                    agency: "NYPD Missing Persons Unit",
                    height: "5'6\" (168 cm)",
                    weight: "130 lbs (59 kg)",
                    hair: "Blonde",
                    eyes: "Blue",
                    build: "Average",
                    complexion: "Fair",
                    features: [
                        "Small butterfly tattoo on right wrist",
                        "Pierced ears (two piercings each)",
                        "Small scar above left eyebrow",
                        "Wears prescription glasses"
                    ],
                    clothing: {
                        top: "Blue denim jacket over white cotton t-shirt",
                        bottom: "Black slim-fit jeans",
                        footwear: "White sneakers with blue stripes",
                        accessories: "Red backpack, silver watch on left wrist"
                    },
                    lastSeen: {
                        location: "Central Park West, New York",
                        details: "Near the entrance at 72nd Street",
                        time: "Approximately 3:45 PM",
                        direction: "Heading toward subway station",
                        weather: "Clear, 65°F at the time"
                    },
                    contacts: {
                        family: {
                            name: "Michael Johnson (Brother)",
                            phone: "(212) 555-1234"
                        },
                        police: {
                            name: "Detective Sarah Miller",
                            phone: "(212) 555-5678"
                        },
                        volunteer: {
                            name: "FindThem Volunteer Team",
                            email: "case.mp-2024-0427@findthem.org"
                        }
                    },
                    medicalAlert: "Emma requires daily medication for a heart condition. Urgent medical attention may be needed.",
                    stats: {
                        shares: 142,
                        sightings: 8,
                        views: 2400
                    }
                },
                '2': {
                    id: 2,
                    name: "David Chen",
                    age: 45,
                    location: "Toronto, Canada",
                    timeAgo: "5 hours ago",
                    description: "Missing after not returning from evening walk. Has medical condition.",
                    status: "active",
                    gender: "male",
                    category: "adult"
                },
                '3': {
                    id: 3,
                    name: "Sophia Rodriguez",
                    age: 16,
                    location: "Madrid, Spain",
                    timeAgo: "1 day ago",
                    description: "Student missing after school. Last seen near city center.",
                    status: "recent",
                    gender: "female",
                    category: "teen"
                }
            };

            resolve(cases[caseId] || cases['1']);
        }, 500);
    });
}

// Update Case Details on Page
function updateCaseDetails(caseData) {
    // Update header
    document.querySelector('.case-details-header h1').textContent = caseData.name;
    document.querySelector('.case-status-badge').className = `case-status-badge ${caseData.status}`;
    document.querySelector('.case-status-badge').innerHTML = `<i class="fas fa-exclamation-triangle"></i> ${caseData.status === 'critical' ? 'Critical Case' : 'Active Case'}`;

    // Update meta information
    const metaElements = document.querySelectorAll('.case-meta-large span');
    if (metaElements.length >= 4) {
        metaElements[0].innerHTML = `<i class="fas fa-user"></i> ${caseData.age} years old`;
        metaElements[1].innerHTML = `<i class="fas fa-${caseData.gender === 'female' ? 'venus' : 'mars'}"></i> ${caseData.gender}`;
        metaElements[2].innerHTML = `<i class="fas fa-map-marker-alt"></i> ${caseData.location}`;
        metaElements[3].innerHTML = `<i class="far fa-clock"></i> Missing since ${caseData.timeAgo}`;
    }

    // Update description
    document.querySelector('.case-description').innerHTML = `
        <p>${caseData.description}</p>
        ${caseData.description.length > 150 ? `<p>Her family is extremely concerned as she has a medical condition that requires medication. She was expected home for dinner and has not been in contact with anyone since this afternoon.</p>` : ''}
    `;
    
    // Update physical details
    if (caseData.height) {
        document.querySelectorAll('.physical-detail')[0].querySelector('.detail-value').textContent = caseData.height;
        document.querySelectorAll('.physical-detail')[1].querySelector('.detail-value').textContent = caseData.weight;
        document.querySelectorAll('.physical-detail')[2].querySelector('.detail-value').textContent = caseData.hair;
        document.querySelectorAll('.physical-detail')[3].querySelector('.detail-value').textContent = caseData.eyes;
        document.querySelectorAll('.physical-detail')[4].querySelector('.detail-value').textContent = caseData.build;
        document.querySelectorAll('.physical-detail')[5].querySelector('.detail-value').textContent = caseData.complexion;
    }
    
    // Update distinguishing features
    if (caseData.features) {
        const featuresList = document.querySelector('.distinguishing-features ul');
        featuresList.innerHTML = caseData.features.map(feature => `<li>${feature}</li>`).join('');
    }
    
    // Update clothing
    if (caseData.clothing) {
        document.querySelectorAll('.clothing-info')[0].querySelector('p').textContent = caseData.clothing.top;
        document.querySelectorAll('.clothing-info')[1].querySelector('p').textContent = caseData.clothing.bottom;
        document.querySelectorAll('.clothing-info')[2].querySelector('p').textContent = caseData.clothing.footwear;
        document.querySelectorAll('.clothing-info')[3].querySelector('p').textContent = caseData.clothing.accessories;
    }
    
    // Update case information
    if (caseData.caseNumber) {
        document.querySelectorAll('.info-item')[0].querySelector('.info-value').textContent = caseData.caseNumber;
        document.querySelectorAll('.info-item')[1].querySelector('.info-value').textContent = caseData.reportedDate;
        document.querySelectorAll('.info-item')[3].querySelector('.info-value').textContent = caseData.policeCase;
        document.querySelectorAll('.info-item')[4].querySelector('.info-value').textContent = caseData.agency;
    }
    
    // Update contacts
    if (caseData.contacts) {
        document.querySelectorAll('.contact-item')[0].querySelector('p').textContent = caseData.contacts.family.name;
        document.querySelectorAll('.contact-item')[0].querySelector('a').textContent = caseData.contacts.family.phone;
        document.querySelectorAll('.contact-item')[0].querySelector('a').href = `tel:${caseData.contacts.family.phone.replace(/[^\d+]/g, '')}`;
        
        document.querySelectorAll('.contact-item')[1].querySelector('p').textContent = caseData.contacts.police.name;
        document.querySelectorAll('.contact-item')[1].querySelector('a').textContent = caseData.contacts.police.phone;
        document.querySelectorAll('.contact-item')[1].querySelector('a').href = `tel:${caseData.contacts.police.phone.replace(/[^\d+]/g, '')}`;
        
        document.querySelectorAll('.contact-item')[2].querySelector('p').textContent = caseData.contacts.volunteer.name;
        document.querySelectorAll('.contact-item')[2].querySelector('a').textContent = caseData.contacts.volunteer.email;
        document.querySelectorAll('.contact-item')[2].querySelector('a').href = `mailto:${caseData.contacts.volunteer.email}`;
    }
    
    // Update medical alert
    if (caseData.medicalAlert) {
        document.querySelector('.alert-content p').textContent = caseData.medicalAlert;
    }
    
    // Update share stats
    if (caseData.stats) {
        document.querySelectorAll('.share-stat')[0].querySelector('.stat-number').textContent = caseData.stats.shares;
        document.querySelectorAll('.share-stat')[1].querySelector('.stat-number').textContent = caseData.stats.sightings;
        document.querySelectorAll('.share-stat')[2].querySelector('.stat-number').textContent = caseData.stats.views.toLocaleString();
    }
    
    // Update page title
    document.title = `${caseData.name} - Missing Person Case - FindThem`;
}

// Initialize Sighting Form
function initSightingForm() {
    const form = document.getElementById('sightingForm');
    if (form) {
        form.addEventListener('submit', handleSightingReport);
        
        // Set default time to now
        const timeInput = document.getElementById('sightingTime');
        if (timeInput) {
            const now = new Date();
            const localDateTime = new Date(now.getTime() - now.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
            timeInput.value = localDateTime;
        }
    }
}

// Handle Sighting Report
async function handleSightingReport(e) {
    e.preventDefault();
    
    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');
    
    // Get form data
    const formData = {
        location: form.sightingLocation.value.trim(),
        time: form.sightingTime.value,
        details: form.sightingDetails.value.trim(),
        contactInfo: form.contactInfo.value.trim(),
        anonymous: false
    };
    
    // Validate
    if (!formData.location || !formData.details) {
        showAlert('Please provide location and details of the sighting.', 'error');
        return;
    }
    
    // Show loading
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
    submitBtn.disabled = true;
    
    try {
        // Submit report
        await submitSightingReport(formData);
        
        // Show success modal
        showSuccessModal();
        
        // Reset form
        form.reset();
        
        // Update time to current
        const timeInput = document.getElementById('sightingTime');
        if (timeInput) {
            const now = new Date();
            const localDateTime = new Date(now.getTime() - now.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
            timeInput.value = localDateTime;
        }
        
    } catch (error) {
        showAlert('Failed to submit sighting report. Please try again.', 'error');
    } finally {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }
}

// Report Anonymously
function reportAnonymously() {
    const form = document.getElementById('sightingForm');
    if (form) {
        form.contactInfo.value = '';
        form.dispatchEvent(new Event('submit'));
    }
}

// Submit Sighting Report
async function submitSightingReport(data) {
    // Simulate API call
    return new Promise((resolve) => {
        setTimeout(() => {
            console.log('Sighting report submitted:', data);
            resolve({ success: true });
        }, 1500);
    });
}

// Initialize Share Buttons
function initShareButtons() {
    // Share case function
    window.shareCase = function() {
        const caseId = new URLSearchParams(window.location.search).get('id') || '1';
        const caseName = document.querySelector('.case-details-header h1').textContent;
        
        if (navigator.share) {
            navigator.share({
                title: `Missing: ${caseName}`,
                text: `Help find ${caseName}. Last seen ${document.querySelector('.case-meta-large span:nth-child(4)').textContent.replace('Missing since ', '')}`,
                url: window.location.href
            });
        } else {
            // Fallback: Open share dialog
            copyCaseLink();
        }
    };
}

// Share on Social Media
function shareSocial(platform) {
    const url = encodeURIComponent(window.location.href);
    const title = encodeURIComponent(document.querySelector('.case-details-header h1').textContent);
    const text = encodeURIComponent(`Help find this missing person.`);
    
    let shareUrl = '';
    
    switch (platform) {
        case 'facebook':
            shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${url}`;
            break;
        case 'twitter':
            shareUrl = `https://twitter.com/intent/tweet?url=${url}&text=${text}`;
            break;
        case 'whatsapp':
            shareUrl = `https://wa.me/?text=${text}%20${url}`;
            break;
    }
    
    if (shareUrl) {
        window.open(shareUrl, '_blank', 'width=600,height=400');
    }
}

// Copy Case Link
function copyCaseLink() {
    const url = window.location.href;
    navigator.clipboard.writeText(url)
        .then(() => {
            showAlert('Case link copied to clipboard!', 'success');
        })
        .catch(err => {
            console.error('Failed to copy: ', err);
            showAlert('Failed to copy link. Please copy manually.', 'error');
        });
}

// Initialize Contact Buttons
function initContactButtons() {
    // Make phone numbers clickable
    document.querySelectorAll('a[href^="tel:"]').forEach(link => {
        link.addEventListener('click', function(e) {
            if (!confirm(`Call ${this.textContent}?`)) {
                e.preventDefault();
            }
        });
    });
}

// Print Case Flyer
function printCase() {
    // In production, this would generate a printable flyer
    showAlert('Print feature coming soon. For now, use browser print (Ctrl+P).', 'info');
    
    // Optionally open print dialog
    // window.print();
}

// Show All Contacts
function showAllContacts() {
    // In production, this would show a modal with all contact information
    showAlert('Full contact list would be displayed here.', 'info');
}

// Show All Sightings
function showAllSightings() {
    // In production, this would load and display all sightings
    showAlert('Loading all sighting reports...', 'info');
}

// Show Success Modal
function showSuccessModal() {
    const modal = document.getElementById('successModal');
    if (modal) {
        modal.classList.add('show');
        modal.style.display = 'flex';
    }
}

// Close Modal
function closeModal() {
    const modal = document.getElementById('successModal');
    if (modal) {
        modal.classList.remove('show');
        setTimeout(() => {
            modal.style.display = 'none';
        }, 300);
    }
}

// Show Loading State
function showLoading(show) {
    const loadingIndicator = document.createElement('div');
    loadingIndicator.id = 'loadingOverlay';
    loadingIndicator.innerHTML = `
        <div class="loading-spinner"></div>
        <p>Loading case details...</p>
    `;
    loadingIndicator.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(255, 255, 255, 0.9);
        display: ${show ? 'flex' : 'none'};
        flex-direction: column;
        align-items: center;
        justify-content: center;
        z-index: 10000;
    `;
    
    if (show) {
        document.body.appendChild(loadingIndicator);
    } else {
        const existing = document.getElementById('loadingOverlay');
        if (existing) existing.remove();
    }
}

// Check Authentication for Reporting
function checkAuthForReporting() {
    const user = localStorage.getItem('findthem_user');
    const sightingForm = document.getElementById('sightingForm');
    
    if (!user && sightingForm) {
        // Add note about anonymous reporting
        const authNote = document.createElement('div');
        authNote.className = 'auth-note';
        authNote.innerHTML = `
            <p><i class="fas fa-info-circle"></i> You can report sightings anonymously. Login to track your reports.</p>
        `;
        sightingForm.parentNode.insertBefore(authNote, sightingForm);
    }
}

// Show Alert
function showAlert(message, type = 'info') {
    const existingAlert = document.querySelector('.alert-message');
    if (existingAlert) existingAlert.remove();
    
    const alert = document.createElement('div');
    alert.className = `alert-message alert-${type}`;
    
    let icon = 'info-circle';
    if (type === 'success') icon = 'check-circle';
    if (type === 'error') icon = 'exclamation-circle';
    if (type === 'warning') icon = 'exclamation-triangle';
    
    alert.innerHTML = `
        <i class="fas fa-${icon}"></i>
        <span>${message}</span>
        <button class="alert-close" onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    alert.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: var(--border-radius);
        display: flex;
        align-items: center;
        gap: 10px;
        box-shadow: var(--box-shadow);
        z-index: 10000;
        max-width: 400px;
        animation: slideInRight 0.3s ease-out;
    `;
    
    const colors = {
        success: { bg: '#d1fae5', text: '#065f46', border: '#a7f3d0' },
        error: { bg: '#fee2e2', text: '#991b1b', border: '#fecaca' },
        warning: { bg: '#fef3c7', text: '#92400e', border: '#fde68a' },
        info: { bg: '#dbeafe', text: '#1e40af', border: '#bfdbfe' }
    };
    
    alert.style.background = colors[type].bg;
    alert.style.color = colors[type].text;
    alert.style.border = `1px solid ${colors[type].border}`;
    
    document.body.appendChild(alert);
    
    setTimeout(() => {
        if (alert.parentElement) {
            alert.style.animation = 'fadeOut 0.3s ease-out';
            setTimeout(() => alert.remove(), 300);
        }
    }, 5000);
}

// Export functions for global use
window.shareCase = shareCase;
window.shareSocial = shareSocial;
window.copyCaseLink = copyCaseLink;
window.printCase = printCase;
window.showAllContacts = showAllContacts;
window.showAllSightings = showAllSightings;
window.reportAnonymously = reportAnonymously;
window.closeModal = closeModal;