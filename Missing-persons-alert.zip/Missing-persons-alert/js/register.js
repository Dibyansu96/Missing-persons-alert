// Registration JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize form submission
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }

    // Initialize components
    initBackToTop();
    initEmailValidation();
    initPasswordStrengthChecker();
    initPasswordMatchChecker();
    initCaptcha();
    initUserTypeSelection();
    initStatsCounter();

    // Add animation classes
    setTimeout(() => {
        document.querySelector('.auth-card') ? .classList.add('fade-in');
        document.querySelectorAll('.benefit-card').forEach((card, index) => {
            card.style.animationDelay = `${index * 0.1}s`;
            card.classList.add('fade-in');
        });
    }, 100);
});

// Handle Registration Form Submission
async function handleRegister(e) {
    e.preventDefault();

    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');

    // Validate form
    if (!validateRegistrationForm(form)) {
        return;
    }

    // Validate CAPTCHA
    const captchaInput = document.getElementById('captchaInput').value;
    const captchaText = document.getElementById('captchaText').textContent;

    if (captchaInput !== captchaText) {
        showAlert('CAPTCHA verification failed. Please try again.', 'error');
        refreshCaptcha();
        return;
    }

    // Collect form data
    const formData = {
        firstName: form.firstName.value.trim(),
        lastName: form.lastName.value.trim(),
        email: form.email.value.trim(),
        phone: form.phone.value.trim(),
        password: form.password.value,
        userType: form.userType.value,
        location: form.location.value.trim(),
        terms: form.terms.checked,
        newsletter: form.newsletter.checked,
        emergencyAlerts: form.emergencyAlerts.checked
    };

    // Show loading state
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating Account...';
    submitBtn.disabled = true;

    try {
        // Simulate API call
        const response = await registerUser(formData);

        if (response.success) {
            // Show success message
            showSuccessMessage(formData.email);

            // Hide form
            form.style.display = 'none';

            // Store user data temporarily
            localStorage.setItem('findthem_pending_user', JSON.stringify({
                email: formData.email,
                name: `${formData.firstName} ${formData.lastName}`,
                timestamp: Date.now()
            }));

        } else {
            throw new Error(response.message || 'Registration failed');
        }

    } catch (error) {
        showAlert(error.message || 'Registration failed. Please try again.', 'error');

        // Reset button
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;

        // Refresh CAPTCHA
        refreshCaptcha();
    }
}

// Validate Registration Form
function validateRegistrationForm(form) {
    let isValid = true;
    const errors = [];

    // Check required fields
    const requiredFields = ['firstName', 'lastName', 'email', 'password', 'confirmPassword', 'terms'];
    requiredFields.forEach(field => {
        const element = form[field];
        if (element && !element.value && !element.checked) {
            errors.push(`${field.replace(/([A-Z])/g, ' $1')} is required`);
            element.classList.add('error');
            isValid = false;
        } else if (element) {
            element.classList.remove('error');
        }
    });

    // Validate email format
    const email = form.email.value;
    if (email && !validateEmail(email)) {
        errors.push('Please enter a valid email address');
        form.email.classList.add('error');
        isValid = false;
    }

    // Validate password match
    const password = form.password.value;
    const confirmPassword = form.confirmPassword.value;
    if (password && confirmPassword && password !== confirmPassword) {
        errors.push('Passwords do not match');
        form.confirmPassword.classList.add('error');
        isValid = false;
    }

    // Validate password strength
    if (password && !validatePasswordStrength(password)) {
        errors.push('Password does not meet security requirements');
        isValid = false;
    }

    // Show errors if any
    if (errors.length > 0) {
        showAlert(errors.join('<br>'), 'error');
    }

    return isValid;
}

// Validate Email Format
function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Validate Password Strength
function validatePasswordStrength(password) {
    const requirements = {
        length: password.length >= 8,
        uppercase: /[A-Z]/.test(password),
        lowercase: /[a-z]/.test(password),
        number: /[0-9]/.test(password),
        special: /[^A-Za-z0-9]/.test(password)
    };

    return Object.values(requirements).every(req => req);
}

// Initialize Email Validation
function initEmailValidation() {
    const emailInput = document.getElementById('email');
    const emailStatus = document.getElementById('emailStatus');

    if (emailInput && emailStatus) {
        let validationTimer;

        emailInput.addEventListener('input', function() {
            clearTimeout(validationTimer);
            const email = this.value.trim();

            if (!email) {
                emailStatus.textContent = '';
                emailStatus.className = 'email-status';
                return;
            }

            if (!validateEmail(email)) {
                emailStatus.textContent = 'Invalid email format';
                emailStatus.className = 'email-status invalid';
                return;
            }

            emailStatus.textContent = 'Checking availability...';
            emailStatus.className = 'email-status loading';

            validationTimer = setTimeout(async() => {
                try {
                    const isAvailable = await checkEmailAvailability(email);

                    if (isAvailable) {
                        emailStatus.textContent = 'Email is available';
                        emailStatus.className = 'email-status valid';
                    } else {
                        emailStatus.textContent = 'Email is already registered';
                        emailStatus.className = 'email-status invalid';
                    }
                } catch (error) {
                    emailStatus.textContent = 'Unable to verify email';
                    emailStatus.className = 'email-status invalid';
                }
            }, 500);
        });
    }
}

// Check Email Availability
async function checkEmailAvailability(email) {
    // Simulate API call
    return new Promise((resolve) => {
        setTimeout(() => {
            // For demo, reject common test emails
            const takenEmails = ['test@test.com', 'admin@admin.com', 'user@example.com'];
            resolve(!takenEmails.includes(email.toLowerCase()));
        }, 800);
    });
}

// Initialize Password Strength Checker
function initPasswordStrengthChecker() {
    const passwordInput = document.getElementById('password');
    if (passwordInput) {
        passwordInput.addEventListener('input', function() {
            updatePasswordStrength(this.value);
            updatePasswordRequirements(this.value);
        });
    }
}

// Update Password Strength
function updatePasswordStrength(password) {
    const strength = checkPasswordStrength(password);
    const meter = document.getElementById('passwordStrength');
    const text = document.getElementById('passwordStrengthText');

    if (!meter || !text) return;

    const levels = [
        { text: 'Very Weak', color: '#ef4444', width: '20%' },
        { text: 'Weak', color: '#f97316', width: '40%' },
        { text: 'Fair', color: '#eab308', width: '60%' },
        { text: 'Good', color: '#84cc16', width: '80%' },
        { text: 'Strong', color: '#10b981', width: '100%' }
    ];

    const level = levels[strength] || levels[0];

    // Update meter
    meter.style.width = level.width;
    meter.style.backgroundColor = level.color;

    // Update text
    text.textContent = level.text;
    text.style.color = level.color;

    // Update parent class for styling
    const strengthContainer = document.querySelector('.password-strength');
    if (strengthContainer) {
        strengthContainer.className = `password-strength password-strength-${strength}`;
    }
}

// Update Password Requirements UI
function updatePasswordRequirements(password) {
    const requirements = {
        length: password.length >= 8,
        uppercase: /[A-Z]/.test(password),
        lowercase: /[a-z]/.test(password),
        number: /[0-9]/.test(password),
        special: /[^A-Za-z0-9]/.test(password)
    };

    Object.keys(requirements).forEach(req => {
        const element = document.getElementById(`req-${req}`);
        if (element) {
            const icon = element.querySelector('i');
            if (requirements[req]) {
                icon.className = 'fas fa-check-circle';
                icon.style.color = '#10b981';
            } else {
                icon.className = 'fas fa-times-circle';
                icon.style.color = '#ef4444';
            }
        }
    });
}

// Initialize Password Match Checker
function initPasswordMatchChecker() {
    const passwordInput = document.getElementById('password');
    const confirmInput = document.getElementById('confirmPassword');

    if (passwordInput && confirmInput) {
        [passwordInput, confirmInput].forEach(input => {
            input.addEventListener('input', checkPasswordMatch);
        });
    }
}

// Check Password Match
function checkPasswordMatch() {
    const password = document.getElementById('password') ? .value;
    const confirmPassword = document.getElementById('confirmPassword') ? .value;
    const indicator = document.getElementById('passwordMatchIndicator');

    if (!indicator) return;

    if (!confirmPassword) {
        indicator.style.display = 'none';
        return;
    }

    if (password === confirmPassword) {
        indicator.innerHTML = '<i class="fas fa-check-circle"></i> <span>Passwords match</span>';
        indicator.style.color = '#10b981';
        indicator.style.display = 'flex';
    } else {
        indicator.innerHTML = '<i class="fas fa-times-circle"></i> <span>Passwords do not match</span>';
        indicator.style.color = '#ef4444';
        indicator.style.display = 'flex';
    }
}

// Initialize CAPTCHA
function initCaptcha() {
    refreshCaptcha();

    // Add input validation
    const captchaInput = document.getElementById('captchaInput');
    if (captchaInput) {
        captchaInput.addEventListener('input', function() {
            this.value = this.value.toUpperCase();
        });
    }
}

// Refresh CAPTCHA
function refreshCaptcha() {
    const captchaText = document.getElementById('captchaText');
    if (captchaText) {
        // Generate random CAPTCHA
        const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        let captcha = '';
        for (let i = 0; i < 6; i++) {
            captcha += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        captchaText.textContent = captcha;

        // Clear input
        const captchaInput = document.getElementById('captchaInput');
        if (captchaInput) {
            captchaInput.value = '';
        }
    }
}

// Initialize User Type Selection
function initUserTypeSelection() {
    // Set default selection
    selectUserType('volunteer');
}

// Select User Type
function selectUserType(type) {
    // Update all options
    document.querySelectorAll('.user-type-option').forEach(option => {
        option.classList.remove('selected');
    });

    // Select clicked option
    const selectedOption = document.querySelector(`.user-type-option[onclick*="${type}"]`);
    if (selectedOption) {
        selectedOption.classList.add('selected');
    }

    // Update hidden input
    const userTypeInput = document.getElementById('userType');
    if (userTypeInput) {
        userTypeInput.value = type;
    }
}

// Initialize Stats Counter
function initStatsCounter() {
    const stats = {
        communitySize: document.getElementById('communitySize'),
        successStories: document.getElementById('successStories'),
        countriesCovered: document.getElementById('countriesCovered')
    };

    const targetValues = {
        communitySize: 10247,
        successStories: 892,
        countriesCovered: 124
    };

    Object.keys(stats).forEach(key => {
        if (stats[key]) {
            animateCounter(stats[key], targetValues[key]);
        }
    });
}

// Animate Counter
function animateCounter(element, target) {
    const duration = 2000;
    const step = target / (duration / 16);
    let current = 0;

    const timer = setInterval(() => {
        current += step;
        if (current >= target) {
            element.textContent = formatNumber(target);
            clearInterval(timer);
        } else {
            element.textContent = formatNumber(Math.floor(current));
        }
    }, 16);
}

// Format Number with Commas
function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

// Initialize Back to Top Button
function initBackToTop() {
    const backToTopBtn = document.getElementById('backToTop');

    if (backToTopBtn) {
        window.addEventListener('scroll', () => {
            if (window.pageYOffset > 300) {
                backToTopBtn.classList.add('visible');
            } else {
                backToTopBtn.classList.remove('visible');
            }
        });

        backToTopBtn.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }
}

// Register User (Simulated API Call)
async function registerUser(userData) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            // Simulate random success/failure
            const isSuccess = Math.random() > 0.2; // 80% success rate

            if (isSuccess) {
                resolve({
                    success: true,
                    message: 'Registration successful',
                    userId: Math.floor(Math.random() * 10000) + 1,
                    verificationToken: 'verify_' + Date.now()
                });
            } else {
                reject(new Error('Registration failed. Please try again.'));
            }
        }, 1500);
    });
}

// Show Success Message
function showSuccessMessage(email) {
    const successMessage = document.getElementById('successMessage');
    if (successMessage) {
        successMessage.style.display = 'block';
        successMessage.classList.add('show');

        // Start countdown for auto-redirect
        let countdown = 10;
        const countdownElement = successMessage.querySelector('.countdown');

        const timer = setInterval(() => {
            countdown--;

            if (countdownElement) {
                countdownElement.textContent = countdown;
            }

            if (countdown <= 0) {
                clearInterval(timer);
                window.location.href = 'login.html';
            }
        }, 1000);
    }
}

// Resend Verification Email
async function resendVerificationEmail() {
    const pendingUser = localStorage.getItem('findthem_pending_user');

    if (!pendingUser) {
        showAlert('No pending registration found.', 'error');
        return;
    }

    const userData = JSON.parse(pendingUser);
    const resendBtn = document.querySelector('button[onclick="resendVerificationEmail()"]');

    if (resendBtn) {
        const originalText = resendBtn.innerHTML;
        resendBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
        resendBtn.disabled = true;

        try {
            await simulateAPICall();

            showAlert('Verification email resent successfully!', 'success');

            // Update timestamp
            userData.timestamp = Date.now();
            localStorage.setItem('findthem_pending_user', JSON.stringify(userData));

            // Reset button after delay
            setTimeout(() => {
                resendBtn.innerHTML = originalText;
                resendBtn.disabled = false;
            }, 2000);

        } catch (error) {
            showAlert('Failed to resend email. Please try again.', 'error');
            resendBtn.innerHTML = originalText;
            resendBtn.disabled = false;
        }
    }
}

// Social Sign Up
function socialSignUp(provider) {
    showAlert(`Connecting with ${provider}...`, 'info');

    // In production, this would redirect to OAuth provider
    // For demo, simulate registration
    setTimeout(() => {
        const userData = {
            id: Math.floor(Math.random() * 10000) + 1,
            email: `user_${Date.now()}@example.com`,
            name: 'Social User',
            provider: provider,
            verified: true,
            token: 'social_token_' + Date.now()
        };

        // Store user data
        localStorage.setItem('findthem_user', JSON.stringify(userData));
        localStorage.setItem('findthem_token', userData.token);

        showAlert(`Registered with ${provider} successfully!`, 'success');

        // Redirect to dashboard
        setTimeout(() => {
            window.location.href = '../dashboard/index.html';
        }, 1000);
    }, 1500);
}

// Check Password Strength (from auth.js)
function checkPasswordStrength(password) {
    if (!password) return 0;

    let strength = 0;

    // Length check
    if (password.length >= 8) strength++;
    if (password.length >= 12) strength++;

    // Complexity checks
    if (/[A-Z]/.test(password)) strength++;
    if (/[a-z]/.test(password)) strength++;
    if (/[0-9]/.test(password)) strength++;
    if (/[^A-Za-z0-9]/.test(password)) strength++;

    return Math.min(strength, 5);
}

// Toggle Password Visibility (from auth.js)
function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    const toggleBtn = input.nextElementSibling;

    if (input.type === 'password') {
        input.type = 'text';
        toggleBtn.innerHTML = '<i class="fas fa-eye-slash"></i>';
    } else {
        input.type = 'password';
        toggleBtn.innerHTML = '<i class="fas fa-eye"></i>';
    }
}

// Show Alert (from auth.js)
function showAlert(message, type = 'info') {
    // Implementation from auth.js
    const existingAlert = document.querySelector('.alert-message');
    if (existingAlert) existingAlert.remove();

    const alert = document.createElement('div');
    alert.className = `alert-message alert-${type}`;

    let icon = 'info-circle';
    if (type === 'success') icon = 'check-circle';
    if (type === 'error') icon = 'exclamation-circle';
    if (type === 'warning') icon = 'exclamation-triangle';

    alert.innerHTML = `
        <i class="fas fa-${icon}"></i>
        <span>${message}</span>
        <button class="alert-close" onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;

    alert.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: var(--border-radius);
        display: flex;
        align-items: center;
        gap: 10px;
        box-shadow: var(--box-shadow);
        z-index: 10000;
        max-width: 400px;
        animation: slideInRight 0.3s ease-out;
    `;

    const colors = {
        success: { bg: '#d1fae5', text: '#065f46', border: '#a7f3d0' },
        error: { bg: '#fee2e2', text: '#991b1b', border: '#fecaca' },
        warning: { bg: '#fef3c7', text: '#92400e', border: '#fde68a' },
        info: { bg: '#dbeafe', text: '#1e40af', border: '#bfdbfe' }
    };

    alert.style.background = colors[type].bg;
    alert.style.color = colors[type].text;
    alert.style.border = `1px solid ${colors[type].border}`;

    document.body.appendChild(alert);

    setTimeout(() => {
        if (alert.parentElement) {
            alert.style.animation = 'fadeOut 0.3s ease-out';
            setTimeout(() => alert.remove(), 300);
        }
    }, 5000);
}

// Simulate API Call
function simulateAPICall() {
    return new Promise((resolve) => {
        setTimeout(resolve, 1000);
    });
}

// Export functions for global use
window.togglePassword = togglePassword;
window.updatePasswordStrength = updatePasswordStrength;
window.checkPasswordMatch = checkPasswordMatch;
window.refreshCaptcha = refreshCaptcha;
window.selectUserType = selectUserType;
window.resendVerificationEmail = resendVerificationEmail;
window.socialSignUp = socialSignUp;