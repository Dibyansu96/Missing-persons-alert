// Emergency Contacts JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize emergency contacts page
    initEmergencyContacts();
    initSearch();
    initFilters();
    loadEmergencyContacts();
    initModal();
});

// Initialize Emergency Contacts
function initEmergencyContacts() {
    // Check if user has saved contacts
    checkSavedContacts();
    
    // Initialize quick contact cards
    initQuickContacts();
    
    // Add animation to contact cards
    observeContactCards();
}

// Initialize Quick Contacts
function initQuickContacts() {
    // Make emergency numbers clickable with confirmation
    document.querySelectorAll('.contact-number').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const number = this.textContent.trim();
            const description = this.closest('.contact-info').querySelector('p').textContent;
            showEmergencyCallModal(number, description);
        });
    });
    
    // Make organization contact links clickable
    document.querySelectorAll('.contact-link[href^="tel:"]').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const number = this.textContent.trim();
            const orgName = this.closest('.org-content').querySelector('h3').textContent;
            showEmergencyCallModal(number, orgName);
        });
    });
}

// Initialize Search
function initSearch() {
    const searchInput = document.getElementById('searchContacts');
    
    if (searchInput) {
        // Add enter key support
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchEmergencyContacts();
            }
        });
        
        // Add clear button
        const clearButton = document.createElement('button');
        clearButton.innerHTML = '<i class="fas fa-times"></i>';
        clearButton.className = 'clear-search';
        clearButton.style.cssText = `
            position: absolute;
            right: 120px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--gray-color);
            cursor: pointer;
            padding: 0.5rem;
            display: none;
        `;
        
        clearButton.addEventListener('click', function() {
            searchInput.value = '';
            this.style.display = 'none';
            searchEmergencyContacts();
        });
        
        searchInput.parentNode.insertBefore(clearButton, searchInput.nextSibling);
        
        // Show/hide clear button
        searchInput.addEventListener('input', function() {
            clearButton.style.display = this.value ? 'block' : 'none';
        });
    }
}

// Search Emergency Contacts
function searchEmergencyContacts() {
    const searchInput = document.getElementById('searchContacts');
    const searchTerm = searchInput.value.trim().toLowerCase();
    
    if (searchTerm) {
        // Filter contacts based on search term
        filterContactsBySearch(searchTerm);
        
        // Show search feedback
        showSearchFeedback(searchTerm);
    } else {
        // If empty, show all contacts
        loadEmergencyContacts();
        
        // Remove search feedback
        removeSearchFeedback();
    }
}

// Filter Contacts by Search
function filterContactsBySearch(searchTerm) {
    const contactCards = document.querySelectorAll('.contact-card');
    let visibleCount = 0;
    
    contactCards.forEach(card => {
        const country = card.querySelector('.country-name').textContent.toLowerCase();
        const category = card.querySelector('.contact-category').textContent.toLowerCase();
        const numbers = card.querySelectorAll('.number-info h4');
        
        let hasMatch = false;
        
        // Check country name
        if (country.includes(searchTerm)) {
            hasMatch = true;
        }
        
        // Check category
        if (category.includes(searchTerm)) {
            hasMatch = true;
        }
        
        // Check emergency service names
        numbers.forEach(number => {
            if (number.textContent.toLowerCase().includes(searchTerm)) {
                hasMatch = true;
            }
        });
        
        // Show/hide card based on match
        if (hasMatch) {
            card.style.display = 'block';
            visibleCount++;
        } else {
            card.style.display = 'none';
        }
    });
    
    // Show/hide no results message
    const noContactsFound = document.getElementById('noContactsFound');
    if (visibleCount === 0) {
        noContactsFound.style.display = 'block';
    } else {
        noContactsFound.style.display = 'none';
    }
}

// Show Search Feedback
function showSearchFeedback(searchTerm) {
    // Remove existing feedback
    removeSearchFeedback();
    
    const feedback = document.createElement('div');
    feedback.className = 'search-feedback';
    feedback.innerHTML = `
        <span>Showing results for: <strong>${searchTerm}</strong></span>
        <button onclick="clearSearch()"><i class="fas fa-times"></i></button>
    `;
    
    feedback.style.cssText = `
        background: #f0f9ff;
        border: 1px solid #bae6fd;
        border-radius: var(--border-radius);
        padding: 1rem 1.5rem;
        margin: 1rem 0;
        display: flex;
        justify-content: space-between;
        align-items: center;
        animation: fadeIn 0.3s ease-out;
    `;
    
    const searchSection = document.querySelector('.search-contacts-section .container');
    searchSection.appendChild(feedback);
}

// Remove Search Feedback
function removeSearchFeedback() {
    const existingFeedback = document.querySelector('.search-feedback');
    if (existingFeedback) {
        existingFeedback.remove();
    }
}

// Clear Search
function clearSearch() {
    const searchInput = document.getElementById('searchContacts');
    searchInput.value = '';
    
    // Remove search feedback
    removeSearchFeedback();
    
    // Load all contacts
    loadEmergencyContacts();
}

// Initialize Filters
function initFilters() {
    // Set up filter button click handlers
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            // Remove active class from all buttons
            document.querySelectorAll('.filter-btn').forEach(b => {
                b.classList.remove('active');
            });
            
            // Add active class to clicked button
            this.classList.add('active');
            
            // Apply filter
            const category = this.textContent.toLowerCase();
            filterByCategory(category);
        });
    });
    
    // Set up continent filter button click handlers
    document.querySelectorAll('.continent-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            // Remove active class from all buttons
            document.querySelectorAll('.continent-btn').forEach(b => {
                b.classList.remove('active');
            });
            
            // Add active class to clicked button
            this.classList.add('active');
            
            // Apply filter
            const continent = this.getAttribute('onclick').match(/'([^']+)'/)[1];
            filterByContinent(continent);
        });
    });
}

// Filter by Category
function filterByCategory(category) {
    const contactCards = document.querySelectorAll('.contact-card');
    let visibleCount = 0;
    
    contactCards.forEach(card => {
        const cardCategory = card.querySelector('.contact-category').textContent.toLowerCase();
        
        if (category === 'all' || cardCategory === category) {
            card.style.display = 'block';
            visibleCount++;
        } else {
            card.style.display = 'none';
        }
    });
    
    // Show/hide no results message
    const noContactsFound = document.getElementById('noContactsFound');
    if (visibleCount === 0) {
        noContactsFound.style.display = 'block';
    } else {
        noContactsFound.style.display = 'none';
    }
}

// Filter by Continent
function filterByContinent(continent) {
    const contactCards = document.querySelectorAll('.contact-card');
    let visibleCount = 0;
    
    contactCards.forEach(card => {
        const country = card.querySelector('.country-name').textContent;
        const cardContinent = getContinentByCountry(country);
        
        if (continent === 'all' || cardContinent === continent) {
            card.style.display = 'block';
            visibleCount++;
        } else {
            card.style.display = 'none';
        }
    });
    
    // Show/hide no results message
    const noContactsFound = document.getElementById('noContactsFound');
    if (visibleCount === 0) {
        noContactsFound.style.display = 'block';
    } else {
        noContactsFound.style.display = 'none';
    }
}

// Get Continent by Country (simplified for demo)
function getContinentByCountry(country) {
    const continentMap = {
        // North America
        'United States': 'north-america',
        'Canada': 'north-america',
        'Mexico': 'north-america',
        
        // Europe
        'United Kingdom': 'europe',
        'Germany': 'europe',
        'France': 'europe',
        'Spain': 'europe',
        'Italy': 'europe',
        
        // Asia
        'China': 'asia',
        'Japan': 'asia',
        'India': 'asia',
        'South Korea': 'asia',
        'Australia': 'asia', // Technically Oceania, but grouped for demo
        
        // Rest will default to their actual continents
    };
    
    return continentMap[country] || 'other';
}

// Load Emergency Contacts
async function loadEmergencyContacts() {
    const contactsGrid = document.getElementById('emergencyContactsGrid');
    const loadingState = document.getElementById('contactsLoading');
    const noContactsFound = document.getElementById('noContactsFound');
    
    if (!contactsGrid) return;
    
    // Show loading
    contactsGrid.innerHTML = '';
    loadingState.style.display = 'block';
    noContactsFound.style.display = 'none';
    
    try {
        // Fetch emergency contacts
        const contacts = await fetchEmergencyContacts();
        
        // Hide loading
        loadingState.style.display = 'none';
        
        if (contacts.length === 0) {
            noContactsFound.style.display = 'block';
            return;
        }
        
        // Clear grid
        contactsGrid.innerHTML = '';
        
        // Add contacts to grid
        contacts.forEach((contact, index) => {
            const contactCard = createContactCard(contact, index);
            contactsGrid.appendChild(contactCard);
        });
        
    } catch (error) {
        console.error('Error loading emergency contacts:', error);
        loadingState.style.display = 'none';
        showAlert('Failed to load emergency contacts. Please try again.', 'error');
    }
}

// Fetch Emergency Contacts
async function fetchEmergencyContacts() {
    // Simulate API call
    return new Promise((resolve) => {
        setTimeout(() => {
            // Sample emergency contacts data
            const contacts = [
                {
                    country: 'United States',
                    flag: '🇺🇸',
                    category: 'police',
                    numbers: [
                        { service: 'Emergency Police', number: '911' },
                        { service: 'Non-Emergency Police', number: '311' },
                        { service: 'Missing Persons Hotline', number: '1-800-844-6337' }
                    ]
                },
                {
                    country: 'Canada',
                    flag: '🇨🇦',
                    category: 'police',
                    numbers: [
                        { service: 'Emergency Police', number: '911' },
                        { service: 'Missing Children', number: '1-866-543-8477' }
                    ]
                },
                {
                    country: 'United Kingdom',
                    flag: '🇬🇧',
                    category: 'police',
                    numbers: [
                        { service: 'Emergency Police', number: '999' },
                        { service: 'Non-Emergency', number: '101' },
                        { service: 'Missing People UK', number: '116 000' }
                    ]
                },
                {
                    country: 'Germany',
                    flag: '🇩🇪',
                    category: 'police',
                    numbers: [
                        { service: 'Emergency Police', number: '110' },
                        { service: 'Emergency Medical', number: '112' }
                    ]
                },
                {
                    country: 'France',
                    flag: '🇫🇷',
                    category: 'police',
                    numbers: [
                        { service: 'Emergency Police', number: '17' },
                        { service: 'Emergency Medical', number: '15' },
                        { service: 'Fire Department', number: '18' }
                    ]
                },
                {
                    country: 'Australia',
                    flag: '🇦🇺',
                    category: 'police',
                    numbers: [
                        { service: 'Emergency Police', number: '000' },
                        { service: 'Missing Persons', number: '1800 333 000' }
                    ]
                },
                {
                    country: 'Japan',
                    flag: '🇯🇵',
                    category: 'police',
                    numbers: [
                        { service: 'Emergency Police', number: '110' },
                        { service: 'Emergency Medical', number: '119' }
                    ]
                },
                {
                    country: 'India',
                    flag: '🇮🇳',
                    category: 'police',
                    numbers: [
                        { service: 'Emergency Police', number: '112' },
                        { service: 'Police', number: '100' },
                        { service: 'Ambulance', number: '102' }
                    ]
                }
            ];
            
            resolve(contacts);
        }, 1000);
    });
}

// Create Contact Card
function createContactCard(contact, index) {
    const card = document.createElement('div');
    card.className = 'contact-card fade-in';
    card.style.animationDelay = `${index * 0.1}s`;
    
    // Format category for display
    const categoryDisplay = contact.category.charAt(0).toUpperCase() + contact.category.slice(1);
    
    // Format numbers HTML
    const numbersHtml = contact.numbers.map(num => `
        <div class="contact-number-item">
            <div class="number-icon">
                <i class="fas fa-phone"></i>
            </div>
            <div class="number-info">
                <h4>${num.service}</h4>
                <a href="tel:${formatPhoneNumber(num.number)}" class="number-value" onclick="handlePhoneClick(event, '${num.service}', '${contact.country}')">
                    ${num.number}
                </a>
            </div>
        </div>
    `).join('');
    
    card.innerHTML = `
        <div class="contact-card-header">
            <div class="contact-country">
                <span class="country-flag">${contact.flag}</span>
                <span class="country-name">${contact.country}</span>
            </div>
            <span class="contact-category">${categoryDisplay}</span>
        </div>
        <div class="contact-numbers">
            ${numbersHtml}
        </div>
        <div class="contact-actions">
            <button class="btn-call" onclick="showEmergencyCallModal('${contact.numbers[0].number}', '${contact.country} Emergency')">
                <i class="fas fa-phone"></i> Call Emergency
            </button>
            <button class="btn-save" onclick="saveContact('${contact.country}', '${contact.numbers[0].number}')">
                <i class="far fa-bookmark"></i>
            </button>
        </div>
    `;
    
    return card;
}

// Format Phone Number for tel: link
function formatPhoneNumber(phone) {
    // Remove all non-numeric characters except +
    return phone.replace(/[^\d+]/g, '');
}

// Handle Phone Click
function handlePhoneClick(event, service, country) {
    event.preventDefault();
    const phoneNumber = event.target.textContent.trim();
    showEmergencyCallModal(phoneNumber, `${service} - ${country}`);
}

// Initialize Modal
function initModal() {
    // Close modal when clicking outside
    const modal = document.getElementById('emergencyCallModal');
    if (modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                closeEmergencyModal();
            }
        });
        
        // Close on escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && modal.classList.contains('show')) {
                closeEmergencyModal();
            }
        });
    }
}

// Show Emergency Call Modal
function showEmergencyCallModal(phoneNumber, description) {
    const modal = document.getElementById('emergencyCallModal');
    const callTitle = document.getElementById('emergencyCallTitle');
    const callDescription = document.getElementById('emergencyCallDescription');
    const callNumber = document.getElementById('emergencyCallNumber');
    
    if (modal && callTitle && callDescription && callNumber) {
        // Set modal content
        callTitle.textContent = 'Emergency Call';
        callDescription.textContent = `You are about to call ${description}`;
        callNumber.textContent = phoneNumber;
        
        // Store phone number for calling
        modal.dataset.phoneNumber = formatPhoneNumber(phoneNumber);
        
        // Show modal
        modal.classList.add('show');
        modal.style.display = 'flex';
    }
}

// Close Emergency Modal
function closeEmergencyModal() {
    const modal = document.getElementById('emergencyCallModal');
    if (modal) {
        modal.classList.remove('show');
        setTimeout(() => {
            modal.style.display = 'none';
        }, 300);
    }
}

// Initiate Emergency Call
function initiateEmergencyCall() {
    const modal = document.getElementById('emergencyCallModal');
    if (modal && modal.dataset.phoneNumber) {
        const phoneNumber = modal.dataset.phoneNumber;
        
        // Close modal
        closeEmergencyModal();
        
        // Show confirmation
        if (confirm(`Call ${phoneNumber}? This will use your device's phone app.`)) {
            // Create tel link and trigger click
            const telLink = document.createElement('a');
            telLink.href = `tel:${phoneNumber}`;
            telLink.style.display = 'none';
            document.body.appendChild(telLink);
            telLink.click();
            document.body.removeChild(telLink);
        }
    }
}

// Save Contact
function saveContact(country, phoneNumber) {
    // Get saved contacts from localStorage
    const savedContacts = JSON.parse(localStorage.getItem('findthem_saved_contacts') || '[]');
    
    // Check if already saved
    const isAlreadySaved = savedContacts.some(contact => 
        contact.country === country && contact.phone === phoneNumber
    );
    
    if (isAlreadySaved) {
        showAlert('This contact is already saved.', 'info');
        return;
    }
    
    // Add to saved contacts
    savedContacts.push({
        country: country,
        phone: phoneNumber,
        savedAt: new Date().toISOString()
    });
    
    // Save to localStorage
    localStorage.setItem('findthem_saved_contacts', JSON.stringify(savedContacts));
    
    // Show success message
    showAlert('Contact saved successfully! You can access saved contacts in your dashboard.', 'success');
}

// Check Saved Contacts
function checkSavedContacts() {
    const savedContacts = JSON.parse(localStorage.getItem('findthem_saved_contacts') || '[]');
    
    // You could display a badge or indicator for saved contacts
    if (savedContacts.length > 0) {
        // console.log(`You have ${savedContacts.length} saved contacts`);
    }
}

// Download Resource
function downloadResource(filename) {
    showAlert(`Downloading ${filename}...`, 'info');
    
    // Simulate download
    setTimeout(() => {
        showAlert(`${filename} downloaded successfully!`, 'success');
        
        // In production, this would trigger actual file download
        // const link = document.createElement('a');
        // link.href = `/resources/downloads/${filename}`;
        // link.download = filename;
        // document.body.appendChild(link);
        // link.click();
        // document.body.removeChild(link);
    }, 1500);
}

// Show App Links
function showAppLinks() {
    const message = `
Available on:
• App Store: https://apps.apple.com/app/emergency-contacts
• Google Play: https://play.google.com/store/apps/details?id=com.emergency.contacts

The app provides offline access to emergency numbers worldwide.
    `;
    
    alert(message);
}

// Observe Contact Cards for Animation
function observeContactCards() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animated');
            }
        });
    }, { threshold: 0.1 });
    
    // Will observe cards after they're loaded
    setTimeout(() => {
        document.querySelectorAll('.contact-card').forEach(card => {
            observer.observe(card);
        });
    }, 500);
}

// Show Alert
function showAlert(message, type = 'info') {
    const existingAlert = document.querySelector('.alert-message');
    if (existingAlert) existingAlert.remove();
    
    const alert = document.createElement('div');
    alert.className = `alert-message alert-${type}`;
    
    let icon = 'info-circle';
    if (type === 'success') icon = 'check-circle';
    if (type === 'error') icon = 'exclamation-circle';
    if (type === 'warning') icon = 'exclamation-triangle';
    
    alert.innerHTML = `
        <i class="fas fa-${icon}"></i>
        <span>${message}</span>
        <button class="alert-close" onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    alert.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: var(--border-radius);
        display: flex;
        align-items: center;
        gap: 10px;
        box-shadow: var(--box-shadow);
        z-index: 10000;
        max-width: 400px;
        animation: slideInRight 0.3s ease-out;
    `;
    
    const colors = {
        success: { bg: '#d1fae5', text: '#065f46', border: '#a7f3d0' },
        error: { bg: '#fee2e2', text: '#991b1b', border: '#fecaca' },
        warning: { bg: '#fef3c7', text: '#92400e', border: '#fde68a' },
        info: { bg: '#dbeafe', text: '#1e40af', border: '#bfdbfe' }
    };
    
    alert.style.background = colors[type].bg;
    alert.style.color = colors[type].text;
    alert.style.border = `1px solid ${colors[type].border}`;
    
    document.body.appendChild(alert);
    
    setTimeout(() => {
        if (alert.parentElement) {
            alert.style.animation = 'fadeOut 0.3s ease-out';
            setTimeout(() => alert.remove(), 300);
        }
    }, 5000);
}

// Export functions for global use
window.searchEmergencyContacts = searchEmergencyContacts;
window.clearSearch = clearSearch;
window.filterByCategory = filterByCategory;
window.filterByContinent = filterByContinent;
window.showEmergencyCallModal = showEmergencyCallModal;
window.closeEmergencyModal = closeEmergencyModal;
window.initiateEmergencyCall = initiateEmergencyCall;
window.saveContact = saveContact;
window.downloadResource = downloadResource;
window.showAppLinks = showAppLinks;